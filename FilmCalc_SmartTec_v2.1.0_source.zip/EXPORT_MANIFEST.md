# FilmCalc Source Project Export

Generated: 2026-11-23T06:48:32

## Project

This archive contains the complete application source for **FilmCalc — ระบบคำนวณฟิล์มอาคาร** from `/home/ubuntu/filmcalc`, excluding generated/dependency folders and secrets.

## Included requested items

- `package.json` and `pnpm-lock.yaml`
- `app.config.ts` (Expo configuration; no `app.json` exists)
- `app/` — Expo Router screens, layouts, routes, and tools
- `src/` — not present in this Expo Router starter; application source is organized in `app/`, `components/`, `lib/`, `hooks/`, `constants/`, and `shared/`
- `eas.json` — not present in this project
- Backend/API: `server/`, `shared/`, `drizzle/`, `drizzle.config.ts`
- Reusable UI and business logic: `components/`, `lib/`, `hooks/`, `constants/`
- Expo assets/configuration, scripts, tests, public route manifest, and project docs

## Runtime commands

- Web/Metro preview: `pnpm dev:metro` on port 8081
- API: `pnpm dev:server` on port 3000
- Type check: `pnpm check`
- Lint: `pnpm lint`
- Tests: `pnpm test`
- Database sync: `pnpm db:push`

## Security exclusions

The archive intentionally excludes `node_modules/`, `.git/`, `.expo/`, build/cache folders, logs, `.env*` files, and any generated local secret material. Run `pnpm install` after extraction.

## File inventory

Total included files: 106

- `.gitignore`
- `.manus-starter-init.json`
- `.npmrc`
- `.watchmanconfig`
- `TODO.md`
- `app.config.ts`
- `app/(tabs)/_layout.tsx`
- `app/(tabs)/index.tsx`
- `app/(tabs)/jobs.tsx`
- `app/(tabs)/products.tsx`
- `app/(tabs)/reports.tsx`
- `app/(tabs)/settings.tsx`
- `app/_layout.tsx`
- `app/dev/theme-lab.tsx`
- `app/job/[id].tsx`
- `app/job/new.tsx`
- `app/oauth/callback.tsx`
- `app/tools.tsx`
- `assets/images/android-icon-background.png`
- `assets/images/android-icon-foreground.png`
- `assets/images/android-icon-monochrome.png`
- `assets/images/favicon.png`
- `assets/images/icon.png`
- `assets/images/partial-react-logo.png`
- `assets/images/react-logo.png`
- `assets/images/react-logo@2x.png`
- `assets/images/react-logo@3x.png`
- `assets/images/splash-icon.png`
- `babel.config.js`
- `components/external-link.tsx`
- `components/film-ui.tsx`
- `components/haptic-tab.tsx`
- `components/hello-wave.tsx`
- `components/job-editor.tsx`
- `components/parallax-scroll-view.tsx`
- `components/screen-container.tsx`
- `components/themed-view.tsx`
- `components/ui/collapsible.tsx`
- `components/ui/icon-symbol.ios.tsx`
- `components/ui/icon-symbol.tsx`
- `constants/const.ts`
- `constants/oauth.ts`
- `constants/theme.ts`
- `drizzle.config.ts`
- `drizzle/0000_elite_eternals.sql`
- `drizzle/meta/0000_snapshot.json`
- `drizzle/meta/_journal.json`
- `drizzle/migrations/.gitkeep`
- `drizzle/relations.ts`
- `drizzle/schema.ts`
- `eslint.config.js`
- `expo-env.d.ts`
- `global.css`
- `hooks/use-auth.ts`
- `hooks/use-color-scheme.ts`
- `hooks/use-color-scheme.web.ts`
- `hooks/use-colors.ts`
- `lib/_core/api.ts`
- `lib/_core/auth.ts`
- `lib/_core/manus-runtime.ts`
- `lib/_core/nativewind-pressable.ts`
- `lib/_core/theme.ts`
- `lib/app-store.tsx`
- `lib/film-calculator.ts`
- `lib/theme-provider.tsx`
- `lib/trpc.ts`
- `lib/types.ts`
- `lib/utils.ts`
- `metro.config.js`
- `nativewind-env.d.ts`
- `package.json`
- `plan.md`
- `pnpm-lock.yaml`
- `public/manus-routes.json`
- `scripts/generate_qr.mjs`
- `scripts/load-env.js`
- `server/_core/context.ts`
- `server/_core/cookies.ts`
- `server/_core/cors.ts`
- `server/_core/dataApi.ts`
- `server/_core/env.ts`
- `server/_core/heartbeat.ts`
- `server/_core/imageGeneration.ts`
- `server/_core/index.ts`
- `server/_core/llm.ts`
- `server/_core/notification.ts`
- `server/_core/oauth.ts`
- `server/_core/sdk.ts`
- `server/_core/storageProxy.ts`
- `server/_core/systemRouter.ts`
- `server/_core/trpc.ts`
- `server/_core/types/cookie.d.ts`
- `server/_core/types/manusTypes.ts`
- `server/_core/voiceTranscription.ts`
- `server/db.ts`
- `server/routers.ts`
- `server/storage.ts`
- `shared/_core/errors.ts`
- `shared/const.ts`
- `shared/types.ts`
- `tailwind.config.js`
- `tests/auth.logout.test.ts`
- `tests/cors.test.ts`
- `theme.config.d.ts`
- `theme.config.js`
- `tsconfig.json`
