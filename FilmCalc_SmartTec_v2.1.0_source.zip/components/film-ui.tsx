import { Feather } from "@expo/vector-icons";
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View, type TextInputProps, type ViewStyle } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { JOB_STATUS_COLOR, JOB_STATUS_LABEL, type JobStatus } from "@/lib/types";

export const COLORS = { navy: "#071A33", navy2: "#0D2A50", cyan: "#39B8F2", cyanSoft: "#DDF5FF", ink: "#10243E", muted: "#6B7C93", line: "#D9E4EF", paper: "#F4F8FC", white: "#FFFFFF", lime: "#B7E75B", amber: "#F3A83B", red: "#DD5A5A", slate: "#53677F" };

export function Page({ children, scroll = true }: { children: React.ReactNode; scroll?: boolean }) {
  const insets = useSafeAreaInsets();
  const content = <View style={[styles.page, { paddingTop: Math.max(insets.top, 12) }]}>{children}</View>;
  return scroll ? <ScrollView style={styles.background} contentContainerStyle={{ paddingBottom: Math.max(insets.bottom, 24) }}>{content}</ScrollView> : <View style={styles.background}>{content}</View>;
}

export function Header({ eyebrow, title, subtitle, right }: { eyebrow?: string; title: string; subtitle?: string; right?: React.ReactNode }) {
  return <View style={styles.header}><View style={{ flex: 1 }}>{eyebrow ? <Text style={styles.eyebrow}>{eyebrow}</Text> : null}<Text style={styles.title}>{title}</Text>{subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}</View>{right}</View>;
}

export function Card({ children, style }: { children: React.ReactNode; style?: ViewStyle }) { return <View style={[styles.card, style]}>{children}</View>; }
export function SectionTitle({ children, action }: { children: React.ReactNode; action?: React.ReactNode }) { return <View style={styles.sectionRow}><Text style={styles.sectionTitle}>{children}</Text>{action}</View>; }

export function Button({ children, onPress, variant = "primary", icon, disabled = false, style }: { children: React.ReactNode; onPress: () => void; variant?: "primary" | "secondary" | "ghost" | "danger"; icon?: React.ComponentProps<typeof Feather>["name"]; disabled?: boolean; style?: ViewStyle }) {
  const palette = variant === "primary" ? { bg: COLORS.navy, fg: COLORS.white, border: COLORS.navy } : variant === "danger" ? { bg: "#FFF0F0", fg: COLORS.red, border: "#F4CACA" } : variant === "secondary" ? { bg: COLORS.cyanSoft, fg: "#0A6B93", border: "#B9E9FB" } : { bg: COLORS.white, fg: COLORS.navy, border: COLORS.line };
  return <Pressable disabled={disabled} onPress={onPress} style={({ pressed }) => [styles.button, { backgroundColor: palette.bg, borderColor: palette.border, opacity: disabled ? 0.45 : pressed ? 0.72 : 1 }, style]}><View style={styles.buttonInner}>{icon ? <Feather name={icon} size={17} color={palette.fg} /> : null}<Text style={[styles.buttonText, { color: palette.fg }]}>{children}</Text></View></Pressable>;
}

export function Metric({ label, value, detail, icon, tone = "blue" }: { label: string; value: string; detail?: string; icon: React.ComponentProps<typeof Feather>["name"]; tone?: "blue" | "lime" | "amber" }) {
  const color = tone === "lime" ? COLORS.lime : tone === "amber" ? COLORS.amber : COLORS.cyan;
  return <View style={styles.metric}><View style={[styles.metricIcon, { backgroundColor: `${color}24` }]}><Feather name={icon} size={18} color={color} /></View><Text style={styles.metricValue}>{value}</Text><Text style={styles.metricLabel}>{label}</Text>{detail ? <Text style={styles.metricDetail}>{detail}</Text> : null}</View>;
}

export function StatusPill({ status }: { status: JobStatus }) { return <View style={[styles.statusPill, { backgroundColor: `${JOB_STATUS_COLOR[status]}18` }]}><View style={[styles.statusDot, { backgroundColor: JOB_STATUS_COLOR[status] }]} /><Text style={[styles.statusText, { color: JOB_STATUS_COLOR[status] }]}>{JOB_STATUS_LABEL[status]}</Text></View>; }

export function Field({ label, hint, ...props }: TextInputProps & { label: string; hint?: string }) { return <View style={styles.field}><Text style={styles.fieldLabel}>{label}</Text><TextInput placeholderTextColor="#9AAABD" style={styles.input} {...props} />{hint ? <Text style={styles.hint}>{hint}</Text> : null}</View>; }

export function IconButton({ icon, onPress, label }: { icon: React.ComponentProps<typeof Feather>["name"]; onPress: () => void; label?: string }) { return <Pressable accessibilityLabel={label} onPress={onPress} style={({ pressed }) => [styles.iconButton, { opacity: pressed ? 0.6 : 1 }]}><Feather name={icon} size={19} color={COLORS.navy} /></Pressable>; }

export function EmptyState({ icon, title, detail, action }: { icon: React.ComponentProps<typeof Feather>["name"]; title: string; detail: string; action?: React.ReactNode }) { return <Card style={styles.empty}><View style={styles.emptyIcon}><Feather name={icon} size={28} color={COLORS.cyan} /></View><Text style={styles.emptyTitle}>{title}</Text><Text style={styles.emptyDetail}>{detail}</Text>{action}</Card>; }

export const styles = StyleSheet.create({ background: { flex: 1, backgroundColor: COLORS.paper }, page: { paddingHorizontal: 18, paddingBottom: 18 }, header: { flexDirection: "row", alignItems: "flex-start", gap: 12, marginBottom: 18 }, eyebrow: { color: COLORS.cyan, fontSize: 12, fontWeight: "800", letterSpacing: 1.2, marginBottom: 6 }, title: { color: COLORS.ink, fontSize: 28, fontWeight: "800", letterSpacing: -0.6 }, subtitle: { color: COLORS.muted, fontSize: 14, lineHeight: 21, marginTop: 6 }, sectionRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 22, marginBottom: 10 }, sectionTitle: { color: COLORS.ink, fontSize: 17, fontWeight: "800" }, card: { backgroundColor: COLORS.white, borderRadius: 20, borderWidth: 1, borderColor: COLORS.line, padding: 16, shadowColor: "#0D2A50", shadowOpacity: 0.05, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 1 }, button: { minHeight: 46, paddingHorizontal: 16, borderRadius: 13, borderWidth: 1, justifyContent: "center" }, buttonInner: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 }, buttonText: { fontSize: 14, fontWeight: "800" }, metric: { backgroundColor: COLORS.navy, borderRadius: 18, padding: 14, minHeight: 124, flex: 1, overflow: "hidden" }, metricIcon: { width: 34, height: 34, borderRadius: 10, alignItems: "center", justifyContent: "center", marginBottom: 8 }, metricValue: { color: COLORS.white, fontSize: 23, fontWeight: "900" }, metricLabel: { color: "#C8D8E8", fontSize: 12, marginTop: 3 }, metricDetail: { color: "#7FA8C9", fontSize: 11, marginTop: 5 }, statusPill: { borderRadius: 999, paddingHorizontal: 9, paddingVertical: 5, flexDirection: "row", alignItems: "center", gap: 5, alignSelf: "flex-start" }, statusDot: { width: 6, height: 6, borderRadius: 3 }, statusText: { fontSize: 11, fontWeight: "800" }, field: { marginBottom: 13 }, fieldLabel: { color: COLORS.ink, fontSize: 13, fontWeight: "800", marginBottom: 6 }, input: { minHeight: 46, borderWidth: 1, borderColor: COLORS.line, borderRadius: 12, paddingHorizontal: 13, paddingVertical: 10, color: COLORS.ink, backgroundColor: "#FBFDFF", fontSize: 15 }, hint: { fontSize: 11, color: COLORS.muted, marginTop: 5 }, iconButton: { width: 40, height: 40, borderRadius: 12, borderWidth: 1, borderColor: COLORS.line, backgroundColor: COLORS.white, alignItems: "center", justifyContent: "center" }, empty: { alignItems: "center", paddingVertical: 28 }, emptyIcon: { width: 56, height: 56, borderRadius: 18, backgroundColor: COLORS.cyanSoft, alignItems: "center", justifyContent: "center", marginBottom: 12 }, emptyTitle: { fontSize: 17, fontWeight: "800", color: COLORS.ink }, emptyDetail: { textAlign: "center", color: COLORS.muted, lineHeight: 20, marginTop: 5, marginBottom: 14 }, });
