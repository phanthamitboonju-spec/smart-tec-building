import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useEffect, useMemo, useState } from "react";
import { Pressable, Text, View } from "react-native";
import {
  Button, Card, COLORS, Field, Header, IconButton, Page, SectionTitle, StatusPill,
} from "@/components/film-ui";
import { useAppStore } from "@/lib/app-store";
import { quotationHtml, shareHtmlAsPdf, workOrderHtml } from "@/lib/documents";
import {
  buildPhysicalRollProfiles, calculateJob, DEFAULT_ROLL_RULES, formatArea,
  newPane, normalizeNumber,
} from "@/lib/film-calculator";
import {
  JOB_STATUS_FLOW, JOB_STATUS_LABEL, type Job, type JobStatus, type PaneInput,
  type QuoteSnapshot, type TaxTreatment, type RollRuleSettings, type OrientationPolicy,
  type FilmFace, type FactoryEdge, type SpliceMethod,
} from "@/lib/types";

function nextStatus(status: JobStatus): JobStatus {
  return JOB_STATUS_FLOW[Math.min(JOB_STATUS_FLOW.length - 1, JOB_STATUS_FLOW.indexOf(status) + 1)];
}

export function JobEditor({ jobId }: { jobId?: string }) {
  const router = useRouter();
  const store = useAppStore();
  const existing = jobId ? store.jobs.find((job) => job.id === jobId) : undefined;
  const [title, setTitle] = useState(existing?.title ?? "");
  const [customer, setCustomer] = useState(existing?.customer ?? "");
  const [site, setSite] = useState(existing?.site ?? "");
  const [notes, setNotes] = useState(existing?.notes ?? "");
  const [productId, setProductId] = useState(existing?.productId ?? store.products[0]?.id ?? "");
  const [panes, setPanes] = useState<PaneInput[]>(existing?.panes ?? [newPane(0)]);
  const [result, setResult] = useState(existing?.calculation ?? null);
  const [error, setError] = useState("");
  const [rollCount, setRollCount] = useState(String(existing?.rollProfiles?.length ?? 1));
  const [rollRules, setRollRules] = useState<RollRuleSettings>({ ...DEFAULT_ROLL_RULES, ...(existing?.physicalRollRules ?? {}) });
  const [travelFee, setTravelFee] = useState("");
  const [scaffoldFee, setScaffoldFee] = useState("");
  const [removalFee, setRemovalFee] = useState("");
  const [discount, setDiscount] = useState("");
  const [taxTreatment, setTaxTreatment] = useState<TaxTreatment>("not_applicable");
  const [savedMessage, setSavedMessage] = useState("");

  const product = useMemo(
    () => store.products.find((item) => item.id === productId) ?? store.products[0],
    [productId, store.products],
  );

  /* eslint-disable react-hooks/set-state-in-effect -- hydrate the editor when an existing job is loaded. */
  useEffect(() => {
    if (!existing) return;
    setTitle(existing.title);
    setCustomer(existing.customer);
    setSite(existing.site);
    setNotes(existing.notes);
    setProductId(existing.productId);
    setPanes(existing.panes);
    setResult(existing.calculation);
    setRollCount(String(existing.rollProfiles?.length ?? 1));
    setRollRules({ ...DEFAULT_ROLL_RULES, ...(existing.physicalRollRules ?? {}) });
    if (existing.quote) {
      setTravelFee(String(existing.quote.extras.travelFee || ""));
      setScaffoldFee(String(existing.quote.extras.scaffoldFee || ""));
      setRemovalFee(String(existing.quote.extras.oldFilmRemovalFee || ""));
      setDiscount(String(existing.quote.discount || ""));
      setTaxTreatment(existing.quote.taxTreatment);
    }
  }, [existing, store.hydrated]);
  /* eslint-enable react-hooks/set-state-in-effect */

  const invalidatePlan = (message = "ข้อมูลเปลี่ยนแล้ว กรุณาคำนวณแผนใหม่ก่อนบันทึก") => {
    setResult(null);
    setSavedMessage(message);
  };

  const updatePane = (id: string, patch: Partial<PaneInput>) => {
    setPanes((current) => current.map((pane) => pane.id === id ? { ...pane, ...patch } : pane));
    invalidatePlan();
  };

  const updateRule = <K extends keyof RollRuleSettings>(key: K, value: RollRuleSettings[K]) => {
    setRollRules((current) => ({ ...current, [key]: value }));
    invalidatePlan("ข้อมูลข้อกำหนดม้วนเปลี่ยนแล้ว กรุณาคำนวณใหม่");
  };

  const runPlan = () => {
    if (!product) return;
    try {
      setError("");
      const count = Math.max(1, Math.min(20, Math.floor(normalizeNumber(rollCount, 1))));
      const profiles = buildPhysicalRollProfiles(product, count, store.settings, rollRules, existing?.id ?? "new-job");
      const planned = calculateJob(panes, product, store.settings.marginCm, profiles);
      setResult(planned);
      setRollCount(String(count));
      setSavedMessage("คำนวณด้วยเอนจินต้นฉบับ 10.36.1 แล้ว — ตรวจสถานะและคำเตือนก่อนตัดจริง");
    } catch (cause) {
      setResult(null);
      setError(cause instanceof Error ? cause.message : "ตรวจข้อมูลบาน ฟิล์ม และม้วนจริงแล้วลองอีกครั้ง");
    }
  };

  const makeQuote = (createdAt: string): QuoteSnapshot | null => {
    if (!result || !product) return null;
    const extras = {
      travelFee: normalizeNumber(travelFee),
      scaffoldFee: normalizeNumber(scaffoldFee),
      oldFilmRemovalFee: normalizeNumber(removalFee),
      additionalFee: 0,
    };
    const base = product.priceStatus === "active" && product.pricePerSqft > 0
      ? result.quoteAreaSqft * product.pricePerSqft
      : null;
    const subtotalBeforeDiscount = base == null
      ? null
      : Math.max(0, base + extras.travelFee + extras.scaffoldFee + extras.oldFilmRemovalFee);
    const discountValue = Math.min(Math.max(0, normalizeNumber(discount)), subtotalBeforeDiscount ?? 0);
    const subtotal = subtotalBeforeDiscount == null ? null : Math.max(0, subtotalBeforeDiscount - discountValue);
    const taxAmount = subtotal == null ? 0
      : taxTreatment === "exclusive" ? subtotal * 0.07
        : taxTreatment === "inclusive" ? subtotal * 7 / 107 : 0;
    return {
      quoteNumber: `QT-${createdAt.slice(0, 10).replaceAll("-", "")}-${createdAt.slice(11, 19).replaceAll(":", "").slice(-4)}`,
      customerName: customer,
      quotedAreaSqft: result.quoteAreaSqft,
      unitRate: product.priceStatus === "active" ? product.pricePerSqft : null,
      subtotal,
      extras,
      discount: discountValue,
      taxTreatment,
      taxAmount: Number(taxAmount.toFixed(2)),
      total: subtotal == null ? null : Number((taxTreatment === "exclusive" ? subtotal + taxAmount : subtotal).toFixed(2)),
      validUntil: new Date(new Date(createdAt).getTime() + store.settings.quoteValidityDays * 86400000).toISOString(),
      createdAt,
    };
  };

  const saveJob = () => {
    if (!title.trim()) { setError("กรุณาตั้งชื่องานก่อนบันทึก"); return; }
    if (result && result.orientationStatus === "block") {
      setError("แผนมีสถานะ BLOCK — ยังไม่สามารถบันทึกเป็นแผนพร้อมใช้งานได้ กรุณาแก้ข้อขัดแย้งของวัสดุ/รอยต่อก่อน");
      return;
    }
    const createdAt = new Date().toISOString();
    const quote = makeQuote(createdAt);
    const payload = {
      title: title.trim(), customer: customer.trim(), site: site.trim(), notes: notes.trim(),
      status: existing?.status ?? "draft" as JobStatus,
      productId: product?.id ?? "", panes, calculation: result, quote,
      physicalRollRules: rollRules,
      rollProfiles: result?.physicalRolls ?? [],
      checklist: existing?.checklist ?? { inspect: false, surface: false, install: false, handover: false },
    };
    if (existing) store.updateJob(existing.id, payload);
    else { const created = store.addJob(payload); router.replace(`/job/${created.id}`); }
    setSavedMessage("บันทึกงานพร้อม calculation snapshot ล่าสุดแล้ว");
    setError("");
  };

  const advance = () => {
    if (!existing) { saveJob(); return; }
    if (!existing.calculation || existing.calculation.engineVersion !== "10.36.1") {
      setError("งานนี้ยังไม่มีผลคำนวณจากเอนจิน 10.36.1 กรุณาคำนวณและบันทึกใหม่ก่อนเปลี่ยนสถานะ");
      return;
    }
    if (existing.calculation.orientationStatus !== "pass") {
      setError("สถานะทิศทาง/ข้อกำหนดวัสดุยังไม่ใช่ PASS (ยังเป็น REVIEW หรือ BLOCK) จึงยังไม่อนุญาตให้ยืนยันหรือสั่งตัดฟิล์ม");
      return;
    }
    store.updateJob(existing.id, { status: nextStatus(existing.status) });
    setSavedMessage(`เปลี่ยนสถานะเป็น ${JOB_STATUS_LABEL[nextStatus(existing.status)]}`);
    setError("");
  };

  const exportDoc = async (kind: "quote" | "order") => {
    if (!existing) return;
    try {
      const prod = store.products.find((p) => p.id === existing.productId);
      await shareHtmlAsPdf(kind === "quote" ? quotationHtml(existing, prod, store.settings) : workOrderHtml(existing, prod, store.settings));
    } catch (e) { setSavedMessage(`ส่งออกไม่สำเร็จ: ${(e as Error).message}`); }
  };
  const toggleCheck = (key: keyof Job["checklist"]) => {
    if (!existing) return;
    store.updateJob(existing.id, { checklist: { ...existing.checklist, [key]: !existing.checklist[key] } });
  };

  const optionPills = <T extends string>(
    value: T,
    options: { value: T; label: string }[],
    onChange: (next: T) => void,
  ) => <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
    {options.map((option) => <Pressable key={option.value} onPress={() => onChange(option.value)} style={{ borderWidth: 1, borderColor: value === option.value ? COLORS.cyan : COLORS.line, backgroundColor: value === option.value ? COLORS.cyanSoft : COLORS.white, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 7 }}>
      <Text style={{ color: value === option.value ? COLORS.navy : COLORS.muted, fontSize: 11, fontWeight: "800" }}>{option.label}</Text>
    </Pressable>)}
  </View>;

  return <Page>
    <Header eyebrow={existing ? "EDIT JOB" : "NEW FIELD JOB"} title={existing ? title || "แก้ไขงาน" : "สร้างงานใหม่"} subtitle={existing ? `${customer || "ไม่ระบุลูกค้า"} · ${site || "ไม่ระบุสถานที่"}` : "เก็บข้อมูลหน้างานและม้วนฟิล์มจริงก่อนวางแผน"} right={existing ? <StatusPill status={existing.status} /> : null} />

    <Card>
      <SectionTitle>ข้อมูลหน้างาน</SectionTitle>
      <Field label="ชื่องาน" value={title} onChangeText={setTitle} placeholder="เช่น อาคารสำนักงาน A" />
      <Field label="ชื่อลูกค้า" value={customer} onChangeText={setCustomer} placeholder="บริษัท / ผู้ติดต่อ" />
      <Field label="สถานที่ติดตั้ง" value={site} onChangeText={setSite} placeholder="ที่อยู่หรือชื่อไซต์งาน" />
      <Field label="หมายเหตุ" value={notes} onChangeText={setNotes} placeholder="ข้อจำกัดกระจก เวลาเข้าหน้างาน ฯลฯ" multiline numberOfLines={3} />
    </Card>

    <SectionTitle action={<Text style={{ color: COLORS.muted, fontSize: 12 }}>{store.products.length} SKU</Text>}>เลือกฟิล์มอาคารหลัก</SectionTitle>
    <View style={{ gap: 8 }}>
      {store.products.map((item) => <Pressable key={item.id} onPress={() => { setProductId(item.id); invalidatePlan("เปลี่ยนรุ่นฟิล์มแล้ว กรุณาคำนวณแผนใหม่"); }} style={{ borderWidth: 1, borderColor: product?.id === item.id ? COLORS.cyan : COLORS.line, backgroundColor: product?.id === item.id ? COLORS.cyanSoft : COLORS.white, borderRadius: 14, padding: 12 }}>
        <View style={{ flexDirection: "row", alignItems: "center" }}><View style={{ flex: 1 }}>
          <Text style={{ color: COLORS.ink, fontWeight: "900" }}>{item.brand} · {item.model}</Text>
          <Text style={{ color: COLORS.muted, fontSize: 12, marginTop: 3 }}>{item.sku} · {item.rollWidthCm} × {item.rollLengthCm} ซม. · {item.priceStatus === "active" ? `C6 ฿${item.pricePerSqft}/ตร.ฟุต` : "ยังไม่ยืนยันราคา C6"}</Text>
          {item.specs ? <Text style={{ color: COLORS.muted, fontSize: 10, marginTop: 4 }}>{[
            item.specs.vlt != null ? `VLT ${item.specs.vlt}%` : "",
            item.specs.uv != null ? `UV ${item.specs.uv}%` : "",
            item.specs.tser != null ? `TSER ${item.specs.tser}%` : "",
            item.specs.irr != null ? `IRR ${item.specs.irr}%` : "",
          ].filter(Boolean).join(" · ")}</Text> : null}
        </View>{product?.id === item.id ? <Feather name="check-circle" size={20} color={COLORS.cyan} /> : null}</View>
      </Pressable>)}
    </View>

    <SectionTitle>ม้วนฟิล์มจริงที่มีในงานนี้</SectionTitle>
    <Card>
      <Text style={{ color: COLORS.muted, fontSize: 12, lineHeight: 18, marginBottom: 10 }}>กรอกจำนวนม้วนที่มีจริง ระบบจะคิดกับหน้ากว้างและความยาวของแต่ละม้วนแยกกัน ไม่ได้นำหน้ากว้างมาบวกเป็นม้วนใหญ่ หากไม่ทราบล็อตหรือข้อกำหนด ให้คงเป็นไม่ทราบและตรวจคำเตือนก่อนตัด</Text>
      <Field label="จำนวนม้วนจริง (1–20)" keyboardType="number-pad" value={rollCount} onChangeText={(v) => { setRollCount(v); invalidatePlan(); }} />
      <Field label="Lot / เลขล็อต (ใช้ร่วมกับทุกม้วนในกลุ่มนี้)" value={rollRules.lotId} onChangeText={(v) => updateRule("lotId", v)} placeholder="ระบุจากฉลากม้วน" />
      <Text style={{ color: COLORS.ink, fontWeight: "800", fontSize: 12, marginBottom: 7 }}>นโยบายแนวฟิล์มตามคู่มือ</Text>
      {optionPills<OrientationPolicy>(rollRules.policy, [
        { value: "unknown", label: "ไม่ทราบ" }, { value: "standard", label: "หมุนได้ตามคู่มือ" }, { value: "directional", label: "มีทิศทาง/ลาย" },
      ], (v) => updateRule("policy", v))}
      <Text style={{ color: COLORS.ink, fontWeight: "800", fontSize: 12, marginTop: 12, marginBottom: 7 }}>ด้านฟิล์ม (Face)</Text>
      {optionPills<FilmFace>(rollRules.face, [
        { value: "unknown", label: "ไม่ทราบ" }, { value: "A", label: "ด้าน A" }, { value: "B", label: "ด้าน B" },
      ], (v) => updateRule("face", v))}
      <Text style={{ color: COLORS.ink, fontWeight: "800", fontSize: 12, marginTop: 12, marginBottom: 7 }}>ขอบโรงงาน (Factory Edge)</Text>
      {optionPills<FactoryEdge>(rollRules.factoryEdge, [
        { value: "unknown", label: "ไม่ทราบ" }, { value: "A", label: "ขอบ A" }, { value: "B", label: "ขอบ B" },
      ], (v) => updateRule("factoryEdge", v))}
      <Field label="รหัสทิศทางม้วน/ลาย (ถ้ามี)" value={rollRules.directionKey} onChangeText={(v) => updateRule("directionKey", v)} placeholder="ใช้รหัสตามฉลากหรือคู่มือ ไม่เดาเอง" />
      <Text style={{ color: COLORS.ink, fontWeight: "800", fontSize: 12, marginBottom: 7 }}>วิธีต่อฟิล์มตามคู่มือ SKU</Text>
      {optionPills<SpliceMethod>(rollRules.spliceMethod, [
        { value: "unknown", label: "ยังไม่ทราบ" }, { value: "butt", label: "ชนขอบ" }, { value: "overlay", label: "ซ้อน" },
        { value: "overlap-cut-through", label: "ซ้อนแล้วกรีด" }, { value: "forbidden", label: "ห้ามต่อ" },
      ], (v) => updateRule("spliceMethod", v))}
      {rollRules.spliceMethod === "overlay" || rollRules.spliceMethod === "overlap-cut-through"
        ? <Field label="ระยะซ้อนตามคู่มือ (ซม.)" keyboardType="decimal-pad" value={rollRules.spliceOverlapCm} onChangeText={(v) => updateRule("spliceOverlapCm", v)} placeholder="กรอกตามคู่มือรุ่นนี้เท่านั้น" />
        : null}
      <Field label="แหล่งอ้างอิงข้อกำหนด (คู่มือ/เอกสารผู้ผลิต)" value={rollRules.specSource} onChangeText={(v) => updateRule("specSource", v)} placeholder="ชื่อเอกสาร / URL / เลขหน้า" />
      <Pressable onPress={() => updateRule("specVerified", !rollRules.specVerified)} style={{ flexDirection: "row", alignItems: "center", marginTop: 8, padding: 11, backgroundColor: rollRules.specVerified ? "#EAF9EE" : COLORS.paper, borderRadius: 11, borderWidth: 1, borderColor: rollRules.specVerified ? "#9ED6AD" : COLORS.line }}>
        <Feather name={rollRules.specVerified ? "check-square" : "square"} size={18} color={rollRules.specVerified ? "#218544" : COLORS.muted} />
        <Text style={{ color: COLORS.ink, fontSize: 12, fontWeight: "800", marginLeft: 9, flex: 1 }}>ตรวจยืนยันข้อมูลด้านบนกับเอกสารผู้ผลิตรุ่นนี้แล้ว</Text>
      </Pressable>
      <Text style={{ color: COLORS.muted, fontSize: 10, lineHeight: 16, marginTop: 8 }}>อย่าเลือกยืนยันจนกว่าจะตรวจคู่มือจริงครบทุกข้อ ม้วนในกลุ่มนี้จะได้รับข้อมูลร่วมกันทั้งหมด หากมีหลาย Lot หรือข้อกำหนดต่างกัน ต้องแยกกลุ่มม้วนให้ชัดก่อนใช้งาน</Text>
    </Card>

    <SectionTitle action={<Button icon="plus" variant="secondary" onPress={() => { setPanes((current) => [...current, newPane(current.length)]); invalidatePlan(); }}>เพิ่มบาน</Button>}>รายการบานกระจก</SectionTitle>
    {panes.map((pane, index) => <Card key={pane.id} style={{ marginBottom: 10 }}>
      <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 12 }}><View style={{ flex: 1 }}><Text style={{ color: COLORS.ink, fontWeight: "900" }}>{pane.label || `บาน ${index + 1}`}</Text><Text style={{ color: COLORS.muted, fontSize: 11, marginTop: 2 }}>กรอกขนาดกระจกที่วัดจริง หน่วยเซนติเมตร</Text></View>{panes.length > 1 ? <IconButton icon="trash-2" label="ลบบาน" onPress={() => { setPanes((current) => current.filter((item) => item.id !== pane.id)); invalidatePlan(); }} /> : null}</View>
      <View style={{ flexDirection: "row", gap: 9 }}><View style={{ flex: 1 }}><Field label="กว้าง (ซม.)" keyboardType="decimal-pad" value={String(pane.widthCm || "")} onChangeText={(value) => updatePane(pane.id, { widthCm: normalizeNumber(value) })} /></View><View style={{ flex: 1 }}><Field label="สูง (ซม.)" keyboardType="decimal-pad" value={String(pane.heightCm || "")} onChangeText={(value) => updatePane(pane.id, { heightCm: normalizeNumber(value) })} /></View><View style={{ width: 62 }}><Field label="จำนวน" keyboardType="number-pad" value={String(pane.qty || "")} onChangeText={(value) => updatePane(pane.id, { qty: Math.round(normalizeNumber(value, 1)) })} /></View></View>
      <View style={{ flexDirection: "row", gap: 7 }}>{(["auto", "V", "H"] as const).map((direction) => <Pressable key={direction} onPress={() => updatePane(pane.id, { direction })} style={{ flex: 1, alignItems: "center", paddingVertical: 9, borderRadius: 10, borderWidth: 1, borderColor: pane.direction === direction ? COLORS.navy : COLORS.line, backgroundColor: pane.direction === direction ? COLORS.navy : COLORS.white }}><Text style={{ color: pane.direction === direction ? COLORS.white : COLORS.muted, fontSize: 12, fontWeight: "800" }}>{direction === "auto" ? "อัตโนมัติ" : `แนว ${direction}`}</Text></Pressable>)}</View>
    </Card>)}

    <Button icon="cpu" onPress={runPlan}>คำนวณแผนตัดทั้งงาน</Button>
    {error ? <View style={{ backgroundColor: "#FFF0F0", borderColor: "#F4CACA", borderWidth: 1, borderRadius: 12, padding: 12, marginTop: 12 }}><Text style={{ color: COLORS.red, fontWeight: "700", lineHeight: 20 }}>{error}</Text></View> : null}

    {result ? <>
      <SectionTitle>ผลคำนวณล่าสุด · Engine {result.engineVersion}</SectionTitle>
      <Card style={{ backgroundColor: COLORS.navy, borderColor: COLORS.navy }}>
        <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 8 }}>
          <ResultStat value={formatArea(result.glassAreaSqft, store.settings.areaUnit)} label="พื้นที่กระจกจริง" />
          <ResultStat value={formatArea(result.freshAreaSqft, store.settings.areaUnit)} label="พื้นที่ฟิล์มใหม่ (ดึงจริง)" />
          <ResultStat value={`${result.rollPulls} ครั้ง`} label="ดึงฟิล์ม" />
        </View>
        <View style={{ borderTopWidth: 1, borderTopColor: "#FFFFFF20", marginTop: 15, paddingTop: 13, flexDirection: "row", justifyContent: "space-between" }}>
          <Text style={{ color: "#BFD2E6", fontSize: 11 }}>ม้วนที่ใช้ {result.requiredRolls} · รอยต่อ {result.totalSeams}</Text>
          <Text style={{ color: COLORS.lime, fontSize: 12, fontWeight: "900" }}>{result.quoteAreaSqft} ตร.ฟุตเสนอราคา</Text>
        </View>
        <Text style={{ color: "#BFD2E6", fontSize: 10, marginTop: 10 }}>การค้นหาแผนเป็น deterministic heuristic แบบมีขอบเขต ไม่ใช่การพิสูจน์ optimum ทางคณิตศาสตร์</Text>
      </Card>

      <SectionTitle>การใช้ม้วนจริง</SectionTitle>
      {result.rollUsage.map((usage) => <Card key={usage.roll_id} style={{ marginBottom: 8, padding: 13 }}>
        <Text style={{ color: COLORS.ink, fontWeight: "900" }}>{usage.label} · {usage.width_cm} × {usage.length_cm} ซม.</Text>
        <Text style={{ color: COLORS.muted, fontSize: 11, marginTop: 4 }}>บาน {usage.pane_indices.join(", ") || "—"} · ดึง {usage.pulls} ครั้ง · รอยต่อ {usage.seams}</Text>
        <Text style={{ color: COLORS.ink, fontSize: 12, marginTop: 6 }}>ความยาวดึง {usage.fresh_pull_cm.toFixed(1)} ซม. · เหลือปลายม้วน {usage.length_remaining_cm.toFixed(1)} ซม.</Text>
      </Card>)}

      <SectionTitle>แผนตัดรายบาน</SectionTitle>
      {result.planSnapshot.engine.panes.map((pane) => <Card key={`pane-${pane.index}`} style={{ marginBottom: 8, padding: 13 }}>
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <View style={{ width: 31, height: 31, borderRadius: 9, backgroundColor: COLORS.cyanSoft, alignItems: "center", justifyContent: "center", marginRight: 9 }}><Text style={{ color: "#0A6B93", fontWeight: "900" }}>{pane.index}</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: COLORS.ink, fontWeight: "900" }}>บาน {pane.index} · {pane.actual_width_cm} × {pane.actual_height_cm} ซม.</Text>
            <Text style={{ color: COLORS.muted, fontSize: 11, marginTop: 3 }}>ขนาดตัดหลังปัด {pane.afterW} × {pane.afterH} ซม. · จำนวน {pane.qty} · แนว {pane.dir}</Text>
            <Text style={{ color: COLORS.muted, fontSize: 11, marginTop: 2 }}>{pane.roll_label ?? pane.roll_id ?? "ไม่ระบุม้วน"} · {pane.pieces ?? pane.cutPieces?.length ?? 0} ชิ้น · {pane.seams ?? 0} รอยต่อ</Text>
          </View>
        </View>
        {(pane.cutPieces ?? []).map((piece) => <View key={piece.piece_id} style={{ borderTopWidth: 1, borderTopColor: COLORS.line, paddingTop: 8, marginTop: 8 }}>
          <Text style={{ color: COLORS.ink, fontSize: 11, fontWeight: "800" }}>ชิ้น #{piece.sequence} · {piece.cut_width_cm} × {piece.cut_length_cm} ซม. · แนว {piece.orientation}{piece.rotated ? " · หมุน 90°" : ""}</Text>
          <Text style={{ color: COLORS.muted, fontSize: 11, marginTop: 2 }}>{piece.source === "fresh" ? `ดึงจากหน้าฟิล์มเต็ม ${result.physicalRolls.find((roll) => roll.id === piece.roll_id)?.width_cm ?? product?.rollWidthCm ?? "—"} ซม. · ครั้งที่ ${piece.pull_no ?? "—"}` : `ใช้เศษฟิล์ม · ${piece.scrap_id ?? "ระบุที่มาในแผน"}`}</Text>
          {(piece.created_scraps ?? []).map((scrap) => <Text key={scrap.id} style={{ color: "#9A6C16", fontSize: 10, marginTop: 2 }}>เกิดเศษ {scrap.width_cm} × {scrap.height_cm} ซม. · {(scrap.reusable ? "เก็บใช้ต่อได้" : "ไม่ผ่านเกณฑ์เก็บ")}</Text>)}
        </View>)}
      </Card>)}

      <SectionTitle>เศษฟิล์มคงเหลือหลังวางแผน</SectionTitle>
      {result.scraps.length ? result.scraps.map((scrap) => <Card key={scrap.id} style={{ marginBottom: 7, padding: 12 }}>
        <Text style={{ color: COLORS.ink, fontWeight: "900" }}>{scrap.widthCm} × {scrap.heightCm} ซม. · {scrap.reusable ? "เข้าเกณฑ์เก็บเศษ" : "ไม่ผ่านเกณฑ์เก็บ"}</Text>
        <Text style={{ color: COLORS.muted, fontSize: 11, marginTop: 3 }}>{scrap.fromLabel} · {scrap.rollLabel ?? scrap.rollId ?? "ม้วนไม่ระบุ"} · {scrap.statusNote ?? ""}</Text>
      </Card>) : <Card><Text style={{ color: COLORS.muted, fontSize: 12 }}>ไม่มีเศษคงเหลือใน snapshot นี้</Text></Card>}
      <Text style={{ color: COLORS.muted, fontSize: 10, lineHeight: 16 }}>เศษเหล่านี้เป็นผลคงเหลือในแผนงานนี้ ยังไม่ได้ถูกบันทึกเป็นคลังเศษกลางข้ามงานหรือซิงก์ข้ามอุปกรณ์</Text>

      <Card style={{ marginTop: 9, backgroundColor: result.orientationStatus === "pass" ? "#EAF9EE" : result.orientationStatus === "block" ? "#FFF0F0" : "#FFF8EA", borderColor: result.orientationStatus === "pass" ? "#A9D9B5" : result.orientationStatus === "block" ? "#F4CACA" : "#F4D59A" }}>
        <Text style={{ color: result.orientationStatus === "pass" ? "#218544" : result.orientationStatus === "block" ? COLORS.red : "#8C6218", fontWeight: "900", marginBottom: 6 }}>สถานะข้อกำหนดวัสดุ: {result.orientationStatus.toUpperCase()}</Text>
        {result.warnings.length ? result.warnings.map((warning, i) => <Text key={`${i}-${warning}`} style={{ color: result.orientationStatus === "block" ? COLORS.red : "#8C6218", fontSize: 11, lineHeight: 18 }}>• {warning}</Text>) : <Text style={{ color: "#218544", fontSize: 11 }}>ไม่มีคำเตือนจากเอนจิน</Text>}
        {result.orientationStatus !== "pass" ? <Text style={{ color: "#8C6218", fontSize: 11, fontWeight: "800", marginTop: 8 }}>REVIEW ไม่เท่ากับ PASS และยังไม่อนุญาตให้สั่งตัดจริง</Text> : null}
      </Card>

      <SectionTitle>ใบเสนอราคา (คำนวณจาก snapshot นี้)</SectionTitle>
      <Card>
        <Text style={{ color: COLORS.muted, fontSize: 12, lineHeight: 19 }}>ใช้พื้นที่เสนอราคา {result.quoteAreaSqft} ตร.ฟุต จากฟิล์มใหม่ที่ดึงจากม้วนรวมทั้งงาน + บัฟเฟอร์คงที่ 2 ตร.ฟุต แล้วปัดขึ้นครั้งเดียวตามกฎต้นฉบับ ไม่ใช่พื้นที่กระจกจริง</Text>
        <View style={{ flexDirection: "row", gap: 9, marginTop: 12 }}><View style={{ flex: 1 }}><Field label="ค่าเดินทาง" keyboardType="decimal-pad" value={travelFee} onChangeText={setTravelFee} placeholder="฿" /></View><View style={{ flex: 1 }}><Field label="ค่านั่งร้าน" keyboardType="decimal-pad" value={scaffoldFee} onChangeText={setScaffoldFee} placeholder="฿" /></View></View>
        <View style={{ flexDirection: "row", gap: 9 }}><View style={{ flex: 1 }}><Field label="ลอกฟิล์มเก่า" keyboardType="decimal-pad" value={removalFee} onChangeText={setRemovalFee} placeholder="฿" /></View><View style={{ flex: 1 }}><Field label="ส่วนลด" keyboardType="decimal-pad" value={discount} onChangeText={setDiscount} placeholder="฿" /></View></View>
        <Text style={{ color: COLORS.ink, fontWeight: "800", fontSize: 13, marginBottom: 7 }}>ภาษี</Text>
        <View style={{ flexDirection: "row", gap: 7 }}>{(["not_applicable", "exclusive", "inclusive"] as const).map((tax) => <Pressable key={tax} onPress={() => setTaxTreatment(tax)} style={{ flex: 1, paddingVertical: 9, borderWidth: 1, borderRadius: 9, borderColor: taxTreatment === tax ? COLORS.cyan : COLORS.line, backgroundColor: taxTreatment === tax ? COLORS.cyanSoft : COLORS.white, alignItems: "center" }}><Text style={{ fontSize: 11, color: COLORS.ink, fontWeight: "800" }}>{tax === "not_applicable" ? "ไม่ใช้ VAT" : tax === "exclusive" ? "VAT แยก" : "VAT รวม"}</Text></Pressable>)}</View>
        {product?.priceStatus !== "active" || !((product?.pricePerSqft ?? 0) > 0) ? <Text style={{ color: "#8C6218", fontSize: 11, lineHeight: 17, marginTop: 9 }}>ราคาของ SKU นี้ยังไม่พร้อมจาก C6 ระบบจะยังไม่สรุปยอดเงินจนกว่าจะมีราคาที่ตรวจยืนยันแล้ว</Text> : null}
        {existing?.quote ? <View style={{ backgroundColor: COLORS.paper, borderRadius: 12, padding: 12, marginTop: 12 }}><Text style={{ color: COLORS.ink, fontWeight: "900" }}>{existing.quote.quoteNumber}</Text><Text style={{ color: COLORS.muted, fontSize: 12, marginTop: 3 }}>{existing.quote.total == null ? "รอทบทวนราคา" : `ยอดรวม ฿${existing.quote.total.toLocaleString()}`}</Text></View> : null}
      </Card>
    </> : null}

    {existing ? <><SectionTitle>เช็กลิสต์หน้างาน</SectionTitle><Card>{([ ["inspect", "ตรวจสภาพกระจก"], ["surface", "เตรียมพื้นผิว"], ["install", "ติดตั้งตามคู่มือรุ่น"], ["handover", "ตรวจงานและส่งมอบ"] ] as const).map(([key, label]) => <Pressable key={key} onPress={() => toggleCheck(key)} style={{ flexDirection: "row", alignItems: "center", paddingVertical: 10, borderBottomWidth: key === "handover" ? 0 : 1, borderBottomColor: COLORS.line }}><View style={{ width: 25, height: 25, borderRadius: 8, backgroundColor: existing.checklist[key] ? COLORS.lime : COLORS.paper, borderWidth: 1, borderColor: existing.checklist[key] ? COLORS.lime : COLORS.line, alignItems: "center", justifyContent: "center", marginRight: 10 }}>{existing.checklist[key] ? <Feather name="check" size={15} color={COLORS.navy} /> : null}</View><Text style={{ color: COLORS.ink, fontWeight: "700" }}>{label}</Text></Pressable>)}</Card></> : null}

    {existing?.calculation ? <View style={{ flexDirection: "row", gap: 9, marginTop: 14 }}>
      <Button icon="file-text" variant="secondary" style={{ flex: 1 }} onPress={() => exportDoc("quote")}>PDF ใบเสนอราคา</Button>
      <Button icon="clipboard" variant="secondary" style={{ flex: 1 }} onPress={() => exportDoc("order")}>PDF ใบสั่งงานช่าง</Button>
    </View> : null}
    <View style={{ gap: 9, marginTop: 18 }}>
      <Button icon="save" onPress={saveJob}>บันทึกงาน{result ? "และ snapshot แผนล่าสุด" : ""}</Button>
      {existing ? <Button icon={existing.status === "closed" ? "check-circle" : "arrow-right-circle"} variant="secondary" onPress={advance}>{existing.status === "closed" ? "งานปิดแล้ว" : `ไปสถานะถัดไป: ${JOB_STATUS_LABEL[nextStatus(existing.status)]}`}</Button> : null}
    </View>
    {savedMessage ? <Text style={{ textAlign: "center", color: "#2D8E54", fontWeight: "800", fontSize: 12, marginTop: 11 }}>{savedMessage}</Text> : null}
  </Page>;
}

function ResultStat({ value, label }: { value: string; label: string }) {
  return <View style={{ flex: 1 }}><Text style={{ color: COLORS.white, fontWeight: "900", fontSize: 15 }}>{value}</Text><Text style={{ color: "#9EBBD3", fontSize: 10, marginTop: 4 }}>{label}</Text></View>;
}
