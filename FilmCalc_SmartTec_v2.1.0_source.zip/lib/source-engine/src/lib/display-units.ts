import { convertArea, convertLength, type AreaUnit, type LengthUnit } from "../domain/unit-conversion.ts";

let activeAreaUnit: AreaUnit = "sqft";
let activeDimensionUnit: LengthUnit = "cm";

export function setActiveAreaUnit(unit: AreaUnit | string | undefined): void {
  activeAreaUnit = unit === "m2" || unit === "cm2" || unit === "in2" ? unit : "sqft";
}

export function getActiveAreaUnit(): AreaUnit {
  return activeAreaUnit;
}

export function convertSqftForDisplay(valueSqft: number): number {
  return convertArea(Number.isFinite(valueSqft) ? Math.max(0, valueSqft) : 0, "sqft", activeAreaUnit);
}

export function activeAreaUnitLabel(): string {
  return activeAreaUnit === "m2" ? "ตร.ม." : activeAreaUnit === "cm2" ? "ตร.ซม." : activeAreaUnit === "in2" ? "ตร.นิ้ว" : "ตร.ฟุต";
}

export function setActiveDimensionUnit(unit: LengthUnit | string | undefined): void {
  activeDimensionUnit = unit === "mm" || unit === "m" || unit === "in" || unit === "ft" ? unit : "cm";
}

export function getActiveDimensionUnit(): LengthUnit {
  return activeDimensionUnit;
}

export function convertCmForDisplay(valueCm: number): number {
  return convertLength(Number.isFinite(valueCm) ? Math.max(0, valueCm) : 0, "cm", activeDimensionUnit);
}

export function activeDimensionUnitLabel(): string {
  return activeDimensionUnit === "mm" ? "มม." : activeDimensionUnit === "m" ? "ม." : activeDimensionUnit === "in" ? "นิ้ว" : activeDimensionUnit === "ft" ? "ฟุต" : "ซม.";
}
