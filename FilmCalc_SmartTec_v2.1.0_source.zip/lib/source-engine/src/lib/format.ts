import { activeAreaUnitLabel, convertSqftForDisplay, getActiveAreaUnit, activeDimensionUnitLabel, convertCmForDisplay } from "./display-units.ts";

const bahtFmt = new Intl.NumberFormat("th-TH", {
  style: "currency",
  currency: "THB",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const numFmt = new Intl.NumberFormat("th-TH", {
  maximumFractionDigits: 2,
});

const intFmt = new Intl.NumberFormat("th-TH", { maximumFractionDigits: 0 });
export function formatBaht(value: number): string {
  return bahtFmt.format(Number.isFinite(value) ? value : 0);
}

export function formatSqft(value: number): string {
  const converted = convertSqftForDisplay(value);
  const display = getActiveAreaUnit() === "sqft" ? intFmt.format(Math.round(converted)) : new Intl.NumberFormat("th-TH", { maximumFractionDigits: 2 }).format(converted);
  return `${display} ${activeAreaUnitLabel()}`;
}

/** Customer quotation uses the same square-foot basis as the C6 price rate, regardless of display-unit preference. */
export function formatSqftBillable(value: number): string {
  const safe = Number.isFinite(value) ? Math.max(0, value) : 0;
  const display = new Intl.NumberFormat("th-TH", { maximumFractionDigits: 2, minimumFractionDigits: 0 }).format(safe);
  return `${display} ตร.ฟุต`;
}

/** Format canonical square feet in the configured display unit without rounding the calculation source. */
export function formatSqftPrecise(value: number): string {
  const safe = convertSqftForDisplay(Number.isFinite(value) ? value : 0);
  const digits = getActiveAreaUnit() === "sqft" ? 2 : getActiveAreaUnit() === "cm2" ? 0 : 3;
  return `${new Intl.NumberFormat("th-TH", { maximumFractionDigits: digits, minimumFractionDigits: 0 }).format(safe)} ${activeAreaUnitLabel()}`;
}

export function formatNumber(value: number, digits = 0): string {
  if (!Number.isFinite(value)) return "0";
  return new Intl.NumberFormat("th-TH", {
    maximumFractionDigits: digits,
    minimumFractionDigits: digits,
  }).format(value);
}

export function formatCm(value: number): string {
  return `${new Intl.NumberFormat("th-TH", { maximumFractionDigits: 3 }).format(convertCmForDisplay(value))} ${activeDimensionUnitLabel()}`;
}

export function formatWhen(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return new Intl.DateTimeFormat("th-TH", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(d);
}

export function newId(): string {
  return crypto.randomUUID();
}
