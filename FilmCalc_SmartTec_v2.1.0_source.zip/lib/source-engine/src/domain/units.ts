/** หน่วยมาตรฐานที่ใช้ร่วมกันทั้งระบบ: 1 ตารางฟุต = 929.0304 ตารางเซนติเมตร */
export const CM2_PER_SQFT = 929.0304;

/** ปัดขนาดตัดขึ้นเป็นเซนติเมตรเต็มแบบเดียวกันทุกเส้นทางคำนวณ */
export function ceilDimensionCm(value: number): number {
  return Number.isFinite(value) && value > 0 ? Math.ceil(value - 1e-12) : 0;
}

/** แปลงพื้นที่ตารางเซนติเมตรเป็นตารางฟุตโดยไม่ปัดระหว่างทาง */
export function cm2ToSqft(cm2: number): number {
  return Number.isFinite(cm2) && cm2 > 0 ? cm2 / CM2_PER_SQFT : 0;
}

/** แปลงพื้นที่ตารางฟุตเป็นตารางเซนติเมตร */
export function sqftToCm2(sqft: number): number {
  return Number.isFinite(sqft) && sqft > 0 ? sqft * CM2_PER_SQFT : 0;
}
