/** Mobile build type shim: quote documents are stored by the app layer. */
export interface QuotationSnapshot { [key: string]: unknown }
