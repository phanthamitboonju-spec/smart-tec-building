/**
 * Calculation Service — SINGLE entry for UI / Chat / Server.
 * No second formula set. Always delegates to film-engine.calculateJob.
 * Enriches result with global scrap pool + face orientation metadata.
 */

import { calculateJob, getConfig, normalizeEngineConfig, type EngineConfig, type EngineScrapInput, type JobCalcResult } from "../engine/film-engine.ts";
import { SYSTEM_VERSION } from "../version.ts";
import { ceilDimensionCm } from "./units.ts";
import { ceilQuoteSqft } from "./area-analysis.ts";
import { findProductByCode, PRODUCTS } from "../data/products.ts";
import { CM2_PER_SQFT } from "./units.ts";
import type { MaterialOrientationSpec } from "./material-orientation.ts";
import {
  canJoinPieces,
  type FilmFace,
  type ScrapPiece,
  type GlobalScrapResult,
} from "./global-scrap-pool.ts";

export interface CalcPaneInput {
  id?: string;
  /** Resolved whole-job family key (same geometry + same material contract). */
  familyId?: string;
  /** Total number of physical panes in this family across the whole job. */
  familyCount?: number;
  label?: string;
  /** Optional physical roll ID selected by the user; only used in multi-roll mode. */
  rollId?: string;
  width_cm: number;
  height_cm: number;
  /** Original measured dimensions; cutting dimensions are rounded up separately. */
  raw_width_cm?: number;
  raw_height_cm?: number;
  qty?: number;
  dir?: "auto" | "V" | "H" | string;
  /** Joined-film face orientation */
  face?: FilmFace;
  /** Verified material constraints for the selected SKU/roll/lot, if known. */
  material?: Partial<MaterialOrientationSpec>;
}

export interface CanonicalCalcResult {
  source: "film-engine";
  engine: JobCalcResult;
  global_scrap: GlobalScrapResult;
  panes: CalcPaneInput[];
  install_sqft: number;
  face_sqft: number;
  saved_sqft: number;
  /** Exact raw glass area before display rounding. */
  glass_area_raw_sqft: number;
  /** Raw material drawn from rolls before whole-square-foot rounding. */
  fresh_raw_sqft: number;
  /** Precomputed customer quote area = job fresh-roll area + fixed 2 sqft, rounded once. */
  quote_area_sqft?: number;
  /** Total rough-cut area of every pane piece, including pieces supplied by offcuts. */
  cut_area_raw_sqft: number;
  version: string;
}

/**
 * Explicit four-area breakdown (SSOT).
 * Downstream code (quotation, work-order, UI, reports) must use this helper
 * instead of picking fields ad-hoc so the four area types cannot be mixed.
 */
export interface AreaBreakdown {
  glass_raw_sqft: number;
  cut_raw_sqft: number;
  fresh_raw_sqft: number;
  quote_sqft: number;
  install_sqft: number;
  face_sqft: number;
  saved_sqft: number;
}

export function getAreaBreakdown(result: CanonicalCalcResult | null | undefined): AreaBreakdown {
  if (!result) {
    return { glass_raw_sqft: 0, cut_raw_sqft: 0, fresh_raw_sqft: 0, quote_sqft: 0, install_sqft: 0, face_sqft: 0, saved_sqft: 0 };
  }
  const n = (v: unknown) => { const x = Number(v); return Number.isFinite(x) && x > 0 ? x : 0; };
  return {
    glass_raw_sqft: n(result.glass_area_raw_sqft),
    cut_raw_sqft: n(result.cut_area_raw_sqft),
    fresh_raw_sqft: n(result.fresh_raw_sqft),
    quote_sqft: n(result.quote_area_sqft),
    install_sqft: n(result.install_sqft),
    face_sqft: n(result.face_sqft),
    saved_sqft: n(result.saved_sqft),
  };
}

export function validateAreaBreakdown(areas: AreaBreakdown): string | null {
  if (areas.quote_sqft > 0 && areas.fresh_raw_sqft > 0 && areas.quote_sqft + 1e-9 < areas.fresh_raw_sqft) {
    return "quote_sqft must not be smaller than fresh_raw_sqft";
  }
  if (areas.glass_raw_sqft < 0 || areas.cut_raw_sqft < 0 || areas.fresh_raw_sqft < 0 || areas.quote_sqft < 0) {
    return "area values must not be negative";
  }
  return null;
}

function asFace(v: unknown): FilmFace {
  if (v === "A" || v === "B") return v;
  return "unknown";
}


/**
 * Assign Pane Family identities across the complete input list before any roll grouping.
 * The key intentionally excludes the physical roll ID: a single-sheet offcut may move
 * across rolls only when the SKU's reuse policy permits it. Spliced panels are checked
 * separately under the stricter same-roll/lot/direction seam contract.
 */
export function assignPaneFamilyMetadata(
  panes: CalcPaneInput[],
  fallbackMaterial?: Partial<MaterialOrientationSpec>,
): CalcPaneInput[] {
  const keys = panes.map((pane, index) => {
    const width = ceilDimensionCm(Number(pane.width_cm));
    const height = ceilDimensionCm(Number(pane.height_cm));
    const material = { ...(fallbackMaterial ?? {}), ...(pane.material ?? {}) };
    const identity = {
      explicit: String(pane.familyId ?? "").trim() || undefined,
      width,
      height,
      sku: String(material.sku ?? "").trim(),
      lot: String(material.lotId ?? "").trim(),
      face: asFace(pane.face),
      materialFace: material.face ?? "unknown",
      policy: material.policy ?? "unknown",
      direction: String(material.directionKey ?? "").trim(),
      rotations: Array.isArray(material.allowedRotations) ? [...material.allowedRotations].sort((a, b) => a - b) : [],
      dir: pane.dir === "V" || pane.dir === "H" ? pane.dir : "auto",
    };
    return Number.isFinite(width) && Number.isFinite(height) && width > 0 && height > 0
      ? JSON.stringify(identity)
      : `blank:${index}`;
  });
  const counts = new Map<string, number>();
  panes.forEach((pane, index) => {
    const qty = Number(pane.qty ?? 1);
    if (keys[index].startsWith("blank:")) return;
    if (!Number.isInteger(qty) || qty < 1) return;
    counts.set(keys[index], (counts.get(keys[index]) ?? 0) + qty);
  });
  return panes.map((pane, index) => ({
    ...pane,
    familyId: keys[index],
    familyCount: Math.max(Number(pane.familyCount ?? 0), counts.get(keys[index]) ?? 1),
  }));
}

/**
 * The only calculation function application code should call.
 */
export function runCalculation(
  panes: CalcPaneInput[],
  config?: Partial<EngineConfig>,
  materialOverride?: Partial<MaterialOrientationSpec>,
  options?: { initialScraps?: EngineScrapInput[] },
): CanonicalCalcResult {
  const input = Array.isArray(panes) ? panes : [];
  const normalizedPanes = input.map((pane, index) => {
    const width = Number(pane?.width_cm);
    const height = Number(pane?.height_cm);
    const widthCm = ceilDimensionCm(width);
    const heightCm = ceilDimensionCm(height);
    const qtyRaw = pane?.qty == null ? 1 : Number(pane.qty);
    const fail = (message: string): never => {
      const error = new Error(`บาน ${index + 1}: ${message}`) as Error & { code?: string };
      error.code = "VALIDATION_FAILED";
      throw error;
    };
    if (!Number.isFinite(width) || !Number.isFinite(height)) {
      return fail("กรุณาระบุความกว้างและความสูงเป็นตัวเลขที่ถูกต้อง");
    }
    if (width < 0 || height < 0) return fail("ขนาดบานต้องไม่ติดลบ");
    // Ignore an untouched row only when both dimensions are exactly zero.
    // Negative/sub-centimeter values must never be mistaken for a blank row.
    if (width === 0 && height === 0) {
      return { ...pane, width_cm: 0, height_cm: 0, raw_width_cm: 0, raw_height_cm: 0, qty: 1, dir: "auto", material: undefined };
    }
    if (width <= 0 || height <= 0) {
      return fail("กรุณาระบุทั้งความกว้างและความสูงเป็นตัวเลขที่มากกว่า 0");
    }
    if (widthCm >= 1000 || heightCm >= 1000) return fail("ขนาดบานหลังปัดขึ้นต้องน้อยกว่า 1,000 ซม.");
    if (!Number.isFinite(qtyRaw) || !Number.isInteger(qtyRaw) || qtyRaw < 1 || qtyRaw > 500) {
      return fail("จำนวนบานต้องเป็นจำนวนเต็มตั้งแต่ 1 ถึง 500");
    }
    const material = {
      ...(config?.materialOrientation ?? {}),
      ...(materialOverride ?? {}),
      ...(pane.material ?? {}),
    };
    return {
      ...pane,
      // Keep measured values intact. The engine separately rounds only the rough-cut dimensions.
      width_cm: width,
      height_cm: height,
      raw_width_cm: width,
      raw_height_cm: height,
      qty: qtyRaw,
      dir: pane.dir === "V" || pane.dir === "H" ? pane.dir : "auto",
      material: Object.keys(material).length ? material : undefined,
    };
  });
  const panesWithFamilies = assignPaneFamilyMetadata(normalizedPanes, {
    ...(config?.materialOrientation ?? {}),
    ...(materialOverride ?? {}),
  });
  // The app release is authoritative: a stale database/config version cannot
  // silently produce a result tagged as an older calculation engine.
  const effectiveConfig: Partial<EngineConfig> = { ...(config ?? {}), version: SYSTEM_VERSION };
  const resolvedConfig = normalizeEngineConfig(effectiveConfig, getConfig());
  for (const [index, pane] of panesWithFamilies.entries()) {
    if (!(pane.width_cm > 0 && pane.height_cm > 0)) continue;
    const w = ceilDimensionCm(Number(pane.width_cm)) + 2 * Number(resolvedConfig.margin ?? 2);
    const h = ceilDimensionCm(Number(pane.height_cm)) + 2 * Number(resolvedConfig.margin ?? 2);
    // Validate geometric feasibility for every direction the whole-job optimizer may test.
    // SKU orientation metadata is reported as REVIEW after planning; it does not block auto mode.
    const requestedDirection = pane.dir === "V" || pane.dir === "H" ? pane.dir : undefined;
    const allowed = requestedDirection ? [requestedDirection] : ["V", "H"];
    const candidates = allowed.filter((direction) => (direction === "V" ? h : w) <= Number(resolvedConfig.rollLen ?? 3000) + 1e-9);
    if (!candidates.length) {
      const error = new Error(`บาน ${index + 1}: ความยาวหลังเผื่อตัดเกินความยาวม้วน หรือแนวฟิล์มที่อนุญาตใช้ไม่ได้ กรุณาตรวจขนาดและการตั้งค่าม้วน`) as Error & { code?: string };
      error.code = "VALIDATION_FAILED";
      throw error;
    }
  }
  return toCanonicalResult(calculateJob(panesWithFamilies, effectiveConfig, options?.initialScraps ?? []), panesWithFamilies);
}

/**
 * Wrap an engine result in the canonical shape without recalculating.
 * Used for both fresh runs and for re-displaying a saved job without rerunning the plan.
 */
export function toCanonicalResult(engine: JobCalcResult, panes: CalcPaneInput[]): CanonicalCalcResult {
  const cfg = getConfig();

  const pool: ScrapPiece[] = (engine.finalScraps || []).map((s, i) => ({
    id: s.id || `scrap-${i}`,
    width_cm: Number(s.width_cm ?? s.w ?? 0),
    height_cm: Number(s.height_cm ?? s.h ?? 0),
    face: asFace(s.face),
    from_pane_id: String(s.pane_id ?? s.from ?? i),
    from_unit: String(s.uid ?? i),
    used: false,
    material: s.material,
  }));

  const assignmentsFromEngine = (engine.panes || []).flatMap((p) =>
    (p.scrapSources || []).map((src) => ({
      scrap_id: src.scrap_id,
      consumer_pane_id: String(p.index),
      consumer_unit: String(p.index),
      scrap_width_cm: src.w,
      scrap_height_cm: src.h,
      face: asFace(src.face),
    })),
  );

  // The engine already did the matching (single source of truth); the pool here is
  // exactly the scrap left at job end, so report it as-is instead of re-running a matcher.
  const global_scrap: GlobalScrapResult = {
    assignments: assignmentsFromEngine,
    remaining: pool,
    reused_count: assignmentsFromEngine.length,
    remaining_count: pool.length,
    remaining_cm2: pool.reduce((sum, s) => sum + s.width_cm * s.height_cm, 0),
  };

  const cutAreaCm2 = (engine.panes ?? []).reduce(
    (sum, pane) => sum + (pane.cutPieces ?? []).reduce((subtotal, piece) => subtotal + piece.cut_width_cm * piece.cut_length_cm, 0),
    0,
  );
  return {
    source: "film-engine",
    engine,
    global_scrap,
    panes,
    install_sqft: Number(engine.summary?.install_sqft ?? engine.installAreaSqft ?? 0),
    face_sqft: Number(engine.summary?.face_sqft ?? 0),
    saved_sqft: Number(engine.summary?.saved_sqft ?? 0),
    glass_area_raw_sqft: Number(engine.summary?.glass_raw_sqft ?? (Number(engine.glassAreaCm2 ?? 0) / CM2_PER_SQFT)),
    fresh_raw_sqft: Number(engine.summary?.fresh_raw_sqft ?? 0),
    quote_area_sqft: ceilQuoteSqft(Number(engine.summary?.fresh_raw_sqft ?? 0), Number(engine.config?.quoteBufferPct ?? 2)),
    cut_area_raw_sqft: cutAreaCm2 / CM2_PER_SQFT,
    version: String(engine.version ?? cfg.version ?? SYSTEM_VERSION),
  };
}


/**
 * Resolve selected C6 SKU identity into the shared engine's material metadata.
 * Catalog entries without verified orientation/face/lot facts deliberately remain REVIEW;
 * this helper never invents manufacturer constraints from a marketing name.
 */
export function materialSpecForSku(
  sku?: string | null,
  brandKey?: string | null,
): Partial<MaterialOrientationSpec> | undefined {
  const code = String(sku ?? "").trim();
  if (!code) return undefined;
  const product = findProductByCode(code, PRODUCTS, String(brandKey ?? "").trim() || undefined);
  if (!product || product.selectable === false || product.identifierKind === "reference") return undefined;
  return {
    sku: `${product.brandKey}:${product.codeNorm}`,
    policy: "unknown",
    face: "unknown",
    factoryEdge: "unknown",
  };
}

/** Rebuild a canonical result from a persisted `job.plan`; null if the stored JSON is not an engine result. */
export function canonicalFromStoredPlan(plan: unknown, panes: CalcPaneInput[]): CanonicalCalcResult | null {
  const p = plan as Partial<JobCalcResult> | null;
  if (!p || typeof p !== "object" || !p.summary || !Array.isArray(p.panes)) return null;
  // A saved plan from another release is never treated as the current engine result.
  if (String(p.version ?? "") !== SYSTEM_VERSION || String(p.config?.version ?? "") !== SYSTEM_VERSION) return null;
  const inputs = Array.isArray(panes) ? panes : [];
  const planned = p.panes as JobCalcResult["panes"];
  const validInputs = inputs.filter((pane) => Number(pane?.width_cm) > 0 && Number(pane?.height_cm) > 0);
  if (planned.length !== validInputs.length) return null;
  for (const row of planned) {
    const input = inputs[Number(row.index) - 1];
    if (!input) return null;
    if (ceilDimensionCm(Number(input.width_cm)) !== Number(row.width_cm) || ceilDimensionCm(Number(input.height_cm)) !== Number(row.height_cm)) return null;
    if (Math.abs(Number(input.width_cm) - Number((row as { actual_width_cm?: number }).actual_width_cm ?? input.width_cm)) > 1e-7) return null;
    if (Math.abs(Number(input.height_cm) - Number((row as { actual_height_cm?: number }).actual_height_cm ?? input.height_cm)) > 1e-7) return null;
    if (Number(input.qty ?? 1) !== Number(row.qty ?? 1)) return null;
    if (!Array.isArray(row.cutPieces)) return null;
  }
  return toCanonicalResult(
    { ...p, finalScraps: Array.isArray(p.finalScraps) ? p.finalScraps : [] } as JobCalcResult,
    inputs,
  );
}

export function assertSameFaceJoin(a: FilmFace, b: FilmFace): boolean {
  return canJoinPieces({ face: a }, { face: b }, false);
}

export { getConfig };
