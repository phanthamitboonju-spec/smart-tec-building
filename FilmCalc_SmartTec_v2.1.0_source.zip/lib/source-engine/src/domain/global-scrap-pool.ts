/**
 * Global Scrap Pool — work-wide scrap reuse (not sequential pane-only).
 * Pairings are evaluated globally; order is not forced left-to-right.
 */

import { checkSpliceCompatibility, type MaterialOrientationSpec } from "./material-orientation.ts";

export type FilmFace = "A" | "B" | "unknown";

/** Geometry/material prefilter for the project-wide stock allocator. */
export interface GlobalScrap {
  id: string;
  widthCm: number;
  lengthCm: number;
  material?: string;
  /** Legacy metadata retained for compatibility; Auto whole-job planning does not use it as a rotation prefilter. */
  rotationAllowed: boolean;
  face?: FilmFace;
  lotId?: string;
  rollId?: string;
  status?: "AVAILABLE" | "RESERVED" | "USED" | "QUARANTINE" | "WASTE";
}

export interface ScrapPiece {
  id: string;
  width_cm: number;
  height_cm: number;
  face: FilmFace;
  from_pane_id: string;
  from_unit: string;
  used: boolean;
  /** Optional verified material provenance used to validate scrap rotation. */
  material?: Partial<MaterialOrientationSpec>;
  used_by_pane_id?: string;
  used_by_unit?: string;
}

export interface FreshPull {
  unit_id: string;
  pane_id: string;
  width_cm: number;
  height_cm: number;
  face: FilmFace;
  leftover?: ScrapPiece;
}

export interface ScrapAssignment {
  scrap_id: string;
  consumer_pane_id: string;
  consumer_unit: string;
  scrap_width_cm: number;
  scrap_height_cm: number;
  face: FilmFace;
}

export interface GlobalScrapResult {
  assignments: ScrapAssignment[];
  remaining: ScrapPiece[];
  reused_count: number;
  remaining_count: number;
  remaining_cm2: number;
}

export function canFit(scrap: GlobalScrap, needW: number, needH: number, consumerSku: string): boolean;
export function canFit(scrap: ScrapPiece, needW: number, needH: number, requireSameFace?: boolean, consumerFace?: FilmFace): boolean;
export function canFit(
  scrap: GlobalScrap | ScrapPiece,
  needW: number,
  needH: number,
  fourth: string | boolean = true,
  consumerFace: FilmFace = "unknown",
): boolean {
  if (!Number.isFinite(needW) || !Number.isFinite(needH) || needW <= 0 || needH <= 0) return false;
  if ("widthCm" in scrap) {
    const consumerSku = typeof fourth === "string" ? fourth : "";
    if (scrap.status && scrap.status !== "AVAILABLE") return false;
    if (!scrap.material || !consumerSku || scrap.material !== consumerSku) return false;
    if (!Number.isFinite(scrap.widthCm) || !Number.isFinite(scrap.lengthCm) || scrap.widthCm <= 0 || scrap.lengthCm <= 0) return false;
    const direct = scrap.widthCm + 1e-9 >= needW && scrap.lengthCm + 1e-9 >= needH;
    const rotated = scrap.widthCm + 1e-9 >= needH && scrap.lengthCm + 1e-9 >= needW;
    return direct || rotated;
  }
  if (scrap.used || !Number.isFinite(scrap.width_cm) || !Number.isFinite(scrap.height_cm) || scrap.width_cm <= 0 || scrap.height_cm <= 0) return false;
  const directFit = scrap.width_cm + 1e-9 >= needW && scrap.height_cm + 1e-9 >= needH;
  const rotatedFit = scrap.width_cm + 1e-9 >= needH && scrap.height_cm + 1e-9 >= needW;
  // The fourth argument controls only whether the face must match; it must never disable
  // whole-job quarter-turn candidates. The committed engine emits a REVIEW warning if a
  // rotated offcut is selected. SKU/face/Lot/Roll compatibility is handled independently.
  if (!directFit && !rotatedFit) return false;
  const requireSameFace = fourth !== false;
  if (requireSameFace && scrap.face !== "unknown" && consumerFace !== "unknown" && scrap.face !== consumerFace) return false;
  return true;
}

export function getGlobalScrapCandidates(
  pool: GlobalScrap[],
  needW: number,
  needH: number,
  consumerSku?: string,
): GlobalScrap[] {
  if (!Array.isArray(pool) || !Number.isFinite(needW) || !Number.isFinite(needH) || needW <= 0 || needH <= 0) return [];
  return pool
    .filter((scrap) => Boolean(scrap.material) && (consumerSku ? scrap.material === consumerSku : true) && canFit(scrap, needW, needH, String(consumerSku ?? scrap.material ?? "")))
    .slice()
    .sort((a, b) => (a.widthCm * a.lengthCm - needW * needH) - (b.widthCm * b.lengthCm - needW * needH) || a.id.localeCompare(b.id));
}

/**
 * Greedy global matching: largest scraps first, largest needs first.
 * Not forced sequential by pane index.
 */
export function assignGlobalScrap(
  pool: ScrapPiece[],
  needs: Array<{ unit_id: string; pane_id: string; w: number; h: number; face: FilmFace }>,
  opts?: { requireSameFace?: boolean },
): GlobalScrapResult {
  const requireSameFace = opts?.requireSameFace !== false;
  const scraps = pool.map((s) => ({ ...s, used: false }));
  scraps.sort((a, b) => b.width_cm * b.height_cm - a.width_cm * a.height_cm);
  const sortedNeeds = [...needs].sort((a, b) => b.w * b.h - a.w * a.h);
  const assignments: ScrapAssignment[] = [];

  for (const need of sortedNeeds) {
    const idx = scraps.findIndex((s) => canFit(s, need.w, need.h, requireSameFace, need.face));
    if (idx < 0) continue;
    const scrap = scraps[idx];
    scrap.used = true;
    scrap.used_by_pane_id = need.pane_id;
    scrap.used_by_unit = need.unit_id;
    assignments.push({
      scrap_id: scrap.id,
      consumer_pane_id: need.pane_id,
      consumer_unit: need.unit_id,
      scrap_width_cm: scrap.width_cm,
      scrap_height_cm: scrap.height_cm,
      face: scrap.face,
    });
  }

  const remaining = scraps.filter((s) => !s.used);
  return {
    assignments,
    remaining,
    reused_count: assignments.length,
    remaining_count: remaining.length,
    remaining_cm2: remaining.reduce((sum, s) => sum + s.width_cm * s.height_cm, 0),
  };
}

export function oppositeFace(face: FilmFace): FilmFace {
  if (face === "A") return "B";
  if (face === "B") return "A";
  return "unknown";
}

/** Joined piece allowed only when orientation/face is compatible */
export function canJoinPieces(
  a: { face: FilmFace; material?: Partial<MaterialOrientationSpec> },
  b: { face: FilmFace; material?: Partial<MaterialOrientationSpec> },
  allowUnknown = false,
): boolean {
  if (a.face === "unknown" || b.face === "unknown") return allowUnknown && Boolean(a.material && b.material);
  if (a.face !== b.face) return false;
  if (!a.material || !b.material) return false;
  return checkSpliceCompatibility(a.material, b.material).status === "pass";
}
