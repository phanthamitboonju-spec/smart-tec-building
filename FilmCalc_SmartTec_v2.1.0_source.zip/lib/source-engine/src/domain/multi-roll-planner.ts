import { CM2_PER_SQFT, ceilDimensionCm } from "./units.ts";
import { SYSTEM_VERSION } from "../version.ts";
import { assignPaneFamilyMetadata, runCalculation, toCanonicalResult, type CanonicalCalcResult, type CalcPaneInput } from "./calculation-service.ts";
import type { EngineConfig, EngineScrapInput, JobCalcResult, PaneCalcRow, FinalScrap, CutPieceDetail, CalcEvent, RollUsageSummary } from "../engine/film-engine.ts";
import { resolveRollMaterialSpec } from "./material-orientation.ts";
import { MAX_JOB_PANE_UNITS } from "./job-validation.ts";
import type { MaterialOrientationSpec, OrientationPolicy, FilmFace, FactoryEdge, Rotation, SpliceMethod } from "./material-orientation.ts";

/** One entry represents one physical roll, not a product type or a pooled length. */
export interface RollProfile {
  id: string;
  label: string;
  width_cm: number;
  length_cm: number;
  /** Optional material binding for mixed-film plans */
  materialKey?: string;
  /** Product selector state stored with each physical roll. Brand is display-name scoped. */
  productBrand?: string;
  productFamilyKey?: string;
  lotId?: string;
  policy: OrientationPolicy;
  face: FilmFace;
  factoryEdge: FactoryEdge;
  allowedRotations?: Rotation[];
  sameLotForSplice?: boolean;
  directionKey?: string;
  sameLotForReuse?: boolean;
  sameRollForReuse?: boolean;
  sameDirectionForReuse?: boolean;
  factoryEdgeRequiredForSplice?: boolean;
  doubleCutSeamForbidden?: boolean;
  /** Manufacturer data source/reference recorded by the operator. */
  specSource?: string;
  /** Must only be true after the listed manufacturer document has been checked. */
  specVerified?: boolean;
  spliceMethod?: SpliceMethod;
  spliceOverlapCm?: number;
  /** Same non-empty ID means rolls are planned as one job pool; widths/lengths remain physical. */
  planningGroupId?: string;
}

export const DEFAULT_ROLL_PROFILES: RollProfile[] = [
  { id: "ROLL-A", label: "ม้วน A", width_cm: 152, length_cm: 3000, policy: "unknown", face: "unknown", factoryEdge: "unknown", sameLotForSplice: false, specSource: "", specVerified: false, spliceMethod: "unknown", spliceOverlapCm: undefined },
];

interface AssignedPane { pane: CalcPaneInput; sourceIndex: number }
interface GroupPlan { roll: RollProfile; entries: AssignedPane[]; calc: CanonicalCalcResult; poolKey: string; poolTerminal: boolean }

function fail(message: string): never {
  const error = new Error(message) as Error & { code?: string };
  error.code = "VALIDATION_FAILED";
  throw error;
}

function safeId(value: string): string {
  return value.trim().replace(/[^a-zA-Z0-9_-]+/g, "_").slice(0, 48) || "ROLL";
}

function validateRolls(profiles: RollProfile[]): RollProfile[] {
  if (!Array.isArray(profiles) || profiles.length < 1) fail("โหมดจัดการม้วนต้องมีม้วนอย่างน้อย 1 ม้วน");
  if (profiles.length > 20) fail("เพิ่มม้วนได้ไม่เกิน 20 ม้วนต่อแผน เพื่อควบคุมเวลาในการคำนวณ");
  const seen = new Set<string>();
  return profiles.map((raw, index) => {
    const id = String(raw?.id ?? "").trim();
    const label = String(raw?.label ?? "").trim() || `ม้วน ${index + 1}`;
    const width = Number(raw?.width_cm);
    const length = Number(raw?.length_cm);
    if (!id || id.length > 48 || !/^[a-zA-Z0-9_-]+$/.test(id)) fail(`ม้วน ${index + 1}: รหัสม้วนไม่ถูกต้อง`);
    if (seen.has(id)) fail(`รหัสม้วน ${id} ซ้ำกัน กรุณากำหนดรหัสให้ไม่ซ้ำ`);
    seen.add(id);
    if (!Number.isFinite(width) || width < 50 || width > 300) fail(`${label}: หน้ากว้างม้วนต้องอยู่ระหว่าง 50–300 ซม.`);
    if (!Number.isFinite(length) || length < 100 || length > 20000) fail(`${label}: ความยาวม้วนต้องอยู่ระหว่าง 100–20,000 ซม.`);
    if (!(raw.policy === "standard" || raw.policy === "directional" || raw.policy === "unknown")) fail(`${label}: ข้อกำหนดแนวฟิล์มไม่ถูกต้อง`);
    if (!(raw.face === "A" || raw.face === "B" || raw.face === "unknown")) fail(`${label}: ด้านฟิล์มไม่ถูกต้อง`);
    if (!(raw.factoryEdge === "A" || raw.factoryEdge === "B" || raw.factoryEdge === "unknown")) fail(`${label}: ขอบโรงงานไม่ถูกต้อง`);
    const specSource = String(raw.specSource ?? "").trim();
    const directionKey = String(raw.directionKey ?? "").trim();
    const planningGroupId = String(raw.planningGroupId ?? "").trim().replace(/[^a-zA-Z0-9_-]+/g, "_").slice(0, 48);
    if (directionKey.length > 120) fail(`${label}: รหัสทิศทางม้วน/ลายยาวเกิน 120 ตัวอักษร`);
    if (specSource.length > 500) fail(`${label}: แหล่งอ้างอิงยาวเกิน 500 ตัวอักษร`);
    if (raw.specVerified === true && !specSource) fail(`${label}: กรุณาระบุคู่มือ/เอกสารอ้างอิงก่อนยืนยันข้อกำหนด`);
    const spliceMethod: SpliceMethod = raw.spliceMethod === "butt" || raw.spliceMethod === "overlay" || raw.spliceMethod === "overlap-cut-through" || raw.spliceMethod === "forbidden" || raw.spliceMethod === "unknown" ? raw.spliceMethod : "unknown";
    const overlap = raw.spliceOverlapCm == null ? undefined : Number(raw.spliceOverlapCm);
    if ((spliceMethod === "overlay" || spliceMethod === "overlap-cut-through") && (!Number.isFinite(overlap) || Number(overlap) < 0.1 || Number(overlap) > Math.min(30, width - 1))) fail(`${label}: วิธีต่อแบบซ้อนต้องระบุระยะซ้อนจากคู่มือระหว่าง 0.1 ถึง 30 ซม. และน้อยกว่าหน้ากว้าง`);
    const rotations = Array.isArray(raw.allowedRotations)
      ? raw.allowedRotations.filter((n): n is Rotation => n === 0 || n === 90 || n === 180 || n === 270)
      : undefined;
    return { ...raw, id, label, width_cm: width, length_cm: length, lotId: String(raw.lotId ?? "").trim(), directionKey, planningGroupId: planningGroupId || undefined, factoryEdgeRequiredForSplice: raw.factoryEdgeRequiredForSplice === true, doubleCutSeamForbidden: raw.doubleCutSeamForbidden === true, allowedRotations: rotations, specSource, specVerified: raw.specVerified === true, spliceMethod, spliceOverlapCm: overlap };
  });
}

const rollMaterial = resolveRollMaterialSpec;

function calcForRoll(
  entries: AssignedPane[],
  roll: RollProfile,
  config: Partial<EngineConfig>,
  skuMaterial?: Partial<MaterialOrientationSpec>,
  optimizerEffort: "quick" | "full" = "full",
  initialScraps: EngineScrapInput[] = [],
): CanonicalCalcResult {
  const configForRoll: Partial<EngineConfig> = {
    ...config,
    filmMax: roll.width_cm,
    rollLen: roll.length_cm,
    materialOrientation: rollMaterial(roll, skuMaterial),
    optimizerEffort,
  };
  const rows = entries.map(({ pane }) => ({
    ...pane,
    // Roll identity and constraints are authoritative over pane drafts.
    material: rollMaterial(roll, skuMaterial),
  }));
  return runCalculation(rows, configForRoll, rollMaterial(roll, skuMaterial), { initialScraps });
}

function poolKeyForRoll(roll: RollProfile): string {
  return roll.planningGroupId ? `shared:${roll.planningGroupId}` : `solo:${roll.id}`;
}

function sourcePaneIndex(index: number | undefined, alreadyGlobal: boolean, entries: AssignedPane[], rollLabel: string): number | undefined {
  if (index == null || !Number.isFinite(Number(index))) return undefined;
  const value = Math.trunc(Number(index));
  if (value < 1) return undefined;
  if (alreadyGlobal) return value;
  const global = entries[value - 1]?.sourceIndex;
  if (global == null) fail(`${rollLabel}: ไม่สามารถผูกที่มาของเศษกับลำดับบาน ${value} ได้`);
  return global + 1;
}

function qualifyUnitId(value: string | undefined, rollId: string): string {
  const text = String(value ?? "").trim();
  if (!text) return `${rollId}::unknown-unit`;
  return text.includes("::") ? text : `${rollId}::${text}`;
}

function qualifyScrapId(value: string, rollId: string): string {
  const id = String(value ?? "").trim();
  if (!id) return `${rollId}-unknown-scrap`;
  if (id.startsWith(`${rollId}-`)) return id;
  if (id.startsWith(`${rollId}::`)) return `${rollId}-${id.slice(rollId.length + 2)}`;
  return `${rollId}-${id}`;
}

function carryPoolScraps(
  calc: CanonicalCalcResult,
  roll: RollProfile,
  entries: AssignedPane[],
  rollLabels: Map<string, string>,
): EngineScrapInput[] {
  return (calc.engine.finalScraps ?? []).map((scrap) => {
    const originRollId = String(scrap.roll_id || roll.id);
    const originRollLabel = String(scrap.roll_label || rollLabels.get(originRollId) || roll.label);
    const createdByRollId = String(scrap.created_by_roll_id || originRollId);
    const fromPane = sourcePaneIndex(scrap.origin_pane_index, scrap.origin_pane_global === true, entries, roll.label);
    const createdByPane = sourcePaneIndex(scrap.created_by_pane_index, scrap.created_by_pane_global === true, entries, roll.label);
    if (fromPane == null || createdByPane == null) fail(`${roll.label}: เศษฟิล์ม ${scrap.id} ไม่มีลำดับบานต้นทาง/บานที่ตัดล่าสุดครบถ้วน`);
    return {
      id: qualifyScrapId(scrap.id, originRollId),
      width_cm: Number(scrap.width_cm),
      height_cm: Number(scrap.height_cm),
      face: scrap.face,
      from_pane: fromPane,
      from_uid: qualifyUnitId(scrap.uid, originRollId),
      created_by_pane: createdByPane,
      created_by_uid: qualifyUnitId(scrap.created_by_uid || scrap.uid, createdByRollId),
      family_id: scrap.family_id,
      family_count: scrap.family_count,
      source_pull_no: scrap.source_pull_no,
      parent_scrap_id: scrap.parent_scrap_id,
      material: { ...(scrap.material ?? {}), rollId: originRollId },
      roll_id: originRollId,
      roll_label: originRollLabel,
      from_pane_global: true,
      created_by_pane_global: true,
      created_by_roll_id: createdByRollId,
    };
  });
}

function sortedPoolRolls(rolls: RollProfile[]): RollProfile[] {
  // Wider rolls are processed first so their physically larger offcuts can be assessed by
  // narrower rolls later. No roll dimensions are ever added or virtualized.
  return [...rolls].sort((a, b) => b.width_cm - a.width_cm || b.length_cm - a.length_cm || a.id.localeCompare(b.id));
}

function simulateRollPool(
  rolls: RollProfile[],
  entriesByRoll: Map<string, AssignedPane[]>,
  config: Partial<EngineConfig>,
  skuMaterial: Partial<MaterialOrientationSpec> | undefined,
  optimizerEffort: "quick" | "full",
): GroupPlan[] {
  const order = sortedPoolRolls(rolls);
  const labels = new Map(rolls.map((roll) => [roll.id, roll.label]));
  let carriedScraps: EngineScrapInput[] = [];
  const results: GroupPlan[] = [];
  const poolKey = rolls[0] ? poolKeyForRoll(rolls[0]) : "";
  for (const roll of order) {
    const entries = (entriesByRoll.get(roll.id) ?? []).slice().sort((a, b) => a.sourceIndex - b.sourceIndex);
    if (!entries.length) continue;
    const calc = calcForRoll(entries, roll, config, skuMaterial, optimizerEffort, carriedScraps);
    if (Number(calc.engine.summary.required_rolls ?? 0) > 1) {
      fail(`ม้วน ${roll.label} มีความยาวไม่พอสำหรับรายการบานที่จัดไว้ กรุณาเพิ่มม้วนจริงหรือแบ่งรายการไปยังม้วนอื่น`);
    }
    results.push({ roll, entries, calc, poolKey, poolTerminal: false });
    carriedScraps = carryPoolScraps(calc, roll, entries, labels);
  }
  if (results.length) results[results.length - 1].poolTerminal = true;
  return results;
}

function scorePool(groups: GroupPlan[]): GroupScore {
  return groups.reduce((score, group) => {
    const item = scoreGroup(group.calc);
    return { seams: score.seams + item.seams, freshSqft: score.freshSqft + item.freshSqft, pulls: score.pulls + item.pulls };
  }, { seams: 0, freshSqft: 0, pulls: 0 });
}

interface GroupScore {
  /** Physical seam count is the primary optimization objective. */
  seams: number;
  /** Fresh raw area is compared only after seam count. */
  freshSqft: number;
  pulls: number;
}

function scoreGroup(calc: CanonicalCalcResult): GroupScore {
  return {
    seams: Number(calc.engine.summary.seams ?? 0),
    freshSqft: Number(calc.engine.summary.fresh_raw_sqft ?? calc.fresh_raw_sqft),
    pulls: Number(calc.engine.summary.pulls ?? 0),
  };
}

/** Rough whole-job fit used only to assign many panes to physical rolls quickly. The final engine pass still plans scraps across the connected pool and always accounts a fresh pull at the full roll width. */
function estimateRollFit(
  pane: CalcPaneInput,
  roll: RollProfile,
  margin: number,
  skuMaterial?: Partial<MaterialOrientationSpec>,
  spliceAllowanceCm = 0,
): { fits: boolean; pullLen: number; splices: number } {
  const cutW = ceilDimensionCm(Number(pane.width_cm)) + 2 * margin;
  const cutH = ceilDimensionCm(Number(pane.height_cm)) + 2 * margin;
  const width = roll.width_cm;
  const material = rollMaterial(roll, skuMaterial);
  const joinRequired = cutW > width + 1e-9 && cutH > width + 1e-9;
  // Match choicesFor() exactly: if only one pane axis fits the web, only that
  // orientation is geometrically valid. Do not estimate a two-strip alternative
  // when the engine must use the other, single-strip orientation.
  const geometries: Array<{ axis: "V" | "H"; across: number; along: number }> = (joinRequired
    ? [
        { axis: "V" as const, across: cutW, along: cutH },
        { axis: "H" as const, across: cutH, along: cutW },
      ]
    : [
        ...(cutW <= width + 1e-9 ? [{ axis: "V" as const, across: cutW, along: cutH }] : []),
        ...(cutH <= width + 1e-9 ? [{ axis: "H" as const, across: cutH, along: cutW }] : []),
      ]).filter((candidate) => candidate.across > 0 && candidate.along > 0 && candidate.along <= roll.length_cm + 1e-9);

  // Auto assignment must consider the same geometric quarter-turn candidates as the
  // whole-job optimizer. The operator's explicit V/H direction remains a preference.
  // SKU/directional metadata is surfaced by the committed engine plan as a warning only.
  const forced = pane.dir === "V" || pane.dir === "H" ? pane.dir : undefined;
  let allowed = geometries;
  if (forced && allowed.some((candidate) => candidate.axis === forced)) {
    allowed = allowed.filter((candidate) => candidate.axis === forced);
  }

  const overlay = material.spliceMethod === "overlay" || material.spliceMethod === "overlap-cut-through"
    ? Number(material.spliceOverlapCm ?? 0)
    : 0;
  const options: Array<{ pullLen: number; splices: number }> = [];
  for (const candidate of allowed) {
    const across = candidate.across;
    const along = candidate.along;
    let strips = 1;
    if (across > width + 1e-6) {
      if (material.spliceMethod === "forbidden") continue;
      strips = overlay > 0 && overlay < width
        ? Math.ceil((across - overlay - 1e-9) / (width - overlay))
        : Math.ceil((across - 1e-9) / width);
      if (strips < 2 || strips > 2) continue; // SmartTec anti-jigsaw limit: max two continuous panels.
    }
    const perPanelLength = along + Math.max(0, Number(spliceAllowanceCm) || 0);
    if (perPanelLength > roll.length_cm + 1e-9) continue;
    options.push({ pullLen: perPanelLength * strips, splices: strips - 1 });
  }
  if (!options.length) return { fits: false, pullLen: Number.POSITIVE_INFINITY, splices: 99 };
  options.sort((a, b) => a.splices - b.splices || a.pullLen - b.pullLen);
  const qty = Math.max(1, Number(pane.qty ?? 1));
  return { fits: true, pullLen: options[0].pullLen * qty, splices: options[0].splices };
}

function scoreDelta(next: GroupScore, previous?: GroupScore): GroupScore {
  return {
    seams: next.seams - (previous?.seams ?? 0),
    freshSqft: next.freshSqft - (previous?.freshSqft ?? 0),
    pulls: next.pulls - (previous?.pulls ?? 0),
  };
}

function compareScoreDelta(a: GroupScore, b: GroupScore): number {
  // Lexicographic priority is deliberate: fewer seams always beats less fresh
  // material. Area/pulls are secondary criteria, never a trade for extra seams.
  return a.seams - b.seams || a.freshSqft - b.freshSqft || a.pulls - b.pulls;
}

function roundAllocation(raw: number[], total: number): number[] {
  const result = raw.map((n) => Math.floor(n + 1e-9));
  let remaining = total - result.reduce((sum, value) => sum + value, 0);
  const order = raw.map((value, i) => ({ i, frac: value - Math.floor(value + 1e-9) })).sort((a, b) => b.frac - a.frac || a.i - b.i);
  for (let i = 0; remaining > 0 && order.length; i = (i + 1) % order.length) {
    result[order[i].i] += 1;
    remaining -= 1;
  }
  return result;
}

/**
 * Whole-job, physical-roll planner. A planningGroupId explicitly connects selected physical rolls
 * into one sequential planning pool. Offcuts may carry forward between compatible rolls, while
 * each engine pass still receives that roll's exact physical width/length and material contract.
 * This deterministic, bounded heuristic does not claim a proven mathematical optimum.
 */
export function runMultiRollCalculation(
  panes: CalcPaneInput[],
  config: Partial<EngineConfig> | undefined,
  skuMaterial: Partial<MaterialOrientationSpec> | undefined,
  rawProfiles: RollProfile[],
): CanonicalCalcResult {
  const profiles = validateRolls(rawProfiles);
  const input = Array.isArray(panes) ? panes : [];
  const valid: AssignedPane[] = [];
  for (let sourceIndex = 0; sourceIndex < input.length; sourceIndex += 1) {
    const pane = input[sourceIndex];
    const width = Number(pane?.width_cm ?? 0);
    const height = Number(pane?.height_cm ?? 0);
    if (width === 0 && height === 0) continue;
    if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0) fail(`บาน ${sourceIndex + 1}: กรุณาตรวจความกว้างและความสูงก่อนวางแผนม้วน`);
    const qty = Number(pane.qty ?? 1);
    if (!Number.isInteger(qty) || qty < 1 || qty > 500) fail(`บาน ${sourceIndex + 1}: จำนวนต้องเป็นจำนวนเต็มระหว่าง 1–500`);
    valid.push({ pane: { ...pane, rollId: String((pane as CalcPaneInput & { rollId?: string }).rollId ?? "").trim() || undefined }, sourceIndex });
  }
  if (!valid.length) fail("กรุณากรอกขนาดบานอย่างน้อย 1 รายการก่อนคำนวณ");
  const withFamilies = assignPaneFamilyMetadata(valid.map((entry) => entry.pane), skuMaterial);
  valid.forEach((entry, index) => { entry.pane = withFamilies[index]; });
  const totalUnits = valid.reduce((sum, entry) => sum + Number(entry.pane.qty ?? 1), 0);
  if (totalUnits > MAX_JOB_PANE_UNITS) fail(`โหมดวางแผนม้วนรองรับไม่เกิน ${MAX_JOB_PANE_UNITS} หน่วยบานต่อแผนรวมทุกชนิดฟิล์ม กรุณาแบ่งงานที่ใหญ่กว่านี้ออกเป็นหลายแผน`);

  const profileById = new Map(profiles.map((profile) => [profile.id, profile]));
  const poolsByKey = new Map<string, RollProfile[]>();
  for (const profile of profiles) {
    const key = poolKeyForRoll(profile);
    const pool = poolsByKey.get(key) ?? [];
    pool.push(profile);
    poolsByKey.set(key, pool);
  }
  const entriesByRoll = new Map<string, AssignedPane[]>(profiles.map((profile) => [profile.id, []]));
  for (const entry of valid) {
    if (entry.pane.rollId && !profileById.has(entry.pane.rollId)) {
      fail(`บาน ${entry.sourceIndex + 1}: เลือกม้วน ${entry.pane.rollId} แต่ไม่พบม้วนนี้ในรายการ กรุณาเลือกม้วนใหม่หรือกลับเป็นอัตโนมัติ`);
    }
    if (entry.pane.rollId) entriesByRoll.get(entry.pane.rollId)!.push(entry);
  }

  // Respect user-pinned roll assignments first. The selected connected pool is still
  // optimized as one work area, but every candidate is calculated against its own roll's
  // exact physical width and remaining length.
  for (const [poolKey, poolRolls] of poolsByKey) {
    try {
      simulateRollPool(poolRolls, entriesByRoll, config ?? {}, skuMaterial, "quick");
    } catch (error) {
      if ((error as { code?: string })?.code === "VALIDATION_FAILED") throw error;
      fail(`กลุ่มม้วน ${poolKey}: ตรวจรายการที่กำหนดม้วนไว้ไม่สำเร็จ — ${error instanceof Error ? error.message : "ตรวจขนาดและข้อกำหนดม้วน"}`);
    }
  }

  // Place the hardest unassigned panes first. Each candidate is scored against every roll in
  // that roll's connected pool; the shared offcut pool is rebuilt for each candidate so a
  // pane can benefit from a reusable remnant produced by another selected physical roll.
  const unassigned = valid.filter((x) => !x.pane.rollId).sort((a, b) => {
    const m = Number(config?.margin ?? 2);
    const areaA = (ceilDimensionCm(a.pane.width_cm) + 2 * m) * (ceilDimensionCm(a.pane.height_cm) + 2 * m) * Number(a.pane.qty ?? 1);
    const areaB = (ceilDimensionCm(b.pane.width_cm) + 2 * m) * (ceilDimensionCm(b.pane.height_cm) + 2 * m) * Number(b.pane.qty ?? 1);
    return areaB - areaA || a.sourceIndex - b.sourceIndex;
  });

  const cloneEntries = (source: Map<string, AssignedPane[]>) => new Map([...source].map(([id, list]) => [id, list.slice()] as [string, AssignedPane[]]));
  const useExactPoolSearch = unassigned.length <= 40;
  const hasConnectedPool = [...poolsByKey.values()].some((pool) => pool.length > 1);

  /**
   * Greedy whole-job assignment of the unpinned panes. `connected=true` lets each trial use the
   * shared offcuts of its connected pool; `connected=false` scores every roll on its own. Both are
   * only candidate assignments: the final plan below always simulates the user's connected pools.
   */
  const assignExact = (connected: boolean): Map<string, AssignedPane[]> => {
    const working = cloneEntries(entriesByRoll);
    for (const entry of unassigned) {
      const candidates: Array<{ roll: RollProfile; entries: AssignedPane[]; score: GroupScore; existing: boolean }> = [];
      for (const roll of profiles) {
        const poolRolls = connected ? (poolsByKey.get(poolKeyForRoll(roll)) ?? [roll]) : [roll];
        const prior = working.get(roll.id) ?? [];
        const trialEntries = new Map(working);
        trialEntries.set(roll.id, [...prior, entry].sort((a, b) => a.sourceIndex - b.sourceIndex));
        try {
          const trial = simulateRollPool(poolRolls, trialEntries, config ?? {}, skuMaterial, "quick");
          candidates.push({ roll, entries: trialEntries.get(roll.id)!, score: scorePool(trial), existing: prior.length > 0 });
        } catch {
          // A non-fitting or technically incompatible roll is excluded without hiding other options.
        }
      }
      candidates.sort((a, b) => compareScoreDelta(a.score, b.score)
        || Number(b.existing) - Number(a.existing)
        || profiles.findIndex((p) => p.id === a.roll.id) - profiles.findIndex((p) => p.id === b.roll.id));
      const picked = candidates[0];
      if (!picked) {
        fail(`บาน ${entry.sourceIndex + 1} (${entry.pane.width_cm} × ${entry.pane.height_cm} ซม.) ยังจัดลงม้วนที่ตั้งไว้ไม่ได้โดยไม่เกินความยาวม้วน กรุณาเพิ่มม้วนจริง ตรวจหน้ากว้าง/ความยาว หรือกำหนดม้วนให้ชัดเจน`);
      }
      working.set(picked.roll.id, picked.entries);
    }
    return working;
  };

  let committedGroups: GroupPlan[] | null = null;
  if (useExactPoolSearch) {
    const connectedAssignment = assignExact(true);
    let chosen = connectedAssignment;
    if (hasConnectedPool && unassigned.length > 0) {
      // Linking widens the planning scope, so it must never produce a worse job than planning the
      // same rolls apart. Heuristic searches are not monotone, so evaluate both candidate
      // assignments through the same connected-pool simulation and keep the better plan.
      const apartAssignment = assignExact(false);
      const planPools = (assignment: Map<string, AssignedPane[]>): GroupPlan[] | null => {
        try {
          return [...poolsByKey.values()].flatMap((poolRolls) => simulateRollPool(poolRolls, assignment, config ?? {}, skuMaterial, "full"));
        } catch {
          return null;
        }
      };
      // Third candidate: the same apart-assignment with no cross-roll offcut flow at all. It is the
      // plan the user would get if the rolls were not linked, so a linked job can never be worse.
      const planSolo = (assignment: Map<string, AssignedPane[]>): GroupPlan[] | null => {
        try {
          return profiles.flatMap((roll) => simulateRollPool([roll], assignment, config ?? {}, skuMaterial, "full"));
        } catch {
          return null;
        }
      };
      const options: Array<{ assignment: Map<string, AssignedPane[]>; plan: GroupPlan[] }> = [];
      const add = (assignment: Map<string, AssignedPane[]>, plan: GroupPlan[] | null) => { if (plan) options.push({ assignment, plan }); };
      add(connectedAssignment, planPools(connectedAssignment));
      add(apartAssignment, planPools(apartAssignment));
      add(apartAssignment, planSolo(apartAssignment));
      if (options.length) {
        let best = options[0];
        for (const option of options.slice(1)) {
          if (compareScoreDelta(scorePool(option.plan), scorePool(best.plan)) < 0) best = option;
        }
        chosen = best.assignment;
        committedGroups = best.plan;
      }
    }
    for (const [id, list] of chosen) entriesByRoll.set(id, list);
  } else {
    // Large jobs still look at every pane before the final plan. Assignment uses a bounded
    // geometric fit so 500 panes stay responsive; the full engine pass below plans the whole
    // connected pool, including remnant carry. Roll widths are never added together.
    const margin = Number(config?.margin ?? 2);
    const remaining = new Map(profiles.map((roll) => [roll.id, roll.length_cm]));
    for (const entry of unassigned) {
      const ranked = profiles.map((roll) => {
        const fit = estimateRollFit(entry.pane, roll, margin, skuMaterial, Number(config?.spliceAllowanceCm ?? 0));
        const left = remaining.get(roll.id) ?? 0;
        return { roll, fit, left, existing: (entriesByRoll.get(roll.id) ?? []).length > 0 };
      }).filter((item) => item.fit.fits && item.left + 1e-9 >= item.fit.pullLen)
        .sort((a, b) => a.fit.splices - b.fit.splices
          || Number(b.existing) - Number(a.existing)
          || a.fit.pullLen - b.fit.pullLen
          || b.left - a.left);
      const picked = ranked[0];
      if (!picked) {
        fail(`บาน ${entry.sourceIndex + 1} (${entry.pane.width_cm} × ${entry.pane.height_cm} ซม.) ไม่มีม้วนที่เหลือความยาวเพียงพอในรายการที่เลือก กรุณาเพิ่ม/ตรวจความยาวม้วน หรือเชื่อมเฉพาะม้วนที่เข้ากันได้ก่อนคำนวณ`);
      }
      const prior = entriesByRoll.get(picked.roll.id) ?? [];
      entriesByRoll.set(picked.roll.id, [...prior, entry].sort((a, b) => a.sourceIndex - b.sourceIndex));
      remaining.set(picked.roll.id, (remaining.get(picked.roll.id) ?? 0) - picked.fit.pullLen);
    }
  }

  const activeGroups: GroupPlan[] = [];
  if (committedGroups) {
    activeGroups.push(...committedGroups);
  } else {
    for (const [poolKey, poolRolls] of poolsByKey) {
      try {
        const committed = simulateRollPool(poolRolls, entriesByRoll, config ?? {}, skuMaterial, "full");
        activeGroups.push(...committed);
      } catch (error) {
        if ((error as { code?: string })?.code === "VALIDATION_FAILED") throw error;
        fail(`กลุ่มม้วน ${poolKey}: วางแผนขั้นสุดท้ายไม่สำเร็จ — ${error instanceof Error ? error.message : "ตรวจขนาดและข้อกำหนดม้วน"}`);
      }
    }
  }

  const allRows: PaneCalcRow[] = [];
  const allScraps: FinalScrap[] = [];
  const allEvents: CalcEvent[] = [];
  const rawFreshByGlobal = new Map<number, number>();
  let totalFreshRaw = 0;
  let totalGlassCm2 = 0;
  let sumFaceSqft = 0;
  let sumNaive = 0;
  let pulls = 0, seams = 0, paired = 0, scrapUsedPieces = 0, scrapUsedCm2 = 0;
  let finalScrapCm2 = 0, reusablePieces = 0, reusableCm2 = 0, wastePieces = 0, wasteCm2 = 0, freshPullCm = 0, endWasteCm = 0, trials = 0;
  let overallPlan: JobCalcResult["summary"]["plan"] = "per-pane";
  let orientationStatus: JobCalcResult["summary"]["orientation_status"] = "pass";
  const warnings = new Set<string>();
  const rollUsages: RollUsageSummary[] = [];
  let globalSeq = 1;
  let globalPullNo = 1;
  const globalPullBySource = new Map<string, number>();
  const globalPullKey = (rollId: string, pullNo: number) => `${rollId}::${pullNo}`;
  const mapPullNo = (rollId: string, pullNo: number | undefined) => {
    if (pullNo == null || !Number.isFinite(Number(pullNo))) return undefined;
    return globalPullBySource.get(globalPullKey(rollId, Number(pullNo))) ?? Number(pullNo);
  };

  for (const group of activeGroups) {
    const { roll, entries, calc } = group;
    const engine = calc.engine;
    const pref = safeId(roll.id);
    const groupSequenceOffset = globalSeq - 1;
    const groupMaxSequence = Math.max(0, ...engine.panes.flatMap((row) => (row.cutPieces ?? []).map((piece) => Number(piece.sequence ?? 0))));
    const localPullNos = [...new Set(engine.panes.flatMap((row) => (row.cutPieces ?? [])
      .filter((piece) => piece.source === "fresh" && piece.pull_no != null)
      .map((piece) => Number(piece.pull_no))))].filter(Number.isFinite).sort((a, b) => a - b);
    for (const localPullNo of localPullNos) {
      globalPullBySource.set(globalPullKey(roll.id, localPullNo), globalPullNo++);
    }
    const mapPane = (localIndex: number | undefined) => localIndex == null ? undefined : entries[localIndex - 1]?.sourceIndex + 1;
    const mapPaneWithScope = (index: number | undefined, isGlobal?: boolean) => index == null ? undefined : isGlobal ? index : mapPane(index);
    const rollLabelById = new Map(profiles.map((profile) => [profile.id, profile.label]));
    const uniqueScrapId = qualifyScrapId;
    const rowRaw = new Map<number, number>();
    const mappedRows = engine.panes.map((row) => {
      const globalIndex = mapPane(row.index) ?? row.index;
      const cutPieces = (row.cutPieces ?? []).map((piece) => {
        const freshRaw = piece.source === "fresh" ? (roll.width_cm * piece.cut_length_cm) / CM2_PER_SQFT : 0;
        if (freshRaw > 0) rowRaw.set(globalIndex, (rowRaw.get(globalIndex) ?? 0) + freshRaw);
        const created = piece.created_scraps?.map((scrap) => {
          const sourceRollId = String(scrap.roll_id || roll.id);
          return {
            ...scrap,
            id: uniqueScrapId(scrap.id, sourceRollId),
            source_pull_no: mapPullNo(sourceRollId, scrap.source_pull_no),
            origin_pane_index: mapPaneWithScope(scrap.origin_pane_index, scrap.origin_pane_global) ?? scrap.origin_pane_index,
            created_by_pane_index: mapPaneWithScope(scrap.created_by_pane_index, scrap.created_by_pane_global) ?? scrap.created_by_pane_index,
            roll_id: sourceRollId,
            roll_label: String(scrap.roll_label || rollLabelById.get(sourceRollId) || roll.label),
          };
        });
        const sourceRollId = String(piece.from_roll_id || roll.id);
        const mapped: CutPieceDetail = {
          ...piece,
          piece_id: `${pref}-${piece.piece_id}`,
          sequence: groupSequenceOffset + Math.max(1, Number(piece.sequence ?? 1)),
          pull_no: piece.source === "fresh" ? mapPullNo(roll.id, piece.pull_no) : undefined,
          source_pull_no: mapPullNo(sourceRollId, piece.source_pull_no),
          scrap_id: piece.scrap_id ? uniqueScrapId(piece.scrap_id, sourceRollId) : undefined,
          from_pane: mapPaneWithScope(piece.from_pane, piece.from_pane_global) ?? piece.from_pane,
          scrap_created_by_pane: mapPaneWithScope(piece.scrap_created_by_pane, piece.scrap_created_by_pane_global) ?? piece.scrap_created_by_pane,
          created_scraps: created,
          roll_id: roll.id,
          roll_label: roll.label,
        };
        return mapped;
      }).sort((a, b) => a.sequence - b.sequence);
      const scrapSources = (row.scrapSources ?? []).map((source) => ({
        ...source,
        scrap_id: uniqueScrapId(source.scrap_id, String(source.from_roll_id || roll.id)),
        from_pane: mapPaneWithScope(source.from_pane, source.from_pane_global) ?? source.from_pane,
      }));
      const mapped: PaneCalcRow = {
        ...row,
        index: globalIndex,
        roll_id: roll.id,
        roll_label: roll.label,
        donor: scrapSources[0]?.from_pane ?? (mapPane(row.donor ?? undefined) ?? row.donor),
        scrapSources,
        cutPieces,
      };
      allRows.push(mapped);
      return mapped;
    });

    if (group.poolTerminal) {
      for (const scrap of engine.finalScraps ?? []) {
        const sourceRollId = String(scrap.roll_id || roll.id);
        const createdByRollId = String(scrap.created_by_roll_id || sourceRollId);
        const originPane = mapPaneWithScope(scrap.origin_pane_index, scrap.origin_pane_global) ?? Number(scrap.pane_id);
        const createdByPane = mapPaneWithScope(scrap.created_by_pane_index, scrap.created_by_pane_global) ?? originPane;
        allScraps.push({
          ...scrap,
          id: uniqueScrapId(scrap.id, sourceRollId),
          pane_id: String(originPane),
          from: String(originPane),
          uid: qualifyUnitId(scrap.uid, sourceRollId),
          origin_pane_index: originPane,
          created_by_pane_index: createdByPane,
          created_by_uid: qualifyUnitId(scrap.created_by_uid || scrap.uid, createdByRollId),
          parent_scrap_id: scrap.parent_scrap_id ? uniqueScrapId(scrap.parent_scrap_id, sourceRollId) : undefined,
          source_pull_no: mapPullNo(sourceRollId, scrap.source_pull_no),
          roll_id: sourceRollId,
          roll_label: String(scrap.roll_label || rollLabelById.get(sourceRollId) || roll.label),
        });
      }
    }
    for (const event of engine.events ?? []) {
      allEvents.push({
        ...event,
        pane: mapPane(event.pane) ?? event.pane,
        from_pane: mapPaneWithScope(event.from_pane, event.from_pane_global) ?? event.from_pane,
        scrap_id: event.scrap_id ? uniqueScrapId(event.scrap_id, String(event.from_roll_id || roll.id)) : undefined,
        from_roll_id: event.from_roll_id,
        roll_id: roll.id,
        roll_label: roll.label,
      });
    }

    globalSeq += groupMaxSequence;
    totalFreshRaw += Number(engine.summary.fresh_raw_sqft ?? 0);
    totalGlassCm2 += Number(engine.glassAreaCm2 ?? 0);
    sumFaceSqft += Number(engine.summary.face_sqft ?? 0);
    sumNaive += Number(engine.summary.naive_install_sqft ?? 0);
    pulls += Number(engine.summary.pulls ?? 0);
    seams += Number(engine.summary.seams ?? 0);
    paired += Number(engine.summary.paired ?? 0);
    scrapUsedPieces += Number(engine.summary.scrap_used_pieces ?? 0);
    scrapUsedCm2 += Number(engine.summary.scrap_used_cm2 ?? 0);
    freshPullCm += Number(engine.summary.fresh_pull_cm ?? 0);
    endWasteCm += Number(engine.summary.roll_end_waste_cm ?? 0);
    trials += Number(engine.summary.optimizer_trials ?? 0);
    if (Number(engine.summary.scrap_used_pieces ?? 0) > 0) overallPlan = "global-scrap";
    if (engine.summary.orientation_status === "block") orientationStatus = "block";
    else if (engine.summary.orientation_status === "review" && orientationStatus !== "block") orientationStatus = "review";
    for (const warning of engine.summary.orientation_warnings ?? []) warnings.add(`${roll.label}: ${warning}`);
    const constraintsVerified = roll.specVerified === true && Boolean(String(roll.specSource ?? "").trim());
    if (!constraintsVerified) {
      orientationStatus = orientationStatus === "block" ? "block" : "review";
      warnings.add(`${roll.label}: ยังไม่มีแหล่งอ้างอิงที่บันทึกไว้และการยืนยันข้อกำหนดจากคู่มือฟิล์ม`);
    }
    if (Number(engine.summary.seams ?? 0) > 0) {
      if (constraintsVerified && roll.spliceMethod === "forbidden") {
        fail(`${roll.label}: คู่มือที่บันทึกไว้ไม่อนุญาตให้ต่อฟิล์ม แต่แผนนี้ต้องต่อ ${engine.summary.seams} จุด กรุณาใช้ม้วนหน้ากว้าง/แนวทางที่ถูกต้อง`);
      }
      if (!constraintsVerified || roll.spliceMethod === "unknown") {
        orientationStatus = orientationStatus === "block" ? "block" : "review";
        warnings.add(`${roll.label}: แผนนี้มีรอยต่อ แต่ยังไม่มีวิธีต่อที่ยืนยันจากคู่มือ (ชนขอบ/ซ้อน/ข้อจำกัดเฉพาะ)`);
      }
    }
    for (const [index, area] of rowRaw) rawFreshByGlobal.set(index, (rawFreshByGlobal.get(index) ?? 0) + area);

    const groupRaw = Number(engine.summary.fresh_raw_sqft ?? 0);
    rollUsages.push({
      roll_id: roll.id,
      label: roll.label,
      width_cm: roll.width_cm,
      length_cm: roll.length_cm,
      lot_id: roll.lotId || undefined,
      pane_indices: entries.map((entry) => entry.sourceIndex + 1),
      glass_sqft: Number(engine.summary.face_sqft ?? 0),
      // Filled after the job-level one-time rounding below.
      install_sqft: 0,
      fresh_raw_sqft: groupRaw,
      fresh_pull_cm: Number(engine.summary.fresh_pull_cm ?? 0),
      length_remaining_cm: Math.max(0, roll.length_cm - Number(engine.summary.fresh_pull_cm ?? 0)),
      pulls: Number(engine.summary.pulls ?? 0),
      seams: Number(engine.summary.seams ?? 0),
      reusable_scrap_pieces: 0,
      reusable_scrap_cm2: 0,
      waste_scrap_pieces: 0,
      waste_scrap_cm2: 0,
    });
  }

  // Final scraps are gathered once per connected pool (from its terminal physical roll),
  // so carried leftovers are never double-counted as they move through the pool.
  finalScrapCm2 = allScraps.reduce((sum, scrap) => sum + Number(scrap.area_cm2 ?? scrap.width_cm * scrap.height_cm), 0);
  const reusableScraps = allScraps.filter((scrap) => scrap.reusable);
  const wasteScraps = allScraps.filter((scrap) => !scrap.reusable);
  reusablePieces = reusableScraps.length;
  reusableCm2 = reusableScraps.reduce((sum, scrap) => sum + Number(scrap.area_cm2 ?? scrap.width_cm * scrap.height_cm), 0);
  wastePieces = wasteScraps.length;
  wasteCm2 = wasteScraps.reduce((sum, scrap) => sum + Number(scrap.area_cm2 ?? scrap.width_cm * scrap.height_cm), 0);
  const rollScrapTotals = new Map<string, { reusablePieces: number; reusableCm2: number; wastePieces: number; wasteCm2: number }>();
  for (const scrap of allScraps) {
    const id = String(scrap.roll_id || "");
    const tally = rollScrapTotals.get(id) ?? { reusablePieces: 0, reusableCm2: 0, wastePieces: 0, wasteCm2: 0 };
    if (scrap.reusable) { tally.reusablePieces += 1; tally.reusableCm2 += Number(scrap.area_cm2 ?? scrap.width_cm * scrap.height_cm); }
    else { tally.wastePieces += 1; tally.wasteCm2 += Number(scrap.area_cm2 ?? scrap.width_cm * scrap.height_cm); }
    rollScrapTotals.set(id, tally);
  }
  for (const usage of rollUsages) {
    const tally = rollScrapTotals.get(usage.roll_id);
    if (!tally) continue;
    usage.reusable_scrap_pieces = tally.reusablePieces;
    usage.reusable_scrap_cm2 = tally.reusableCm2;
    usage.waste_scrap_pieces = tally.wastePieces;
    usage.waste_scrap_cm2 = tally.wasteCm2;
  }

  allRows.sort((a, b) => a.index - b.index);
  const rowRawList = allRows.map((row) => rawFreshByGlobal.get(row.index) ?? 0);
  const totalInstall = Math.ceil(totalFreshRaw - 1e-9);
  const allocated = roundAllocation(rowRawList, totalInstall);
  const rowAllocations = new Map<number, number>();
  allRows.forEach((row, index) => {
    row.install_sqft = allocated[index] ?? 0;
    rowAllocations.set(row.index, row.install_sqft);
  });
  for (const usage of rollUsages) usage.install_sqft = usage.pane_indices.reduce((sum, index) => sum + (rowAllocations.get(index) ?? 0), 0);

  const totalReusableScrapSqft = reusableCm2 / CM2_PER_SQFT;
  const totalWasteScrapSqft = wasteCm2 / CM2_PER_SQFT;
  const effectiveConfig = config ?? {};
  const mainRoll = activeGroups[0]?.roll ?? profiles[0];
  const enginePlan: JobCalcResult = {
    version: activeGroups[0]?.calc.engine.version ?? SYSTEM_VERSION,
    config: {
      filmMax: mainRoll.width_cm,
      margin: Number(effectiveConfig.margin ?? 2),
      edgeGapMm: 0,
      divisor: CM2_PER_SQFT,
      rollLen: mainRoll.length_cm,
      scrapMin: Number(effectiveConfig.scrapMin ?? 5),
      jobProfile: String(effectiveConfig.jobProfile ?? "general"),
      version: activeGroups[0]?.calc.engine.version ?? SYSTEM_VERSION,
      roll_plan_enabled: true,
      roll_profiles: profiles.map((roll) => ({ id: roll.id, label: roll.label, width_cm: roll.width_cm, length_cm: roll.length_cm, lotId: roll.lotId || undefined, directionKey: roll.directionKey || undefined, planningGroupId: roll.planningGroupId || undefined, policy: roll.policy, face: roll.face, factoryEdge: roll.factoryEdge, allowedRotations: roll.allowedRotations, sameRollForSplice: true, sameLotForSplice: true, sameDirectionForSplice: true, sameLotForReuse: roll.sameLotForReuse, sameRollForReuse: roll.sameRollForReuse, sameDirectionForReuse: roll.sameDirectionForReuse, factoryEdgeRequiredForSplice: roll.factoryEdgeRequiredForSplice, doubleCutSeamForbidden: roll.doubleCutSeamForbidden, specSource: roll.specSource, specVerified: roll.specVerified, spliceMethod: roll.spliceMethod, spliceOverlapCm: roll.spliceOverlapCm })),
    },
    panes: allRows,
    summary: {
      install_sqft: totalInstall,
      fresh_sqft: totalInstall,
      naive_install_sqft: sumNaive,
      saved_sqft: Math.max(0, sumNaive - totalInstall),
      face_sqft: sumFaceSqft,
      pulls,
      seams,
      paired,
      scrap_used_pieces: scrapUsedPieces,
      scrap_used_cm2: scrapUsedCm2,
      final_scrap_pieces: allScraps.length,
      final_scrap_cm2: finalScrapCm2,
      final_scrap_sqft: Math.round(totalFreshRaw * 0 + (finalScrapCm2 / CM2_PER_SQFT) * 100) / 100,
      reusable_scrap_pieces: reusablePieces,
      reusable_scrap_cm2: reusableCm2,
      waste_scrap_pieces: wastePieces,
      waste_scrap_cm2: wasteCm2,
      waste_scrap_sqft: Math.round(totalWasteScrapSqft * 100) / 100,
      waste_cm2: wasteCm2,
      glass_raw_sqft: totalGlassCm2 / CM2_PER_SQFT,
      optimizer_trials: trials,
      optimization_is_exact: false,
      optimization_method: "deterministic-heuristic",
      pieces: allRows.reduce((sum, row) => sum + Number(row.pieces ?? 0), 0),
      fresh_raw_sqft: totalFreshRaw,
      plan: overallPlan,
      plan_order: "connected-physical-roll-pools-whole-job-heuristic",
      note_th: `วางแผน ${activeGroups.length} ม้วนจริงตามหน้ากว้างม้วนแต่ละม้วน โดยม้วนที่ผู้ใช้เชื่อมกลุ่มเดียวกันจะส่งต่อเฉพาะเศษที่เหลือให้ม้วนถัดไปตรวจใช้ได้จริง ไม่บวกหน้ากว้างหรือความยาวม้วนเข้าด้วยกัน; การใช้เศษยังต้องผ่าน SKU ด้านฟิล์ม Lot และข้อกำหนดฟิล์ม`,
      fresh_pull_cm: freshPullCm,
      required_rolls: activeGroups.length,
      roll_end_waste_cm: endWasteCm,
      orientation_status: orientationStatus,
      orientation_warnings: [...warnings],
      roll_usage: rollUsages,
    },
    events: allEvents.sort((a, b) => a.pane - b.pane || 0),
    finalScraps: allScraps.sort((a, b) => a.roll_id!.localeCompare(b.roll_id!) || Number(a.origin_pane_index ?? 0) - Number(b.origin_pane_index ?? 0)),
    glassAreaCm2: totalGlassCm2,
    glassAreaSqft: totalGlassCm2 / CM2_PER_SQFT,
    installAreaSqft: totalInstall,
  };
  const mappedInputs = input.map((pane, inputIndex) => {
    const row = allRows.find((candidate) => candidate.index === inputIndex + 1);
    return { ...pane, rollId: row?.roll_id ?? (pane as CalcPaneInput & { rollId?: string }).rollId };
  });
  return toCanonicalResult(enginePlan, mappedInputs);
}
