/**
 * Material orientation / splice guard for architectural window film.
 *
 * This module deliberately does not guess manufacturer-specific rules.
 * Missing optional metadata is REVIEW: the planner may allocate provisionally and must
 * surface a visible warning. Confirmed incompatibilities/prohibitions remain BLOCK.
 */
export type FilmFace = "A" | "B" | "unknown";
export type FactoryEdge = "A" | "B" | "unknown";
export type SpliceMethod = "butt" | "overlay" | "overlap-cut-through" | "forbidden" | "unknown";
export type OrientationPolicy = "standard" | "directional" | "unknown";
export type Rotation = 0 | 90 | 180 | 270;

export interface MaterialOrientationSpec {
  sku?: string;
  rollId?: string;
  lotId?: string;
  face: FilmFace;
  factoryEdge: FactoryEdge;
  policy: OrientationPolicy;
  allowedRotations?: Rotation[];
  flipAllowed?: boolean;
  sameRollForSplice?: boolean;
  sameLotForSplice?: boolean;
  /** Require the same recorded web/pattern direction across every panel in one pane. */
  sameDirectionForSplice?: boolean;
  /** Require same Lot when offcuts are reused across separately installed panes for appearance continuity. */
  sameLotForReuse?: boolean;
  /** Require same physical roll for offcut reuse (separate from seam requirements). */
  sameRollForReuse?: boolean;
  /** Recorded machine/pattern direction key; required when directional continuity is specified. */
  directionKey?: string;
  sameDirectionForReuse?: boolean;
  factoryEdgeRequiredForSplice?: boolean;
  /** Some catalogued finishes explicitly prohibit double-cut seams (e.g. DI-NOC W-designated products). */
  doubleCutSeamForbidden?: boolean;
  spliceMethod?: SpliceMethod;
  spliceOverlapCm?: number;
  /** True only after a person checked the manufacturer sheet for this SKU. */
  specVerified?: boolean;
  specSource?: string;
}

export type SpliceCheckStatus = "pass" | "review" | "block";

export interface SpliceCheck {
  status: SpliceCheckStatus;
  reasons: string[];
}

const ALL_ROTATIONS: Rotation[] = [0, 90, 180, 270];

export function normalizeOrientationSpec(spec?: Partial<MaterialOrientationSpec> | null): MaterialOrientationSpec {
  const rotations = Array.isArray(spec?.allowedRotations)
    ? spec!.allowedRotations.filter((n): n is Rotation => ALL_ROTATIONS.includes(n as Rotation))
    : undefined;
  return {
    sku: spec?.sku,
    rollId: spec?.rollId,
    lotId: spec?.lotId,
    face: spec?.face === "A" || spec?.face === "B" ? spec.face : "unknown",
    factoryEdge: spec?.factoryEdge === "A" || spec?.factoryEdge === "B" ? spec.factoryEdge : "unknown",
    policy: spec?.policy === "standard" || spec?.policy === "directional" ? spec.policy : "unknown",
    allowedRotations: rotations,
    flipAllowed: spec?.flipAllowed === true,
    // SmartTec seam policy: panels for one pane must originate from the same physical roll,
    // same production Lot, and same recorded web/pattern direction.
    sameRollForSplice: true,
    sameLotForSplice: true,
    sameDirectionForSplice: true,
    sameLotForReuse: spec?.sameLotForReuse === true,
    sameRollForReuse: spec?.sameRollForReuse === true,
    directionKey: typeof spec?.directionKey === "string" ? spec.directionKey.trim() : undefined,
    sameDirectionForReuse: spec?.sameDirectionForReuse === true,
    factoryEdgeRequiredForSplice: spec?.factoryEdgeRequiredForSplice === true,
    doubleCutSeamForbidden: spec?.doubleCutSeamForbidden === true,
    spliceMethod: spec?.spliceMethod === "butt" || spec?.spliceMethod === "overlay" || spec?.spliceMethod === "overlap-cut-through" || spec?.spliceMethod === "forbidden" || spec?.spliceMethod === "unknown" ? spec.spliceMethod : "unknown",
    spliceOverlapCm: Number.isFinite(Number(spec?.spliceOverlapCm)) && spec?.spliceOverlapCm != null ? Number(spec.spliceOverlapCm) : undefined,
    specVerified: spec?.specVerified === true,
    specSource: typeof spec?.specSource === "string" ? spec.specSource : undefined,
  };
}

export interface RollMaterialProfileForRules {
  id: string;
  materialKey?: string;
  lotId?: string;
  policy: OrientationPolicy;
  face: FilmFace;
  factoryEdge: FactoryEdge;
  allowedRotations?: Rotation[];
  sameLotForSplice?: boolean;
  directionKey?: string;
  factoryEdgeRequiredForSplice?: boolean;
  doubleCutSeamForbidden?: boolean;
  specSource?: string;
  specVerified?: boolean;
  spliceMethod?: SpliceMethod;
  spliceOverlapCm?: number;
  sameLotForReuse?: boolean;
  sameRollForReuse?: boolean;
  sameDirectionForReuse?: boolean;
  /** Present on physical rolls; ignored by rule resolution. */
  label?: string;
  width_cm?: number;
  length_cm?: number;
}

/** Resolve SKU-level manufacturer rules with verified physical-roll overrides. */
export function resolveRollMaterialSpec(roll: RollMaterialProfileForRules, skuMaterial?: Partial<MaterialOrientationSpec>): Partial<MaterialOrientationSpec> {
  const rollVerified = roll.specVerified === true && Boolean(String(roll.specSource ?? "").trim());
  const skuVerified = skuMaterial?.specVerified === true && Boolean(String(skuMaterial.specSource ?? "").trim());
  // A checked roll-level bulletin may refine SKU rules; default/unknown roll fields must not erase verified catalogue data.
  const policy = rollVerified && roll.policy !== "unknown" ? roll.policy : skuVerified ? skuMaterial?.policy : "unknown";
  const face = rollVerified && roll.face !== "unknown" ? roll.face : skuVerified ? skuMaterial?.face : "unknown";
  const factoryEdge = rollVerified && roll.factoryEdge !== "unknown" ? roll.factoryEdge : skuVerified ? skuMaterial?.factoryEdge : "unknown";
  const rollMethod = rollVerified && roll.spliceMethod && roll.spliceMethod !== "unknown" ? roll.spliceMethod : undefined;
  const skuMethod = skuVerified && skuMaterial?.spliceMethod && skuMaterial.spliceMethod !== "unknown" ? skuMaterial.spliceMethod : undefined;
  const spliceMethod: SpliceMethod = (rollMethod ?? skuMethod ?? "unknown") as SpliceMethod;
  const rotations = rollVerified && Array.isArray(roll.allowedRotations) && roll.allowedRotations.length
    ? roll.allowedRotations
    : skuVerified && Array.isArray(skuMaterial?.allowedRotations) ? skuMaterial.allowedRotations : undefined;
  const overlap = rollMethod === "overlay" || rollMethod === "overlap-cut-through"
    ? roll.spliceOverlapCm
    : skuVerified ? skuMaterial?.spliceOverlapCm : undefined;
  const specSource = rollVerified ? String(roll.specSource).trim() : skuVerified ? String(skuMaterial?.specSource).trim() : undefined;
  const doubleCutSeamForbidden = (skuVerified && skuMaterial?.doubleCutSeamForbidden === true) ||
    (rollVerified && roll.doubleCutSeamForbidden === true);
  const factoryEdgeRequiredForSplice = spliceMethod === "butt" ||
    (skuVerified && skuMaterial?.factoryEdgeRequiredForSplice === true) ||
    (rollVerified && roll.factoryEdgeRequiredForSplice === true);
  return {
    ...(skuMaterial ?? {}),
    sku: String(roll.materialKey ?? skuMaterial?.sku ?? "") || undefined,
    rollId: roll.id,
    lotId: String(roll.lotId ?? "").trim() || skuMaterial?.lotId || undefined,
    directionKey: rollVerified && String(roll.directionKey ?? "").trim()
      ? String(roll.directionKey).trim()
      : String(skuMaterial?.directionKey ?? "").trim() || undefined,
    policy: policy === "standard" || policy === "directional" ? policy : "unknown",
    face: face === "A" || face === "B" ? face : "unknown",
    factoryEdge: factoryEdge === "A" || factoryEdge === "B" ? factoryEdge : "unknown",
    factoryEdgeRequiredForSplice,
    doubleCutSeamForbidden,
    allowedRotations: rotations,
    spliceMethod,
    spliceOverlapCm: overlap,
    sameRollForSplice: true,
    sameLotForSplice: true,
    sameDirectionForSplice: true,
    sameLotForReuse: (skuVerified && skuMaterial?.sameLotForReuse === true) || (rollVerified && roll.sameLotForReuse === true),
    sameRollForReuse: (skuVerified && skuMaterial?.sameRollForReuse === true) || (rollVerified && roll.sameRollForReuse === true),
    sameDirectionForReuse: (skuVerified && skuMaterial?.sameDirectionForReuse === true) || (rollVerified && roll.sameDirectionForReuse === true),
    specVerified: rollVerified || skuVerified,
    specSource,
  };
}

export function allowedRotations(spec?: Partial<MaterialOrientationSpec> | null): Rotation[] {
  const normalized = normalizeOrientationSpec(spec);
  if (normalized.allowedRotations?.length) return normalized.allowedRotations;
  if (normalized.policy === "standard") return ALL_ROTATIONS;
  if (normalized.policy === "directional") return [0];
  return [];
}

export function canRotate(spec: Partial<MaterialOrientationSpec> | null | undefined, rotation: Rotation): boolean {
  return allowedRotations(spec).includes(rotation);
}

export function checkSpliceCompatibility(
  a?: Partial<MaterialOrientationSpec> | null,
  b?: Partial<MaterialOrientationSpec> | null,
): SpliceCheck {
  const left = normalizeOrientationSpec(a);
  const right = normalizeOrientationSpec(b);
  const reasons: string[] = [];

  if (left.sku && right.sku && left.sku !== right.sku) {
    return { status: "block", reasons: ["รอยต่อต้องใช้ฟิล์มรุ่นเดียวกัน"] };
  }
  if (left.spliceMethod === "forbidden" || right.spliceMethod === "forbidden") {
    return { status: "block", reasons: ["ข้อกำหนดฟิล์มไม่อนุญาตให้ต่อฟิล์ม"] };
  }
  if ((left.doubleCutSeamForbidden || right.doubleCutSeamForbidden) && (left.spliceMethod === "overlap-cut-through" || right.spliceMethod === "overlap-cut-through")) {
    return { status: "block", reasons: ["SKU นี้ห้ามต่อแบบซ้อนแล้วกรีดตัดสองชั้นตามข้อกำหนดผู้ผลิต"] };
  }
  if (left.spliceMethod === "unknown" || right.spliceMethod === "unknown") reasons.push("ยังไม่ยืนยันวิธีต่อจากคู่มือฟิล์ม");
  if (left.spliceMethod !== "unknown" && right.spliceMethod !== "unknown" && left.spliceMethod !== right.spliceMethod) {
    return { status: "block", reasons: ["วิธีต่อของชิ้นฟิล์มไม่ตรงกัน"] };
  }
  const usesOverlap = left.spliceMethod === "overlay" || left.spliceMethod === "overlap-cut-through";
  const otherUsesOverlap = right.spliceMethod === "overlay" || right.spliceMethod === "overlap-cut-through";
  if (usesOverlap && otherUsesOverlap && Math.abs(Number(left.spliceOverlapCm ?? 0) - Number(right.spliceOverlapCm ?? 0)) > 1e-9) {
    return { status: "block", reasons: ["ระยะซ้อนทับของชิ้นฟิล์มไม่ตรงกัน"] };
  }
  if (left.face !== "unknown" && right.face !== "unknown" && left.face !== right.face) {
    return { status: "block", reasons: ["ด้านฟิล์มที่ใช้ต่อไม่ตรงกัน"] };
  }
  if (left.sameRollForSplice || right.sameRollForSplice) {
    if (!left.rollId || !right.rollId) reasons.push("ยังไม่ระบุรหัสม้วน จึงยืนยันการใช้ม้วนเดียวกันไม่ได้");
    else if (left.rollId !== right.rollId) return { status: "block", reasons: ["ชิ้นฟิล์มมาจากคนละม้วน"] };
  }
  if (left.sameLotForSplice || right.sameLotForSplice) {
    if (!left.lotId || !right.lotId) reasons.push("ยังไม่ระบุ Lot จึงยืนยัน Lot เดียวกันไม่ได้");
    else if (left.lotId !== right.lotId) return { status: "block", reasons: ["ชิ้นฟิล์มมาจากคนละ Lot"] };
  }
  if (left.sameDirectionForSplice || right.sameDirectionForSplice) {
    if (!left.directionKey || !right.directionKey) reasons.push("ยังไม่ระบุทิศทางม้วน/ทิศทางลาย จึงยืนยันความต่อเนื่องของเฉดสีไม่ได้");
    else if (left.directionKey !== right.directionKey) return { status: "block", reasons: ["ทิศทางการผลิตหรือทิศทางลายของแผ่นต่อไม่ตรงกัน"] };
  }
  const requiresFactoryEdge = left.factoryEdgeRequiredForSplice || right.factoryEdgeRequiredForSplice || left.spliceMethod === "butt" || right.spliceMethod === "butt";
  if (requiresFactoryEdge) {
    if (left.factoryEdge === "unknown" || right.factoryEdge === "unknown") {
      reasons.push("ยังไม่ระบุ Factory Edge ของชิ้นที่จะต่อ");
    } else if (left.factoryEdge !== right.factoryEdge) {
      return { status: "block", reasons: ["ขอบโรงงานของชิ้นฟิล์มไม่ตรงกัน ต้องใช้ขอบชนิดเดียวกันตามคู่มือฟิล์ม"] };
    }
  }
  if (left.policy === "unknown" || right.policy === "unknown") reasons.push("ยังไม่ทราบกฎทิศทางของฟิล์มรุ่นนี้");
  if (left.policy === "directional" || right.policy === "directional") reasons.push("เป็นฟิล์มที่ต้องตรวจทิศทางก่อนตัด/ต่อ");

  return { status: reasons.length ? "review" : "pass", reasons };
}


/** Compatibility for using an offcut as a separate pane (not a seam within one pane).
 * Same-roll rules belong to splice validation; offcuts may be used on another pane
 * when SKU/face/required lot rules match. Unknown metadata yields REVIEW, never PASS.
 */
export function checkScrapReuseCompatibility(
  donor?: Partial<MaterialOrientationSpec> | null,
  consumer?: Partial<MaterialOrientationSpec> | null,
): SpliceCheck {
  const left = normalizeOrientationSpec(donor);
  const right = normalizeOrientationSpec(consumer);
  const reasons: string[] = [];

  if (left.sku && right.sku && left.sku !== right.sku) {
    return { status: "block", reasons: ["เศษฟิล์มมาจาก SKU คนละรหัสกับบานที่จะติดตั้ง"] };
  }
  if (!left.sku || !right.sku) reasons.push("ยังไม่ยืนยันรหัส SKU ของเศษและบานปลายทาง");
  if (left.face !== "unknown" && right.face !== "unknown" && left.face !== right.face) {
    return { status: "block", reasons: ["ด้านฟิล์มของเศษไม่ตรงกับบานปลายทาง"] };
  }
  if (left.face === "unknown" || right.face === "unknown") reasons.push("ยังไม่ยืนยันด้านฟิล์มของเศษ");
  // Lot/roll constraints for reusing a whole offcut on another pane are distinct from
  // the stricter requirements that apply when two panels are joined on one pane.
  if (left.sameLotForReuse || right.sameLotForReuse) {
    if (!left.lotId || !right.lotId) reasons.push("ยังไม่ระบุ Lot จึงยืนยัน Lot เดียวกันไม่ได้");
    else if (left.lotId !== right.lotId) return { status: "block", reasons: ["เศษฟิล์มมาจากคนละ Lot"] };
  }
  if (left.sameRollForReuse || right.sameRollForReuse) {
    if (!left.rollId || !right.rollId) reasons.push("ยังไม่ระบุรหัสม้วน จึงยืนยันม้วนเดียวกันไม่ได้");
    else if (left.rollId !== right.rollId) return { status: "block", reasons: ["เศษฟิล์มมาจากคนละม้วนตามข้อกำหนดการใช้เศษ"] };
  }
  if (left.sameDirectionForReuse || right.sameDirectionForReuse) {
    if (!left.directionKey || !right.directionKey) reasons.push("ยังไม่ระบุทิศทางลาย/แนวผลิต จึงยืนยันความต่อเนื่องไม่ได้");
    else if (left.directionKey !== right.directionKey) return { status: "block", reasons: ["ทิศทางลายหรือแนวผลิตของเศษไม่ตรงกับบานปลายทาง"] };
  }
  if (left.policy === "unknown" || right.policy === "unknown") reasons.push("ยังไม่ยืนยันทิศทางฟิล์มของ SKU นี้");
  return { status: reasons.length ? "review" : "pass", reasons };
}


/**
 * Scrap reuse boundary.
 * A physical pane may never consume its own offcut. A sibling physical pane in the same
 * Pane Family may consume it only when the source family has at least two physical panes.
 * This is a family rule, not a permission to patch multiple strips into one physical pane.
 */
export interface ScrapPaneBoundaryContext {
  familyId?: string;
  familyCount?: number;
}

export function checkScrapPaneBoundary(
  scrap: { fromUid?: string; createdByUid?: string; familyId?: string; familyCount?: number },
  consumerUid?: string,
  context: ScrapPaneBoundaryContext = {},
): SpliceCheck {
  if (!consumerUid || !scrap.fromUid || !scrap.createdByUid) {
    return { status: "block", reasons: ["ไม่สามารถยืนยันต้นทางเศษและบานปลายทางได้ จึงห้ามนำเศษมาใช้"] };
  }
  if (scrap.createdByUid === consumerUid) {
    return { status: "block", reasons: ["ห้ามนำเศษกลับมาเติมบานกระจกกายภาพใบที่เพิ่งสร้างเศษชิ้นนี้"] };
  }
  const sameFamily = Boolean(scrap.familyId && context.familyId && scrap.familyId === context.familyId);
  if (sameFamily) {
    const sourceCount = Number(scrap.familyCount ?? 0);
    const consumerCount = Number(context.familyCount ?? 0);
    if (sourceCount < 2 || consumerCount < 2) {
      return { status: "block", reasons: ["การใช้เศษภายใน Pane Family เดียวกันอนุญาตเฉพาะกลุ่มที่มีบานจริงอย่างน้อย 2 บาน"] };
    }
  }
  return { status: "pass", reasons: [] };
}

/**
 * หลักการต่อฟิล์มอาคาร / ฟิล์มตกแต่งภายใน (จากแนวทางช่างและคู่มือผู้ผลิต)
 *
 * อนุญาต:
 * - รอยต่อเส้นตรงต่อเนื่องในทิศทางเดียวต่อหนึ่งบาน (แนวตั้ง หรือ แนวนอน)
 * - แผ่นยาวเป็นแถบขนาน (strip layout) ใช้ factory edge / overlap หรือ butt ตามคู่มือ
 * - จำนวนรอยต่อน้อยที่สุดที่เป็นไปได้
 *
 * ห้ามเด็ดขาด (จิ๊กซอว์):
 * - ต่อเป็นตาราง 2 แกน (ทั้งแนวตั้งและแนวนอนบนบานเดียวกัน)
 * - ต่อเป็นชิ้นเล็กไม่เรียงแนว / ปะติดปะต่อแบบปริศนา
 * - ใช้เศษหลายชิ้นประกอบเป็นหนึ่งบานแบบไม่เป็นแถบต่อเนื่อง
 *
 * วิธีต่อ (butt / overlay / overlap-cut-through), ระยะซ้อน, factory edge และตำแหน่ง
 * รอยต่อ ต้องเลือกจากคู่มือ SKU และบริบทหน้างานเท่านั้น ไม่มีค่า overlap หรือระดับสายตา
 * ที่ใช้เป็นกฎสากลกับฟิล์มทุกประเภท
 */
export const SPLICE_LAYOUT_POLICY = {
  /** ห้ามต่อแบบจิ๊กซอว์ / ตาราง 2 แกน เสมอ */
  forbidJigsawSplice: true as const,
  /** หนึ่งบาน = หนึ่งทิศทางรอยต่อเท่านั้น (V หรือ H หรือไม่มี) */
  singleAxisSeamsOnly: true as const,
  /** ต้องเป็นแผ่นเต็มต่อเนื่อง ไม่ใช่ชิ้นปะ */
  continuousParallelStripsOnly: true as const,
  /** One pane: either one unjoined sheet or two full panels joined along one line. */
  maxPanelsPerPane: 2 as const,
  maxContinuousSeamLinesPerPane: 1 as const,
};

export type SeamAxis = "none" | "V" | "H";

/** ตรวจว่าแผนรอยต่อของหนึ่งบานไม่ใช่จิ๊กซอว์ */
export function validatePaneSeamLayout(input: {
  seamAxis?: SeamAxis | string | null;
  stripCount?: number;
  hasPerpendicularSeams?: boolean;
  isJigsawOrGrid?: boolean;
}): { ok: boolean; status: SpliceCheckStatus; reasons: string[] } {
  const reasons: string[] = [];
  if (input.isJigsawOrGrid || input.hasPerpendicularSeams) {
    reasons.push("ห้ามต่อฟิล์มแบบจิ๊กซอว์หรือตารางสองแกน — ใช้ได้เฉพาะรอยต่อเส้นตรงทิศทางเดียว");
  }
  const axis = input.seamAxis ?? "none";
  if (axis !== "none" && axis !== "V" && axis !== "H") {
    reasons.push("ทิศทางรอยต่อต้องเป็นแนวตั้งหรือแนวนอนอย่างใดอย่างหนึ่งเท่านั้น");
  }
  const strips = Number(input.stripCount ?? 1);
  if (!Number.isInteger(strips) || strips < 1) {
    reasons.push("จำนวนแผ่นต้องเป็นจำนวนเต็มอย่างน้อย 1 แผ่น");
  } else if (strips > SPLICE_LAYOUT_POLICY.maxPanelsPerPane) {
    reasons.push("หนึ่งบานอนุญาตสูงสุด 2 แผ่นเต็มและรอยต่อเส้นเดียวต่อเนื่องเท่านั้น");
  }
  if (strips >= 2 && axis === "none") {
    reasons.push("มีหลายแผ่นแต่ไม่ระบุทิศทางรอยต่อ — อาจเป็นแผนจิ๊กซอว์");
  }
  if (reasons.length) return { ok: false, status: "block", reasons };
  return { ok: true, status: "pass", reasons: [] };
}

/** สรุปทิศทางรอยต่อจากจำนวนแผ่นและแนวตัด */
export function seamAxisFromOrient(orient: "V" | "H" | null | undefined, stripCount: number): SeamAxis {
  if (!stripCount || stripCount <= 1) return "none";
  if (orient === "V") return "V";
  if (orient === "H") return "H";
  return "none";
}
