/** Canonical measurement conversion functions. Calculations remain in cm and square feet internally. */
export const LENGTH_TO_CM = {
  mm: 0.1,
  cm: 1,
  m: 100,
  in: 2.54,
  ft: 30.48,
} as const;

export type LengthUnit = keyof typeof LENGTH_TO_CM;
export const AREA_TO_CM2 = {
  cm2: 1,
  m2: 10_000,
  in2: 6.4516,
  sqft: 929.0304,
} as const;
export type AreaUnit = keyof typeof AREA_TO_CM2;

export const LENGTH_UNIT_LABELS: Record<LengthUnit, string> = {
  mm: "มิลลิเมตร (มม.)",
  cm: "เซนติเมตร (ซม.)",
  m: "เมตร (ม.)",
  in: "นิ้ว (in)",
  ft: "ฟุต (ft)",
};
export const AREA_UNIT_LABELS: Record<AreaUnit, string> = {
  sqft: "ตารางฟุต (ตร.ฟุต / ft²)",
  m2: "ตารางเมตร (ตร.ม. / m²)",
  cm2: "ตารางเซนติเมตร (ตร.ซม. / cm²)",
  in2: "ตารางนิ้ว (ตร.นิ้ว / in²)",
};
export const AREA_UNIT_SHORT: Record<AreaUnit, string> = {
  sqft: "ตร.ฟุต",
  m2: "ตร.ม.",
  cm2: "ตร.ซม.",
  in2: "ตร.นิ้ว",
};

function finiteNonNegative(value: number): number {
  return Number.isFinite(value) && value >= 0 ? value : 0;
}

export function convertLength(value: number, from: LengthUnit, to: LengthUnit): number {
  return finiteNonNegative(value) * LENGTH_TO_CM[from] / LENGTH_TO_CM[to];
}

export function rectangleArea(valueA: number, valueB: number, unit: LengthUnit): number {
  return finiteNonNegative(valueA) * LENGTH_TO_CM[unit] * finiteNonNegative(valueB) * LENGTH_TO_CM[unit];
}

export function convertAreaFromCm2(areaCm2: number, to: AreaUnit): number {
  return finiteNonNegative(areaCm2) / AREA_TO_CM2[to];
}

export function convertArea(value: number, from: AreaUnit, to: AreaUnit): number {
  return finiteNonNegative(value) * AREA_TO_CM2[from] / AREA_TO_CM2[to];
}

export function explainConversion(valueA: number, valueB: number, unit: LengthUnit, output: AreaUnit): string[] {
  const widthCm = finiteNonNegative(valueA) * LENGTH_TO_CM[unit];
  const heightCm = finiteNonNegative(valueB) * LENGTH_TO_CM[unit];
  const areaCm2 = widthCm * heightCm;
  const factor = AREA_TO_CM2[output];
  const divisorText = output === "sqft" ? "929.0304" : output === "m2" ? "10,000" : output === "in2" ? "6.4516" : "1";
  return [
    `แปลงด้านกว้าง: ${valueA || 0} ${unit} × ${LENGTH_TO_CM[unit]} = ${widthCm.toLocaleString("th-TH", { maximumFractionDigits: 6 })} ซม.`,
    `แปลงด้านยาว: ${valueB || 0} ${unit} × ${LENGTH_TO_CM[unit]} = ${heightCm.toLocaleString("th-TH", { maximumFractionDigits: 6 })} ซม.`,
    `หาพื้นที่: ${widthCm.toLocaleString("th-TH", { maximumFractionDigits: 6 })} × ${heightCm.toLocaleString("th-TH", { maximumFractionDigits: 6 })} = ${areaCm2.toLocaleString("th-TH", { maximumFractionDigits: 6 })} ตร.ซม.`,
    output === "cm2"
      ? `แปลงหน่วยพื้นที่: ใช้ค่า ตร.ซม. โดยตรง (ตัวหาร ${divisorText})`
      : `แปลงหน่วยพื้นที่: ${areaCm2.toLocaleString("th-TH", { maximumFractionDigits: 6 })} ÷ ${divisorText} = ${convertAreaFromCm2(areaCm2, output).toLocaleString("th-TH", { maximumFractionDigits: 6 })} ${AREA_UNIT_SHORT[output]}`,
  ];
}
