import type { CalcPaneInput } from "./calculation-service.ts";

/** Same limit as the Calculate page and the chat parser. */
export const MAX_PANE_CM = 1000;
/** Maximum physical pane count in one whole-job plan, shared by single- and mixed-film modes. */
export const MAX_JOB_PANE_UNITS = 500;
/** Maximum repeat quantity on a single pane row. */
export const MAX_PANE_QTY = 500;

/**
 * Pure guard used by the server before saving a job. The engine silently skips invalid panes,
 * which would persist a job with fewer panes than the user sees on screen.
 * Returns a Thai message, or null when every pane is valid.
 */
export function validatePanes(panes: CalcPaneInput[]): string | null {
  if (!panes.length) return "กรุณาเพิ่มบานอย่างน้อย 1 บาน";
  for (const p of panes) {
    const w = Number(p.width_cm);
    const h = Number(p.height_cm);
    const q = p.qty === undefined ? 1 : Number(p.qty);
    if (!Number.isFinite(w) || !Number.isFinite(h) || !(w > 0 && h > 0)) {
      return "ความกว้างและความสูงของบานต้องมากกว่า 0";
    }
    if (w >= MAX_PANE_CM || h >= MAX_PANE_CM) return `ขนาดบานต้องน้อยกว่า ${MAX_PANE_CM} ซม.`;
    if (!Number.isInteger(q) || q < 1) return "จำนวนบานต้องเป็นจำนวนเต็มตั้งแต่ 1 ขึ้นไป";
    if (q > MAX_PANE_QTY) return `จำนวนบานต่อรายการต้องไม่เกิน ${MAX_PANE_QTY} บาน`;
  }
  return null;
}
