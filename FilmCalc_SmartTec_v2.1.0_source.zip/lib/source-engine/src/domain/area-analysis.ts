/**
 * การวิเคราะห์การใช้พื้นที่ — แยกชั้นข้อมูลให้ชัด ไม่ปนกัน
 *
 * 1) glass   = พื้นที่กระจกที่วัดได้จริง (ทศนิยม, ไม่ปัดระหว่างทาง)
 * 2) cut     = พื้นที่แผ่นตัดหยาบรวม (รวมชิ้นจากเศษ + ม้วนใหม่)
 * 3) fresh   = พื้นที่ฟิล์มใหม่ที่ดึงจากม้วนก่อนปัดแสดงผล
 * 4) install = fresh ที่ปัดขึ้นเป็นหน่วยงานตามกติกาปัจจุบัน; ไม่ใช่พื้นที่หลังเก็บขอบ
 * 5) saved   = ค่าประหยัดจากการจัดแผนใช้เศษเมื่อเทียบกับแผนฐาน
 * 6) quote   = พื้นที่เสนอราคาจากฟิล์มใหม่ที่ดึงจากม้วน + บัฟเฟอร์คงที่ 2 ตร.ฟุต
 */
import type { CanonicalCalcResult } from "./calculation-service.ts";
import { formatSqft, formatSqftPrecise } from "../lib/format.ts";
import { CM2_PER_SQFT } from "./units.ts";

export interface AreaBreakdown {
  /** พื้นที่กระจกวัดจริง (ตร.ฟ.) — ไม่รวมเผื่อตัด */
  glassSqft: number;
  /** ชื่อเดียวกับ glass สำหรับความเข้ากันกับ engine.face_sqft */
  faceSqft: number;
  /** ปริมาณฟิล์มใหม่ที่ดึงจากม้วน ปัดขึ้นตามกติกาหน่วยงานเดิม; ไม่ใช่พื้นที่หลังเก็บขอบ */
  installSqft: number;
  /** ฟิล์มดึงจากม้วนใหม่ (ก่อนปัดแสดงผล) */
  freshRawSqft: number;
  /** พื้นที่แผ่นตัดหยาบรวมทุกชิ้น */
  cutAreaRawSqft: number;
  /** พื้นที่ที่ประหยัดได้จากการใช้เศษ */
  savedSqft: number;
  /** พื้นที่เสนอราคา: ฟิล์มใหม่ที่ดึงจากม้วน + บัฟเฟอร์ (ตร.ฟุต), ปัดขึ้นเป็นตร.ฟุตเต็ม */
  quoteSqft: number;
  /** บัฟเฟอร์พื้นที่เสนอราคา (ตร.ฟุต); คงชื่อเดิมเพื่ออ่านข้อมูลเก่าได้ */
  bufferPct: number;
  /** อัตราส่วนปริมาณฟิล์มใหม่ที่ปัดแล้วต่อพื้นที่กระจก (เก็บไว้เพื่อวิเคราะห์ภายใน) */
  filmToGlassRatio: number | null;
  /** อัตราส่วนเศษที่ประหยัดต่อพื้นที่ตัด (saved/cut) */
  scrapReuseRatio: number | null;
}

export interface AreaAnalysisLabels {
  glass: string;
  install: string;
  fresh: string;
  cut: string;
  saved: string;
  quote: string;
  note: string;
}

/** ป้ายภาษาไทยมาตรฐาน — ใช้ทั้ง UI / รายงาน / ใบเสนอราคา */
export const AREA_ANALYSIS_LABELS_TH: AreaAnalysisLabels = {
  glass: "พื้นที่กระจกจริง (วัดได้)",
  install: "ฟิล์มใหม่ที่ดึงจากม้วน (ปัดตามหน่วยงาน)",
  fresh: "ฟิล์มดึงจากม้วนใหม่",
  cut: "พื้นที่ชิ้นฟิล์มตัดหยาบรวม",
  saved: "ประหยัดจากการใช้เศษ",
  quote: "พื้นที่เสนอราคา",
  note: "พื้นที่ฟิล์มใหม่คำนวณจากหน้ากว้างจริงของม้วน × ความยาวดึงทุกครั้ง รวมทั้งงาน บวกบัฟเฟอร์ 2 ตร.ฟุตครั้งเดียว แล้วปัดขึ้นเป็นตารางฟุตเต็ม ไม่ใช่พื้นที่กระจกจริง",
};

export interface MaterialLoss {
  drawnSqft: number;
  freshCutSqft: number;
  offcutSqft: number;
  discardedSqft: number;
  reusableSqft: number;
  rollEndCm: number;
}

/** สูญเสีย = ฟิล์มที่ดึงเต็มหน้ากว้าง ลบชิ้นที่ตัดจากม้วนใหม่ เศษที่ใช้แล้วไม่ถูกนับซ้ำ */
export function materialLoss(calc: CanonicalCalcResult): MaterialLoss {
  const drawnSqft = Math.max(0, Number(calc.fresh_raw_sqft) || 0);
  let freshCutCm2 = 0;
  for (const pane of calc.engine.panes ?? []) {
    for (const piece of pane.cutPieces ?? []) {
      if (piece.source !== "fresh") continue;
      freshCutCm2 += Math.max(0, Number(piece.cut_width_cm) || 0) * Math.max(0, Number(piece.cut_length_cm) || 0);
    }
  }
  const freshCutSqft = freshCutCm2 / CM2_PER_SQFT;
  const summary = calc.engine.summary;
  return {
    drawnSqft,
    freshCutSqft,
    offcutSqft: Math.max(0, drawnSqft - freshCutSqft),
    discardedSqft: Math.max(0, Number(summary?.waste_scrap_cm2 ?? 0)) / CM2_PER_SQFT,
    reusableSqft: Math.max(0, Number(summary?.reusable_scrap_cm2 ?? 0)) / CM2_PER_SQFT,
    rollEndCm: Math.max(0, Number(summary?.roll_end_waste_cm ?? 0)),
  };
}

/** ปัดพื้นที่เสนอราคาจากฟิล์มที่ดึงจากม้วน + บัฟเฟอร์เป็นตร.ฟุต แล้วปัดขึ้นเป็นตร.ฟุตเต็ม */
export function ceilQuoteSqft(freshSqft: number, bufferSqft = 2): number {
  const fresh = Math.max(0, Number(freshSqft) || 0);
  // An empty calculation is not a billable quotation: do not add the fixed buffer to zero material.
  if (fresh <= 0) return 0;
  const buffer = Number.isFinite(bufferSqft) ? Math.max(0, bufferSqft) : 2;
  return Math.ceil(fresh + buffer - 1e-9);
}

/**
 * Distribute a precomputed whole-job quote area across material lines.
 * The job buffer is applied once before this function; this helper only allocates
 * that integer handoff so line areas sum exactly to the whole-job area.
 */
export function allocateQuoteAreaSqft(freshAreasSqft: number[], quotedAreaSqft: number): number[] {
  const fresh = freshAreasSqft.map((value, index) => {
    const n = Number(value);
    if (!Number.isFinite(n) || n < 0) throw new Error(`พื้นที่ฟิล์มของรายการ ${index + 1} ไม่ถูกต้อง`);
    return n;
  });
  const quoted = Number(quotedAreaSqft);
  if (!Number.isFinite(quoted) || quoted < 0 || !Number.isInteger(quoted)) {
    throw new Error("พื้นที่เสนอราคาที่ส่งต่อมาต้องเป็นจำนวนเต็มตารางฟุตที่ถูกต้อง");
  }
  const freshTotal = fresh.reduce((sum, value) => sum + value, 0);
  if (quoted + 1e-9 < freshTotal) {
    throw new Error("พื้นที่เสนอราคาน้อยกว่าพื้นที่ฟิล์มที่ต้องดึงจากม้วน ตรวจผลคำนวณก่อนออกใบเสนอราคา");
  }
  if (fresh.length === 0) {
    if (quoted !== 0) throw new Error("ไม่มีรายการฟิล์ม แต่มีพื้นที่เสนอราคาไม่เป็นศูนย์");
    return [];
  }
  if (freshTotal <= 0) {
    if (quoted !== 0) throw new Error("ไม่มีการดึงฟิล์มใหม่ แต่พื้นที่เสนอราคาไม่เป็นศูนย์");
    return fresh.map(() => 0);
  }

  // Keep each SKU's actual roll-consumption area intact. Distribute the single
  // whole-job quote uplift (fixed 2 sqft buffer plus whole-sqft rounding) in
  // proportion to each SKU's fresh-roll consumption. Fractional per-SKU areas
  // are intentional: their sum must exactly equal the integer whole-job handoff,
  // and small material groups must never be assigned zero/less area than used.
  const uplift = Math.max(0, quoted - freshTotal);
  let assignedUplift = 0;
  let lastActiveIndex = -1;
  for (let i = 0; i < fresh.length; i++) if (fresh[i] > 0) lastActiveIndex = i;
  return fresh.map((value, index) => {
    if (value <= 0) return 0;
    const share = index === lastActiveIndex
      ? uplift - assignedUplift
      : uplift * (value / freshTotal);
    if (index !== lastActiveIndex) assignedUplift += share;
    return value + share;
  });
}

/**
 * สกัดการวิเคราะห์พื้นที่จากผลคำนวณมาตรฐาน
 * แยกพื้นที่กระจกจริงจากฟิล์มที่ดึงจากม้วน; พื้นที่เสนอราคาใช้ fresh + 2 ตร.ฟุต
 */
export function analyzeCalcArea(
  calc: CanonicalCalcResult | null | undefined,
  bufferPct = 2,
): AreaBreakdown {
  const bufferSqft = Number.isFinite(bufferPct) ? Math.max(0, bufferPct) : 2;
  if (!calc) {
    return {
      glassSqft: 0,
      faceSqft: 0,
      installSqft: 0,
      freshRawSqft: 0,
      cutAreaRawSqft: 0,
      savedSqft: 0,
      quoteSqft: 0,
      bufferPct: 2,
      filmToGlassRatio: null,
      scrapReuseRatio: null,
    };
  }
  const glass = Math.max(
    0,
    Number(calc.glass_area_raw_sqft ?? calc.engine?.summary?.glass_raw_sqft ?? calc.face_sqft ?? 0) || 0,
  );
  const face = Math.max(0, Number(calc.face_sqft ?? calc.engine?.summary?.face_sqft ?? glass) || 0);
  const install = Math.max(0, Number(calc.install_sqft ?? calc.engine?.summary?.install_sqft ?? 0) || 0);
  const fresh = Math.max(0, Number(calc.fresh_raw_sqft ?? calc.engine?.summary?.fresh_raw_sqft ?? 0) || 0);
  const cut = Math.max(0, Number(calc.cut_area_raw_sqft ?? 0) || 0);
  const saved = Math.max(0, Number(calc.saved_sqft ?? calc.engine?.summary?.saved_sqft ?? 0) || 0);
  const quote = Number(calc.quote_area_sqft) > 0
    ? Math.ceil(Number(calc.quote_area_sqft) - 1e-9)
    : ceilQuoteSqft(fresh, bufferSqft);
  return {
    glassSqft: glass,
    faceSqft: face,
    installSqft: install,
    freshRawSqft: fresh,
    cutAreaRawSqft: cut,
    savedSqft: saved,
    quoteSqft: quote,
    bufferPct: bufferSqft,
    filmToGlassRatio: glass > 0 ? install / glass : null,
    scrapReuseRatio: cut > 0 ? saved / cut : null,
  };
}

/** รวมหลาย breakdown (เช่น หลายกลุ่มฟิล์ม) — บวกบัฟเฟอร์ 2 ตร.ฟุตครั้งเดียวจากผลรวมฟิล์มดึงจากม้วน */
export function mergeAreaBreakdowns(
  parts: AreaBreakdown[],
  bufferPct?: number,
): AreaBreakdown {
  const bufferSqft = Number.isFinite(bufferPct) ? Math.max(0, Number(bufferPct)) : 2;
  const glass = parts.reduce((s, p) => s + p.glassSqft, 0);
  const face = parts.reduce((s, p) => s + p.faceSqft, 0);
  const install = parts.reduce((s, p) => s + p.installSqft, 0);
  const fresh = parts.reduce((s, p) => s + p.freshRawSqft, 0);
  const cut = parts.reduce((s, p) => s + p.cutAreaRawSqft, 0);
  const saved = parts.reduce((s, p) => s + p.savedSqft, 0);
  return {
    glassSqft: glass,
    faceSqft: face,
    installSqft: install,
    freshRawSqft: fresh,
    cutAreaRawSqft: cut,
    savedSqft: saved,
    quoteSqft: ceilQuoteSqft(fresh, bufferSqft),
    bufferPct: bufferSqft,
    filmToGlassRatio: glass > 0 ? install / glass : null,
    scrapReuseRatio: cut > 0 ? saved / cut : null,
  };
}

/** ข้อความสรุปสั้นสำหรับผู้ใช้: ไม่แสดงสูตร อัตราส่วนภายใน หรือศัพท์ของเอ็นจิ้น */
export function formatAreaAnalysisSummary(a: AreaBreakdown): string {
  return [
    `พื้นที่กระจกที่วัดได้ ${formatSqftPrecise(a.glassSqft)}`,
    `พื้นที่ชิ้นฟิล์มตัดหยาบรวม ${formatSqftPrecise(a.cutAreaRawSqft)}`,
    `ฟิล์มใหม่ที่ดึงจากม้วน ${formatSqftPrecise(a.freshRawSqft)}`,
    `ประหยัดจากการใช้เศษ ${formatSqftPrecise(a.savedSqft)}`,
    `พื้นที่เสนอราคา ${formatSqft(a.quoteSqft)} (ฟิล์มดึงจากม้วน + 2 ตร.ฟุต)`,
  ].join(" · ");
}
