export const SYSTEM_VERSION = "10.36.1" as const;
