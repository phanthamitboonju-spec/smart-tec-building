import { CATALOG } from "./catalog-data.ts";

export interface Product {
  skuId: string; code: string; codeNorm: string; modelKey: string;
  brand: string; brandKey: string; familyKey: string; familyName: string;
  name: string; category: string; filmType: string; intensity: string;
  group: string; price: number; sortKey: number; selectable: boolean;
  identifierKind: "sku" | "reference"; priceStatus: "active" | "contact";
  rollWidthCm?: number | null; rollLengthM?: number | null;
  [key: string]: unknown;
}

type CatalogPayload = { products: Product[] };
export const PRODUCTS: Product[] = (CATALOG as unknown as CatalogPayload).products;
export function normalizeProductCode(value: string): string {
  return String(value ?? "").trim().toUpperCase().replace(/\s+/g, "");
}
export function findProductByCode(code: string, products: Product[] = PRODUCTS, brand?: string): Product | null {
  const normalized = normalizeProductCode(code);
  const brandKey = String(brand ?? "").trim().toLowerCase();
  return products.find((product) => product.codeNorm === normalized && (!brandKey || product.brandKey.toLowerCase() === brandKey)) ?? null;
}
