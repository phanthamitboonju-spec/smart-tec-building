/**
 * SmartTec Film Engine — Pure TypeScript calculation layer (no DOM, no side-effects)
 * Source of truth for layout / join / area / scrap planning
 * UI, PDF and the calculation bot must only display or summarize results from this module
 * @version 10.36.1
 */

import { SYSTEM_VERSION } from "../version.ts";
import type { QuotationSnapshot } from "../domain/quotation.ts";
import { CM2_PER_SQFT, ceilDimensionCm } from "../domain/units.ts";
import { checkScrapReuseCompatibility, checkScrapPaneBoundary, checkSpliceCompatibility, validatePaneSeamLayout, seamAxisFromOrient, SPLICE_LAYOUT_POLICY, type MaterialOrientationSpec, type SpliceCheckStatus } from "../domain/material-orientation.ts";

export type DimensionDisplayUnit = "mm" | "cm" | "m" | "in" | "ft";
export type AreaDisplayUnit = "sqft" | "m2" | "cm2" | "in2";
export interface AdditionalCostItem { id: string; label: string; amount: number; }

export interface EngineConfig {
  filmMax: number;
  rollLen: number;
  margin: number;
  /** Reserved compatibility metadata; the current cutting layout does not model a cut gap. */
  edgeGapMm?: number;
  divisor: number;
  scrapMin: number;
  /** Extra cut length per resulting strip when a pane requires a splice; zero is the default. */
  spliceAllowanceCm: number;
  /** Global display preferences; canonical calculation units are unchanged. */
  dimensionUnit: DimensionDisplayUnit;
  areaUnit: AreaDisplayUnit;
  quoteBufferPct: number;
  travelRatePerKm: number;
  scaffoldPricePerTier: number;
  additionalCostsEnabled: boolean;
  additionalCostItems: AdditionalCostItem[];
  /** Seller identity and default quotation terms; blank details are shown as blanks on the quote. */
  companyName: string;
  companyAddress: string;
  companyTaxId: string;
  companyPhone: string;
  companyEmail: string;
  quoteValidityDays: number;
  quotePaymentTerms: string;
  quoteDeliveryTimeline: string;
  /** แผ่นต่อสุดท้ายแคบสุดที่ยอมรับ (ซม.) — แคบกว่านี้จะแบ่งสมดุลใหม่ ไม่ปล่อยเป็นริ้วบาง */
  minStrip?: number;
  version: string;
  jobProfile?: string;
  materialOrientation?: Partial<MaterialOrientationSpec>;
  /** Internal planner effort: quick for candidate scoring, full for a committed group plan. */
  optimizerEffort?: "quick" | "full";
}

export const DEFAULT_ENGINE_CONFIG: EngineConfig = {
  filmMax: 152,
  rollLen: 3000,
  margin: 2,
  edgeGapMm: 0,
  divisor: CM2_PER_SQFT,
  scrapMin: 0,
  spliceAllowanceCm: 0,
  dimensionUnit: "cm",
  areaUnit: "sqft",
  quoteBufferPct: 2,
  travelRatePerKm: 0,
  scaffoldPricePerTier: 0,
  additionalCostsEnabled: false,
  additionalCostItems: [],
  companyName: "SmartTec",
  companyAddress: "",
  companyTaxId: "",
  companyPhone: "",
  companyEmail: "",
  quoteValidityDays: 15,
  quotePaymentTerms: "ชำระตามเงื่อนไขที่ตกลงร่วมกัน",
  quoteDeliveryTimeline: "กำหนดวันติดตั้งตามการนัดหมายและความพร้อมของพื้นที่",
  minStrip: 15,
  version: SYSTEM_VERSION,
  jobProfile: "general",
  materialOrientation: { face: "unknown", factoryEdge: "unknown", policy: "unknown" },
  optimizerEffort: "full",
};

let _cfg: EngineConfig = { ...DEFAULT_ENGINE_CONFIG, materialOrientation: { ...DEFAULT_ENGINE_CONFIG.materialOrientation } };

function clamp(key: keyof EngineConfig, value: number): number {
  const ranges: Partial<Record<keyof EngineConfig, { min: number; max: number }>> = {
    filmMax: { min: 50, max: 300 },
    rollLen: { min: 100, max: 20000 },
    margin: { min: 0, max: 20 },
    edgeGapMm: { min: 0, max: 10 },
    scrapMin: { min: 0, max: 50 },
    spliceAllowanceCm: { min: 0, max: 50 },
    quoteBufferPct: { min: 0, max: 100 },
    travelRatePerKm: { min: 0, max: 100000 },
    scaffoldPricePerTier: { min: 0, max: 1000000 },
    quoteValidityDays: { min: 1, max: 365 },
    minStrip: { min: 0, max: 60 },
  };
  const r = ranges[key];
  if (!r) return value;
  return Math.min(r.max, Math.max(r.min, value));
}

export function normalizeEngineConfig(
  input: Partial<EngineConfig> = {},
  base: EngineConfig = DEFAULT_ENGINE_CONFIG,
): EngineConfig {
  const next: EngineConfig = {
    ...base,
    materialOrientation: { ...(base.materialOrientation ?? {}) },
  };
  for (const [k, v] of Object.entries(input)) {
    if (v === undefined || v === null || v === "") continue;
    if (["version", "jobProfile", "companyName", "companyAddress", "companyTaxId", "companyPhone", "companyEmail", "quotePaymentTerms", "quoteDeliveryTimeline"].includes(k)) {
      const maxLength = k === "companyAddress" || k === "quotePaymentTerms" || k === "quoteDeliveryTimeline" ? 500 : 200;
      (next as unknown as Record<string, unknown>)[k] = String(v).trim().slice(0, maxLength);
      continue;
    }
    if (k === "dimensionUnit") {
      if (v === "mm" || v === "cm" || v === "m" || v === "in" || v === "ft") next.dimensionUnit = v;
      continue;
    }
    if (k === "areaUnit") {
      if (v === "sqft" || v === "m2" || v === "cm2" || v === "in2") next.areaUnit = v;
      continue;
    }
    if (k === "optimizerEffort") {
      next.optimizerEffort = v === "quick" ? "quick" : "full";
      continue;
    }
    if (k === "additionalCostsEnabled") {
      next.additionalCostsEnabled = v === true;
      continue;
    }
    if (k === "additionalCostItems" && Array.isArray(v)) {
      next.additionalCostItems = v.slice(0, 20).flatMap((item, index) => {
        if (!item || typeof item !== "object" || Array.isArray(item)) return [];
        const row = item as unknown as Record<string, unknown>;
        const label = String(row.label ?? "").trim().slice(0, 120);
        const amount = Number(row.amount);
        const id = String(row.id ?? `extra-${index + 1}`).replace(/[^a-zA-Z0-9_-]/g, "-").slice(0, 48);
        if (!label || !Number.isFinite(amount) || amount < 0) return [];
        return [{ id: id || `extra-${index + 1}`, label, amount: Math.min(10000000, amount) }];
      });
      continue;
    }
    if (k === "materialOrientation" && typeof v === "object" && !Array.isArray(v)) {
      // Preserve every supported material constraint through config normalization.
      // Previously only policy/face/factoryEdge survived, silently dropping allowedRotations,
      // SKU, roll/Lot identity and splice requirements from job-level settings.
      const orientation = v as Record<string, unknown>;
      const merged = { ...(next.materialOrientation ?? {}), ...orientation };
      const policy = merged.policy;
      const face = merged.face;
      const factoryEdge = merged.factoryEdge;
      const rotations = Array.isArray(merged.allowedRotations)
        ? merged.allowedRotations.filter((n): n is 0 | 90 | 180 | 270 => n === 0 || n === 90 || n === 180 || n === 270)
        : undefined;
      next.materialOrientation = {
        ...(typeof merged.sku === "string" ? { sku: merged.sku } : {}),
        ...(typeof merged.rollId === "string" ? { rollId: merged.rollId } : {}),
        ...(typeof merged.lotId === "string" ? { lotId: merged.lotId } : {}),
        ...(policy === "standard" || policy === "directional" || policy === "unknown" ? { policy } : {}),
        ...(face === "A" || face === "B" || face === "unknown" ? { face } : {}),
        ...(factoryEdge === "A" || factoryEdge === "B" || factoryEdge === "unknown" ? { factoryEdge } : {}),
        ...(rotations !== undefined ? { allowedRotations: rotations } : {}),
        ...(typeof merged.flipAllowed === "boolean" ? { flipAllowed: merged.flipAllowed } : {}),
        ...(typeof merged.sameRollForSplice === "boolean" ? { sameRollForSplice: merged.sameRollForSplice } : {}),
        ...(typeof merged.sameLotForSplice === "boolean" ? { sameLotForSplice: merged.sameLotForSplice } : {}),
        ...(typeof merged.factoryEdgeRequiredForSplice === "boolean" ? { factoryEdgeRequiredForSplice: merged.factoryEdgeRequiredForSplice } : {}),
        ...(typeof merged.specVerified === "boolean" ? { specVerified: merged.specVerified } : {}),
        ...(typeof merged.specSource === "string" ? { specSource: merged.specSource.slice(0, 500) } : {}),
      };
      continue;
    }
    if (typeof v === "number" && Number.isFinite(v)) {
      (next as unknown as Record<string, unknown>)[k] = clamp(k as keyof EngineConfig, v);
    }
  }
  // Compatibility fields are intentionally not configurable until their behavior
  // is implemented and tested. They must not imply an effect they do not have.
  next.edgeGapMm = 0;
  // Physical constant; incoming JSON can never override the unit conversion.
  next.divisor = CM2_PER_SQFT;
  if (!next.version) next.version = SYSTEM_VERSION;
  return next;
}

export function setConfig(partial: Partial<EngineConfig> = {}): EngineConfig {
  _cfg = normalizeEngineConfig(partial, _cfg);
  return getConfig();
}
export function getConfig(): EngineConfig {
  return { ..._cfg };
}

export function resetConfig(): EngineConfig {
  _cfg = { ...DEFAULT_ENGINE_CONFIG, materialOrientation: { ...DEFAULT_ENGINE_CONFIG.materialOrientation } };
  return getConfig();
}

/** Effective width after margin */
export function colE(w: number, m?: number): number {
  if (!w || w === 0) return 0;
  return +w + 2 * (m != null ? m : _cfg.margin);
}

/** Effective height after margin */
export function colF(h: number, m?: number): number {
  if (!h || h === 0) return 0;
  return +h + 2 * (m != null ? m : _cfg.margin);
}

export function mustJoinByRule(w: number, h: number, cfg?: Partial<EngineConfig>): boolean {
  const c = { ..._cfg, ...cfg };
  const FM = Number(c.filmMax) || 152;
  if (!(w > 0) || !(h > 0) || !(FM > 0)) return false;
  // Parameters are measured glass dimensions; use the same per-side margin rule as calculateJob.
  return colE(w, c.margin) > FM + 1e-9 && colF(h, c.margin) > FM + 1e-9;
}

export interface LayoutResult {
  I: number;
  J: number;
  K: number;
  M: number;
  L: string;
  PW: number;
  seams: string;
  material: number;
  feasible?: boolean;
}

export function computeLayout(
  E: number,
  F: number,
  FM?: number,
  dir: "V" | "H" | "auto" = "auto",
  autoPW = 1,
  materialSpec?: Partial<MaterialOrientationSpec>,
): LayoutResult {
  const filmMax = FM ?? _cfg.filmMax;
  if (!Number.isFinite(E) || !Number.isFinite(F) || !Number.isFinite(filmMax) || E <= 0 || F <= 0 || filmMax <= 0) {
    return { I: 0, J: 0, K: 0, M: 0, L: "INVALID", PW: autoPW, seams: "invalid", material: 0, feasible: false };
  }
  const spec = materialSpec ?? _cfg.materialOrientation ?? {};
  const overlap = spec.spliceMethod === "overlay" || spec.spliceMethod === "overlap-cut-through"
    ? Number(spec.spliceOverlapCm ?? 0)
    : 0;
  const panelCount = (across: number) => {
    if (across <= filmMax + 1e-9) return 1;
    if (overlap < 0 || overlap >= filmMax) return Number.POSITIVE_INFINITY;
    const advance = filmMax - overlap;
    return Math.ceil((across - overlap - 1e-9) / advance);
  };
  const blocked = (axis: "V" | "H"): LayoutResult => ({ I: 0, J: 0, K: 0, M: 0, L: "NO_FEASIBLE_PLAN", PW: axis === "V" ? 0 : 1, seams: "invalid", material: 0, feasible: false });
  const run = (axis: "V" | "H"): LayoutResult => {
    const across = axis === "V" ? E : F;
    const along = axis === "V" ? F : E;
    const M = panelCount(across);
    if (M > 2 || M < 1 || !Number.isFinite(M) || (M > 1 && spec.spliceMethod === "forbidden")) return blocked(axis);
    const panelWidth = Math.min(filmMax, across);
    const cutAcross = M === 1 ? across : across + (M - 1) * overlap;
    const last = cutAcross - (M - 1) * filmMax;
    return {
      I: panelWidth,
      J: along,
      K: Math.max(0, filmMax - Math.min(filmMax, last)),
      M,
      L: M > 1 ? "JOIN" : "OK",
      PW: axis === "V" ? 0 : 1,
      seams: M > 1 ? axis : "none",
      material: (M === 1 ? across : cutAcross) * along,
      feasible: true,
    };
  };

  // If either glass dimension fits the usable roll width, rotate the one-piece sheet.
  const vFit = E <= filmMax + 1e-9;
  const hFit = F <= filmMax + 1e-9;
  if (vFit || hFit) {
    const chosen = dir === "H" && hFit ? "H" : dir === "V" && vFit ? "V" : vFit ? "V" : "H";
    return run(chosen);
  }

  const v = run("V");
  const h = run("H");
  if (dir === "V") return v;
  if (dir === "H") return h;
  if (!v.feasible && !h.feasible) return blocked("V");
  if (!v.feasible) return h;
  if (!h.feasible) return v;
  // Prefer fewer panels (therefore fewer seam lines); compare material only on a tie.
  if (v.M !== h.M) return v.M < h.M ? v : h;
  return v.material <= h.material ? v : h;
}

export function calcAreaRaw(M: number, filmMax: number, pullLen: number, divisor?: number): number {
  if (!M || M === 0) return 0;
  const div = CM2_PER_SQFT;
  return (M * filmMax * pullLen) / div;
}

export function calcAreaRounded(areaRaw: number, qty = 1): number {
  if (!Number.isFinite(areaRaw) || !Number.isFinite(qty) || areaRaw <= 0 || qty <= 0) return 0;
  // Round once after multiplying the raw per-unit area by quantity.
  // Rounding each unit first can materially overstate area for many small panes.
  return Math.ceil(areaRaw * qty - 1e-9);
}

export function fmtDim(n: number | null | undefined): string {
  if (n == null || isNaN(+n)) return "—";
  return String(Math.round(+n));
}

export function fmtAreaSqft(n: number | null | undefined): string {
  if (n == null || isNaN(+n)) return "0";
  return String(Math.round(+n));
}

export type FilmFace = "A" | "B" | "unknown";

export interface PaneInput {
  width_cm?: number;
  height_cm?: number;
  raw_width_cm?: number;
  raw_height_cm?: number;
  w?: number;
  h?: number;
  qty?: number;
  dir?: string;
  width?: number;
  height?: number;
  face?: FilmFace | string;
  material?: Partial<MaterialOrientationSpec>;
  id?: string;
  /** Stable family key for repeated physical panes of the same geometry/specification. */
  familyId?: string;
  /** Total physical panes in the family across the complete job (precomputed by the planner). */
  familyCount?: number;
}

export interface RollDetail {
  pulls: number;
  dir: string;
  I: number;
  J: number;
  K: number;
}

export interface ScrapSource {
  scrap_id: string;
  from_pane: number;
  from_pane_global?: boolean;
  from_roll_id?: string;
  from_roll_label?: string;
  w: number;
  h: number;
  face: FilmFace;
}

export interface PaneCalcRow {
  index: number;
  /** Ceil-rounded dimensions used for cutting layout. */
  width_cm: number;
  height_cm: number;
  /** Original measured glass dimensions, preserved for physical glass-area reporting. */
  actual_width_cm: number;
  actual_height_cm: number;
  qty: number;
  afterW: number;
  afterH: number;
  dir: string;
  install_sqft: number;
  face_sqft: number;
  paired: boolean;
  donor: number | null;
  rollPulls: number;
  rollCount: number;
  scrapCount: number;
  rollDetails: RollDetail[];
  scrapSources: ScrapSource[];
  face: FilmFace;
  /** จำนวนแผ่นฟิล์มทั้งหมดที่บานนี้ต้องใช้ (ทั้งตัดใหม่และจากเศษ) */
  pieces?: number;
  /** จำนวนรอยต่อของบานนี้ (ทุกชิ้นในบาน) */
  seams?: number;
  /** Physical roll assignment used by the optional multi-roll planner. */
  roll_id?: string;
  roll_label?: string;
  /** รายละเอียดชิ้นฟิล์มสำหรับแผนตัด/ใบสั่งงานช่าง (เป็นผลจากแผนที่คำนวณแล้ว ไม่ใช่สูตรชุดใหม่) */
  cutPieces?: CutPieceDetail[];
}

export interface GeneratedScrapDetail {
  id: string;
  width_cm: number;
  height_cm: number;
  reusable: boolean;
  source_pull_no?: number;
  origin_pane_index?: number;
  created_by_pane_index?: number;
  roll_id?: string;
  roll_label?: string;
  created_by_roll_id?: string;
  origin_pane_global?: boolean;
  created_by_pane_global?: boolean;
}

export interface CutPieceDetail {
  piece_id: string;
  /** ลำดับการตัดจริงทั้งงาน */
  sequence: number;
  source: "fresh" | "scrap";
  cut_width_cm: number;
  cut_length_cm: number;
  orientation: Orient;
  rotated: boolean;
  /** เลขครั้งที่ดึงฟิล์มใหม่จากม้วน — มีเฉพาะ source=fresh */
  pull_no?: number;
  /** รหัสเศษชิ้นที่นำมาตัดใช้ */
  scrap_id?: string;
  /** บานต้นทางเดิมของฟิล์มเศษ */
  from_pane?: number;
  from_pane_global?: boolean;
  from_roll_id?: string;
  from_roll_label?: string;
  /** บานล่าสุดที่ตัดแล้วเกิดเศษชิ้นนี้ต่อ */
  scrap_created_by_pane?: number;
  scrap_created_by_pane_global?: boolean;
  source_pull_no?: number;
  created_scraps?: GeneratedScrapDetail[];
  roll_id?: string;
  roll_label?: string;
}

export interface FinalScrap {
  id: string;
  w: number;
  h: number;
  width_cm: number;
  height_cm: number;
  face: FilmFace;
  pane_id: string;
  from: string;
  uid: string;
  family_id?: string;
  family_count?: number;
  material?: Partial<MaterialOrientationSpec>;
  /** true = ขนาดผ่านเกณฑ์สำหรับเก็บไว้พิจารณาใช้ในงานถัดไป */
  reusable: boolean;
  source_pull_no?: number;
  origin_pane_index?: number;
  created_by_pane_index?: number;
  parent_scrap_id?: string;
  area_cm2: number;
  status_note_th: string;
  roll_id?: string;
  roll_label?: string;
  origin_pane_global?: boolean;
  created_by_pane_global?: boolean;
  created_by_uid?: string;
  created_by_roll_id?: string;
}

export interface EnginePublicConfig {
  filmMax: number;
  margin: number;
  edgeGapMm: number;
  divisor: number;
  rollLen: number;
  scrapMin: number;
  jobProfile: string;
  version: string;
  /** Physical-roll settings captured with the stored plan. */
  roll_plan_enabled?: boolean;
  roll_profiles?: Array<{ id: string; label: string; width_cm: number; length_cm: number; lotId?: string; directionKey?: string; planningGroupId?: string; policy?: string; face?: string; factoryEdge?: string; allowedRotations?: Array<0 | 90 | 180 | 270>; sameRollForSplice?: boolean; sameLotForSplice?: boolean; sameDirectionForSplice?: boolean; sameLotForReuse?: boolean; sameRollForReuse?: boolean; sameDirectionForReuse?: boolean; factoryEdgeRequiredForSplice?: boolean; doubleCutSeamForbidden?: boolean; specSource?: string; specVerified?: boolean; spliceMethod?: "butt" | "overlay" | "overlap-cut-through" | "forbidden" | "unknown"; spliceOverlapCm?: number }>;
  quotation?: QuotationSnapshot;
  /** Display units captured with a stored plan. Canonical math stays in cm / sqft. */
  dimensionUnit?: "mm" | "cm" | "m" | "in" | "ft";
  areaUnit?: "sqft" | "m2" | "cm2" | "in2";
  /** Extra square feet added once to the quoted area. */
  quoteBufferPct?: number;
}

export interface CalcEvent {
  type: string;
  pane: number;
  dir?: string;
  M?: number;
  K?: number;
  J?: number;
  from_pane?: number;
  from_pane_global?: boolean;
  from_roll_id?: string;
  scrap_id?: string;
  w?: number;
  h?: number;
  roll_id?: string;
  roll_label?: string;
}

export interface RollUsageSummary {
  roll_id: string;
  label: string;
  width_cm: number;
  length_cm: number;
  lot_id?: string;
  pane_indices: number[];
  glass_sqft: number;
  install_sqft: number;
  fresh_raw_sqft: number;
  fresh_pull_cm: number;
  length_remaining_cm: number;
  pulls: number;
  seams: number;
  reusable_scrap_pieces: number;
  reusable_scrap_cm2: number;
  waste_scrap_pieces: number;
  waste_scrap_cm2: number;
}

export interface JobCalcResult {
  version: string;
  config: EnginePublicConfig;
  panes: PaneCalcRow[];
  summary: {
    install_sqft: number;
    fresh_sqft: number;
    naive_install_sqft: number;
    saved_sqft: number;
    face_sqft: number;
    pulls: number;
    seams: number;
    paired: number;
    scrap_used_pieces: number;
    scrap_used_cm2: number;
    final_scrap_pieces: number;
    final_scrap_cm2: number;
    final_scrap_sqft: number;
    reusable_scrap_pieces: number;
    reusable_scrap_cm2: number;
    waste_scrap_pieces: number;
    waste_scrap_cm2: number;
    waste_scrap_sqft: number;
    waste_cm2: number;
    /** True raw glass area (not rounded), square feet. */
    glass_raw_sqft?: number;
    /** Number of deterministic heuristic trials used for whole-job planning. */
    optimizer_trials?: number;
    /** This is a bounded heuristic search; it does not claim a mathematical optimum. */
    optimization_is_exact?: false;
    optimization_method?: "deterministic-multi-start-global-search" | "deterministic-heuristic";
    /** จำนวนแผ่นฟิล์มทั้งงาน (ตัดใหม่ + จากเศษ) */
    pieces?: number;
    /** พื้นที่ฟิล์มที่ดึงจากม้วนจริงก่อนปัดเศษ (ตร.ฟ.) */
    fresh_raw_sqft?: number;
    plan: "per-pane" | "global-scrap";
    plan_order: string;
    note_th: string;
    fresh_pull_cm: number;
    required_rolls: number;
    orientation_status: SpliceCheckStatus;
    orientation_warnings: string[];
    /** Present only for the isolated physical-roll planning mode. */
    roll_usage?: RollUsageSummary[];
    /** Unused tail of the physical roll after the last pull, centimetres. */
    roll_end_waste_cm?: number;
  };
  events: CalcEvent[];
  finalScraps: FinalScrap[];
  glassAreaCm2: number;
  glassAreaSqft: number;
  installAreaSqft: number;
}

interface ScrapBit {
  id: string;
  w: number;
  h: number;
  face: FilmFace;
  /** บานต้นทางเดิมที่ดึงฟิล์มชิ้นนี้มาจากม้วน */
  fromPane: number;
  fromUid: string;
  /** Pane Family identity; repeated quantity units share a family key. */
  familyId?: string;
  familyCount?: number;
  /** เลขครั้งดึงม้วนที่เป็นต้นทางของเศษ */
  sourcePullNo?: number;
  /** บานที่ตัดครั้งล่าสุดแล้วเกิดเศษชิ้นปัจจุบัน */
  createdByPane?: number;
  createdByUid?: string;
  parentScrapId?: string;
  material?: Partial<MaterialOrientationSpec>;
  /** Origin metadata retained when an offcut is shared across connected physical rolls. */
  rollId?: string;
  rollLabel?: string;
  createdByRollId?: string;
  fromPaneGlobal?: boolean;
  createdByPaneGlobal?: boolean;
}

/** A physical offcut carried from another roll explicitly connected to this job plan. */
export interface EngineScrapInput {
  id: string;
  width_cm: number;
  height_cm: number;
  face: FilmFace;
  from_pane: number;
  from_uid: string;
  created_by_pane?: number;
  created_by_uid?: string;
  family_id?: string;
  family_count?: number;
  source_pull_no?: number;
  parent_scrap_id?: string;
  material?: Partial<MaterialOrientationSpec>;
  roll_id: string;
  roll_label?: string;
  from_pane_global?: boolean;
  created_by_pane_global?: boolean;
  created_by_roll_id?: string;
}

function scrapRotationAllowed(_spec: Partial<MaterialOrientationSpec> | undefined, _rotated: boolean): boolean {
  // The whole-job optimizer may quarter-turn a compatible offcut when this gives a better
  // complete-job plan. SKU orientation metadata is surfaced as a warning after selection;
  // it does not remove geometric candidates from the optimizer. Material identity, face,
  // Lot/Roll and explicit reuse incompatibilities are still enforced separately.
  return true;
}

type Orient = "V" | "H";

interface UnitPlan {
  uid: string;
  familyId?: string;
  familyCount: number;
  paneIdx: number;
  paneIndex: number;
  qtyIndex: number;
  E: number;
  F: number;
  W: number;
  H: number;
  forceDir: Orient | null;
  face: FilmFace;
  material?: Partial<MaterialOrientationSpec>;
}

function asFace(v: unknown): FilmFace {
  if (v === "A" || v === "B") return v;
  return "unknown";
}

function facesOk(a: FilmFace, b: FilmFace): boolean {
  if (a === "unknown" || b === "unknown") return true;
  return a === b;
}

function usable(w: number, h: number, scrapMin: number): boolean {
  return w > 1e-6 && h > 1e-6 && Math.min(w, h) + 1e-9 >= scrapMin;
}

function remainderPieces(sw: number, sh: number, nw: number, nh: number, scrapMin: number): Array<{ w: number; h: number }> {
  // Two valid guillotine layouts. Keep every physical remnant, including strips
  // too small for reuse, so the final report reconciles to the material drawn.
  const patterns = [
    [{ w: sw - nw, h: sh }, { w: nw, h: sh - nh }],
    [{ w: sw, h: sh - nh }, { w: sw - nw, h: nh }],
  ].map((pattern) => pattern.filter((p) => p.w > 1e-6 && p.h > 1e-6));
  const score = (parts: Array<{ w: number; h: number }>) => {
    const reusable = parts.filter((part) => usable(part.w, part.h, scrapMin));
    const unusable = parts.filter((part) => !usable(part.w, part.h, scrapMin));
    return {
      unusableArea: unusable.reduce((sum, part) => sum + part.w * part.h, 0),
      reusableArea: reusable.reduce((sum, part) => sum + part.w * part.h, 0),
      reusableCount: reusable.length,
      physicalCount: parts.length,
    };
  };
  const [a, b] = patterns;
  const sa = score(a);
  const sb = score(b);
  if (Math.abs(sa.unusableArea - sb.unusableArea) > 1e-6) return sa.unusableArea < sb.unusableArea ? a : b;
  if (Math.abs(sa.reusableArea - sb.reusableArea) > 1e-6) return sa.reusableArea > sb.reusableArea ? a : b;
  if (sa.physicalCount !== sb.physicalCount) return sa.physicalCount < sb.physicalCount ? a : b;
  return sa.reusableCount >= sb.reusableCount ? a : b;
}

function offcutDetail(scrap: ScrapBit, scrapMin: number): GeneratedScrapDetail {
  return {
    id: scrap.id,
    width_cm: scrap.w,
    height_cm: scrap.h,
    reusable: usable(scrap.w, scrap.h, scrapMin),
    source_pull_no: scrap.sourcePullNo,
    origin_pane_index: scrap.fromPane,
    created_by_pane_index: scrap.createdByPane,
    roll_id: scrap.rollId,
    roll_label: scrap.rollLabel,
    created_by_roll_id: scrap.createdByRollId,
    origin_pane_global: scrap.fromPaneGlobal,
    created_by_pane_global: scrap.createdByPaneGlobal,
  };
}

interface FutureNeed {
  w: number;
  h: number;
  full: boolean;
  unit: UnitPlan;
}

function canScrapServeNeed(scrap: ScrapBit, need: FutureNeed, scrapMin: number): boolean {
  if (!usable(scrap.w, scrap.h, scrapMin) || need.full) return false;
  if (checkScrapPaneBoundary(scrap, need.unit.uid, { familyId: need.unit.familyId, familyCount: need.unit.familyCount }).status !== "pass") return false;
  if (!facesOk(scrap.face, need.unit.face)) return false;
  // REVIEW means the material metadata is incomplete, not that the offcut is physically
  // incompatible. Keep it in the provisional optimizer pool and surface the review warning
  // in the final plan. Only an explicit BLOCK may exclude a candidate here.
  if (checkScrapReuseCompatibility(scrap.material, need.unit.material).status === "block") return false;
  const direct = scrap.w + 1e-9 >= need.w && scrap.h + 1e-9 >= need.h;
  const rotated = scrapRotationAllowed(scrap.material, true) &&
    scrapRotationAllowed(need.unit.material, true) &&
    scrap.w + 1e-9 >= need.h && scrap.h + 1e-9 >= need.w &&
    Math.abs(need.w - need.h) > 1e-9;
  return direct || rotated;
}

/**
 * Score a candidate offcut pool against the upcoming demands, not only the immediate cut.
 * This is a bounded look-ahead matching heuristic: constrained pieces get first choice and each
 * offcut can cover at most one future piece in this estimate. The full simulator then evaluates
 * the actual downstream plan and its newly generated offcuts.
 */
function lookAheadReuseScore(pool: ScrapBit[], needs: FutureNeed[], scrapMin: number, maxNeeds = 12) {
  if (!needs.length || maxNeeds <= 0) return { count: 0, coveredArea: 0 };
  const available = pool.filter((scrap) => usable(scrap.w, scrap.h, scrapMin));
  // Assess every remaining demand first; only then limit the assignment simulation to the
  // globally most constrained demands. This is not simply the next 12 entered/cut panes.
  const pending = needs.filter((need) => !need.full).map((need) => ({ need, fits: 0 }));
  for (const row of pending) {
    row.fits = available.reduce((count, scrap) => count + (canScrapServeNeed(scrap, row.need, scrapMin) ? 1 : 0), 0);
  }
  // Demands that no currently available/remainder scrap can serve do not deserve a look-ahead
  // slot; prioritize the globally scarce demands that this pool can actually cover.
  const constrained = pending
    .filter((row) => row.fits > 0)
    .sort((a, b) => a.fits - b.fits || (b.need.w * b.need.h) - (a.need.w * a.need.h))
    .slice(0, maxNeeds);
  let count = 0;
  let coveredArea = 0;
  const left = [...available];
  for (const row of constrained) {
    let bestIndex = -1;
    let bestWaste = Number.POSITIVE_INFINITY;
    for (let i = 0; i < left.length; i++) {
      const scrap = left[i];
      if (!canScrapServeNeed(scrap, row.need, scrapMin)) continue;
      const directFits = scrap.w + 1e-9 >= row.need.w && scrap.h + 1e-9 >= row.need.h;
      const useW = directFits ? row.need.w : row.need.h;
      const useH = directFits ? row.need.h : row.need.w;
      const rem = remainderPieces(scrap.w, scrap.h, useW, useH, scrapMin);
      const remWaste = rem.filter((piece) => !usable(piece.w, piece.h, scrapMin)).reduce((sum, piece) => sum + piece.w * piece.h, 0);
      const excess = Math.max(0, scrap.w * scrap.h - useW * useH);
      const score = remWaste * 1000 + excess;
      if (score < bestWaste) {
        bestWaste = score;
        bestIndex = i;
      }
    }
    if (bestIndex >= 0) {
      left.splice(bestIndex, 1);
      count += 1;
      coveredArea += row.need.w * row.need.h;
    }
  }
  return { count, coveredArea };
}

function tryConsumeScrap(
  scraps: ScrapBit[],
  needW: number,
  needH: number,
  face: FilmFace,
  scrapMin: number,
  consumerMaterial?: Partial<MaterialOrientationSpec>,
  consumerUid?: string,
  consumerFamilyId?: string,
  consumerFamilyCount = 1,
  futureNeeds: FutureNeed[] = [],
  lookAheadLimit = 12,
): { scrap: ScrapBit; remainders: Array<{ w: number; h: number }>; usedW: number; usedH: number; rotated: boolean } | null {
  type RemainderScore = { futureCount: number; futureArea: number; unusableArea: number; reusableArea: number; physicalCount: number; totalArea: number };
  let best: { index: number; orient: { w: number; h: number }; remainders: Array<{ w: number; h: number }>; score: RemainderScore } | null = null;
  const scoreRemainders = (parts: Array<{ w: number; h: number }>, futurePool: ScrapBit[]): RemainderScore => {
    const reusable = parts.filter((part) => usable(part.w, part.h, scrapMin));
    const unusable = parts.filter((part) => !usable(part.w, part.h, scrapMin));
    const future = lookAheadReuseScore(futurePool, futureNeeds, scrapMin, lookAheadLimit);
    return {
      futureCount: future.count,
      futureArea: future.coveredArea,
      unusableArea: unusable.reduce((sum, part) => sum + part.w * part.h, 0),
      reusableArea: reusable.reduce((sum, part) => sum + part.w * part.h, 0),
      physicalCount: parts.length,
      totalArea: parts.reduce((sum, part) => sum + part.w * part.h, 0),
    };
  };
  const isBetterScore = (a: RemainderScore, b: RemainderScore) => {
    if (a.futureCount !== b.futureCount) return a.futureCount > b.futureCount;
    if (Math.abs(a.futureArea - b.futureArea) > 1e-6) return a.futureArea > b.futureArea;
    if (Math.abs(a.unusableArea - b.unusableArea) > 1e-6) return a.unusableArea < b.unusableArea;
    if (Math.abs(a.reusableArea - b.reusableArea) > 1e-6) return a.reusableArea > b.reusableArea;
    if (a.physicalCount !== b.physicalCount) return a.physicalCount < b.physicalCount;
    return a.totalArea < b.totalArea - 1e-6;
  };

  for (let i = 0; i < scraps.length; i++) {
    const scrap = scraps[i];
    if (!usable(scrap.w, scrap.h, scrapMin)) continue;
    // Same physical pane is never allowed. A sibling unit in the same Pane Family is allowed
    // only when that family contains at least two physical panes.
    if (checkScrapPaneBoundary(scrap, consumerUid, { familyId: consumerFamilyId, familyCount: consumerFamilyCount }).status !== "pass") continue;
    if (!facesOk(scrap.face, face)) continue;
    const compatibility = checkScrapReuseCompatibility(scrap.material, consumerMaterial);
    // REVIEW is a provisional allocation with a visible warning, so planning remains
    // automatic when optional metadata (SKU/face/Lot/orientation) has not been entered.
    // An explicit conflict or manufacturer prohibition still returns BLOCK and is rejected.
    if (compatibility.status === "block") continue;
    const orientations = [
      ...(scrap.w + 1e-9 >= needW && scrap.h + 1e-9 >= needH ? [{ w: needW, h: needH }] : []),
      ...(scrapRotationAllowed(scrap.material, true) && scrapRotationAllowed(consumerMaterial, true) && scrap.w + 1e-9 >= needH && scrap.h + 1e-9 >= needW && Math.abs(needW - needH) > 1e-9 ? [{ w: needH, h: needW }] : []),
    ];
    for (const orient of orientations) {
      const remainders = remainderPieces(scrap.w, scrap.h, orient.w, orient.h, scrapMin);
      const remainderScraps: ScrapBit[] = remainders.map((rem, ri) => ({
        ...scrap,
        id: `${scrap.id}-lookahead-${ri}`,
        w: rem.w,
        h: rem.h,
        parentScrapId: scrap.id,
      }));
      const futurePool = scraps.filter((_, index) => index !== i).concat(remainderScraps);
      const score = scoreRemainders(remainders, futurePool);
      if (!best || isBetterScore(score, best.score)) best = { index: i, orient, remainders, score };
    }
  }
  if (!best) return null;
  const scrap = scraps.splice(best.index, 1)[0];
  return {
    scrap,
    remainders: best.remainders,
    usedW: best.orient.w,
    usedH: best.orient.h,
    rotated: best.orient.w !== needW || best.orient.h !== needH,
  };
}

/* ───────────── การวางแผนระดับงาน (whole-job planner) ─────────────
 * แต่ละบานถูกแตกเป็น "แผ่นฟิล์ม" (piece) แล้วทุกแผ่นจากทุกบานลงในกองเดียวกัน
 * แผ่นใหญ่ถูกวางก่อน เศษที่เหลือจากการดึงฟิล์มใหม่ถูกใช้ข้ามบานได้ทั้งงาน
 * แนวตัดของแต่ละบาน (แนวตั้ง/แนวนอน) เลือกจากผลรวมทั้งงาน ไม่ได้เลือกทีละบาน
 */

interface Piece {
  unit: number;
  seq: number;
  /** ความกว้างที่ใช้ตามหน้ากว้างม้วน */
  w: number;
  /** ความยาวที่ดึงตามแนวม้วน */
  l: number;
  /** เต็มหน้ากว้างม้วนพอดี — ต้องดึงใหม่เสมอ ไม่มีเศษ */
  full: boolean;
}

interface Placement {
  piece: Piece;
  source: "fresh" | "scrap";
  /** ลำดับดึงใหม่จากม้วน (เฉพาะชิ้นที่มาจากม้วน) */
  pullNo?: number;
  scrapId?: string;
  fromPane?: number;
  fromPaneGlobal?: boolean;
  fromRollId?: string;
  fromRollLabel?: string;
  scrapCreatedByPane?: number;
  scrapCreatedByPaneGlobal?: boolean;
  sourcePullNo?: number;
  scrapMaterial?: Partial<MaterialOrientationSpec>;
  usedW?: number;
  usedH?: number;
  leftoverW?: number;
  rotated?: boolean;
  createdScraps?: GeneratedScrapDetail[];
}

interface SimResult {
  orients: Orient[];
  rawCm2: number;
  seams: number;
  pulls: number;
  freshLen: number;
  placements: Placement[];
  pieces: Piece[];
  scraps: ScrapBit[];
  scrapSeq: number;
  sequence: number[];
}

/** ค่า minStrip ของการคำนวณรอบปัจจุบัน (ฟังก์ชันภายในใช้ร่วมกัน; คำนวณแบบ synchronous จึงปลอดภัย) */
const MIN_STRIP_CTX = { v: 0 };

function choicesFor(unit: UnitPlan, FM: number, rollLen: number): Orient[] {
  const join = unit.E > FM + 1e-9 && unit.F > FM + 1e-9;
  const fitsV = unit.E <= FM + 1e-9;
  const fitsH = unit.F <= FM + 1e-9;
  const geometric: Orient[] = join ? ["V", "H"] : [...(fitsV ? (["V"] as Orient[]) : []), ...(fitsH ? (["H"] as Orient[]) : [])];
  // The long side of every strip must fit within the physical roll length.
  const spliceAllowed = unit.material?.spliceMethod !== "forbidden";
  const lengthValid = geometric.filter((orientation) => {
    const across = orientation === "V" ? unit.E : unit.F;
    const along = orientation === "V" ? unit.F : unit.E;
    const requiresSeam = across > FM + 1e-9;
    const overlay = unit.material?.spliceMethod === "overlay" || unit.material?.spliceMethod === "overlap-cut-through"
      ? Number(unit.material.spliceOverlapCm ?? 0)
      : 0;
    const panelCount = !requiresSeam ? 1 : (overlay >= 0 && overlay < FM
      ? Math.ceil((across - overlay - 1e-9) / (FM - overlay))
      : Number.POSITIVE_INFINITY);
    return along <= rollLen + 1e-9 && panelCount <= SPLICE_LAYOUT_POLICY.maxPanelsPerPane && (!requiresSeam || spliceAllowed);
  });
  if (!lengthValid.length) return [];
  // Auto mode evaluates every geometrically feasible quarter-turn (V/H) in the
  // whole-job optimizer. Unverified/directional SKU metadata must remain visible as a
  // warning, but it must not pre-filter candidates before the whole-job comparison.
  // A manually selected V/H direction remains the operator's preference when feasible.
  const allowed = lengthValid;
  if (unit.forceDir && allowed.includes(unit.forceDir)) return [unit.forceDir];
  return allowed;
}

function splitUnit(
  unit: UnitPlan,
  orient: Orient,
  FM: number,
  minStrip = 0,
  spliceAllowanceCm = 0,
): Array<{ w: number; l: number; full: boolean }> {
  const across = orient === "V" ? unit.E : unit.F;
  const along = orient === "V" ? unit.F : unit.E;
  if (across <= FM + 1e-9) return [{ w: across, l: along, full: across >= FM - 1e-9 }];
  const overlay = unit.material?.spliceMethod === "overlay" || unit.material?.spliceMethod === "overlap-cut-through"
    ? Number(unit.material.spliceOverlapCm ?? 0)
    : 0;
  if (overlay < 0 || overlay >= FM) throw new Error("ระยะซ้อนรอยต่อไม่ถูกต้องเมื่อเทียบกับหน้ากว้างฟิล์ม");
  const k = overlay > 0 ? Math.ceil((across - overlay - 1e-9) / (FM - overlay)) : Math.ceil((across - 1e-9) / FM);
  if (!Number.isInteger(k) || k < 2 || k > SPLICE_LAYOUT_POLICY.maxPanelsPerPane) {
    throw new Error("บานนี้ต้องใช้มากกว่า 2 แผ่นเต็มหรือมีมากกว่า 1 แนวรอยต่อ จึงไม่ผ่านกฎ One Continuous Seam");
  }
  const totalFilmWidth = across + Math.max(0, k - 1) * overlay;
  const widths: number[] = [];
  for (let i = 0; i < k - 1; i++) widths.push(FM);
  let r = totalFilmWidth - (k - 1) * FM;
  // หลักช่าง: ไม่ปล่อยแผ่นต่อเป็นริ้วแคบ (ติดยาก เห็นรอยต่อชัด) — ดึงส่วนจากแผ่นก่อนหน้ามาเติมให้แผ่นสุดท้ายกว้างพอ
  if (r < minStrip - 1e-9 && k >= 2 && minStrip <= FM) {
    const need = minStrip - r;
    widths[k - 2] = FM - need;
    r = minStrip;
  }
  widths.push(r);
  const safeAllowance = Number.isFinite(spliceAllowanceCm) ? Math.max(0, Math.min(50, spliceAllowanceCm)) : 0;
  return widths.map((w) => ({ w, l: along + safeAllowance, full: w >= FM - 1e-9 }));
}

/** วิธีเดิมแบบรายบาน: เลือกแนวที่เศษต่อบานน้อยกว่า — ใช้เป็นจุดเริ่มค้นหาและฐานเทียบ "ไม่ใช้เศษ" */
function legacyOrient(unit: UnitPlan, FM: number, rollLen: number, spliceAllowanceCm = 0): Orient {
  const options = choicesFor(unit, FM, rollLen);
  if (!options.length) throw new Error(`บาน ${unit.paneIndex}: ไม่มีแนวตัดที่ผ่านข้อกำหนดหน้ากว้างและความยาวม้วน`);
  if (options.length === 1) return options[0];
  const score = (o: Orient) => {
    const parts = splitUnit(unit, o, FM, MIN_STRIP_CTX.v, spliceAllowanceCm);
    const last = parts[parts.length - 1];
    return {
      stripCount: parts.length,
      unusableArea: parts.filter((part) => !usable(FM - part.w, part.l, 0)).reduce((sum, part) => sum + Math.max(0, FM - part.w) * part.l, 0),
      leftoverArea: last.full ? 0 : (FM - last.w) * last.l,
    };
  };
  const v = score("V");
  const h = score("H");
  // First minimize the number of seam lines; only then compare leftover material.
  if (v.stripCount !== h.stripCount) return v.stripCount < h.stripCount ? "V" : "H";
  if (Math.abs(v.unusableArea - h.unusableArea) > 1e-6) return v.unusableArea < h.unusableArea ? "V" : "H";
  return v.leftoverArea <= h.leftoverArea ? "V" : "H";
}

type PieceOrder = "area" | "width" | "donor" | "thin";

function simulate(
  units: UnitPlan[],
  orients: Orient[],
  FM: number,
  scrapMin: number,
  order: PieceOrder,
  reuse = true,
  override?: number[],
  spliceAllowanceCm = 0,
  lookAheadLimit = 12,
  initialScraps: ScrapBit[] = [],
): SimResult {
  const pieces: Piece[] = [];
  let seams = 0;
  units.forEach((unit, ui) => {
    const parts = splitUnit(unit, orients[ui], FM, MIN_STRIP_CTX.v, spliceAllowanceCm);
    seams += Math.max(0, parts.length - 1);
    parts.forEach((part, seq) => pieces.push({ unit: ui, seq, ...part }));
  });

  const sequence = (override && override.length === pieces.length ? override : pieces
    .map((_, i) => i)
    .sort((a, b) => {
      const pa = pieces[a];
      const pb = pieces[b];
      if (order === "width") {
        if (pb.w !== pa.w) return pb.w - pa.w;
        if (pb.l !== pa.l) return pb.l - pa.l;
      } else if (order === "donor" || order === "thin") {
        // แผ่นเต็มหน้ากว้างต้องดึงใหม่เสมออยู่แล้ว ทำก่อน; แผ่นแคบดึงใหม่แล้วเหลือเศษกว้าง จึงเป็น "ผู้ให้เศษ" ที่ดี
        if (pa.full !== pb.full) return pa.full ? -1 : 1;
        if (order === "thin" && pa.w !== pb.w) return pa.w - pb.w;
        const da = pa.w * pa.l;
        const db = pb.w * pb.l;
        if (db !== da) return db - da;
      } else {
        const da = pa.w * pa.l;
        const db = pb.w * pb.l;
        if (db !== da) return db - da;
      }
      return a - b;
    })).slice();

  // Connected rolls share only explicitly carried, uniquely identified physical offcuts.
  // Clone the seed list for every optimizer trial; a trial must never mutate another trial.
  const scraps: ScrapBit[] = initialScraps.map((scrap) => ({ ...scrap, material: scrap.material ? { ...scrap.material } : undefined }));
  const placements: Placement[] = new Array(pieces.length);
  let rawCm2 = 0;
  let pulls = 0;
  let freshLen = 0;
  let scrapSeq = 0;

  for (let sequencePosition = 0; sequencePosition < sequence.length; sequencePosition += 1) {
    const pi = sequence[sequencePosition];
    const piece = pieces[pi];
    const unit = units[piece.unit];
    if (reuse && !piece.full) {
      const futureNeeds: FutureNeed[] = lookAheadLimit > 0
        ? sequence.slice(sequencePosition + 1).map((futureIndex) => {
            const futurePiece = pieces[futureIndex];
            return { w: futurePiece.w, h: futurePiece.l, full: futurePiece.full, unit: units[futurePiece.unit] };
          })
        : [];
      const hit = tryConsumeScrap(scraps, piece.w, piece.l, unit.face, scrapMin, unit.material, unit.uid, unit.familyId, unit.familyCount, futureNeeds, lookAheadLimit);
      if (hit) {
        const createdScraps: GeneratedScrapDetail[] = [];
        for (const rem of hit.remainders) {
          const nextScrap: ScrapBit = {
            // A remainder keeps a child identity derived from the consumed offcut. This
            // prevents a new engine pass from accidentally reusing an ID from an earlier roll.
            id: `${hit.scrap.id}-rem-${++scrapSeq}`,
            w: rem.w,
            h: rem.h,
            face: hit.scrap.face,
            fromPane: hit.scrap.fromPane,
            fromUid: hit.scrap.fromUid,
            sourcePullNo: hit.scrap.sourcePullNo,
            createdByPane: unit.paneIndex,
            createdByUid: unit.uid,
            familyId: unit.familyId,
            familyCount: unit.familyCount,
            parentScrapId: hit.scrap.id,
            material: hit.scrap.material,
            rollId: hit.scrap.rollId,
            rollLabel: hit.scrap.rollLabel,
            createdByRollId: String(unit.material?.rollId ?? "") || hit.scrap.createdByRollId,
            fromPaneGlobal: hit.scrap.fromPaneGlobal,
            createdByPaneGlobal: false,
          };
          scraps.push(nextScrap);
          createdScraps.push(offcutDetail(nextScrap, scrapMin));
        }
        placements[pi] = {
          piece,
          source: "scrap",
          scrapId: hit.scrap.id,
          fromPane: hit.scrap.fromPane,
          fromPaneGlobal: hit.scrap.fromPaneGlobal,
          fromRollId: hit.scrap.rollId,
          fromRollLabel: hit.scrap.rollLabel,
          scrapCreatedByPane: hit.scrap.createdByPane,
          scrapCreatedByPaneGlobal: hit.scrap.createdByPaneGlobal,
          sourcePullNo: hit.scrap.sourcePullNo,
          usedW: hit.usedW,
          usedH: hit.usedH,
          rotated: hit.rotated,
          scrapMaterial: hit.scrap.material,
          createdScraps,
        };
        continue;
      }
    }
    rawCm2 += FM * piece.l;
    pulls += 1;
    const pullNo = pulls;
    freshLen += piece.l;
    const leftoverW = piece.full ? 0 : FM - piece.w;
    const createdScraps: GeneratedScrapDetail[] = [];
    if (leftoverW > 1e-6 && piece.l > 1e-6) {
      const newScrap: ScrapBit = {
        id: `scrap-${++scrapSeq}`,
        w: leftoverW,
        h: piece.l,
        face: unit.face,
        fromPane: unit.paneIndex,
        fromUid: unit.uid,
        sourcePullNo: pullNo,
        createdByPane: unit.paneIndex,
        createdByUid: unit.uid,
        familyId: unit.familyId,
        familyCount: unit.familyCount,
        material: unit.material,
        rollId: String(unit.material?.rollId ?? "") || undefined,
        createdByRollId: String(unit.material?.rollId ?? "") || undefined,
      };
      // Keep physical offcuts in the result whether reusable or below the
      // storage threshold; only usable ones participate in later matching.
      scraps.push(newScrap);
      createdScraps.push(offcutDetail(newScrap, scrapMin));
    }
    placements[pi] = { piece, source: "fresh", pullNo, leftoverW, createdScraps };
  }

  return { orients, rawCm2, seams, pulls, freshLen, placements, pieces, scraps, scrapSeq, sequence };
}

/**
 * Pack fresh cut lengths onto physical rolls using deterministic first-fit-decreasing.
 * `ceil(sum(lengths) / rollLen)` is only a lower bound and can understate rolls needed
 * (for example, three 1,800 cm pulls cannot fit on two 3,000 cm rolls).
 */
function packPullLengths(lengths: number[], rollLen: number): { rolls: number; unusedCm: number } {
  const capacity = Math.max(1, Number(rollLen) || 1);
  const bins: number[] = [];
  for (const length of lengths.filter((value) => Number.isFinite(value) && value > 0).sort((a, b) => b - a)) {
    if (length > capacity + 1e-9) throw new Error(`ความยาวตัด ${length} ซม. เกินความยาวม้วน ${capacity} ซม.`);
    let bestIndex = -1;
    let bestRemainder = Number.POSITIVE_INFINITY;
    for (let i = 0; i < bins.length; i += 1) {
      const remaining = capacity - bins[i];
      if (remaining + 1e-9 >= length && remaining - length < bestRemainder) {
        bestIndex = i;
        bestRemainder = remaining - length;
      }
    }
    if (bestIndex < 0) bins.push(length);
    else bins[bestIndex] += length;
  }
  const unusedCm = bins.reduce((sum, used) => sum + Math.max(0, capacity - used), 0);
  return { rolls: bins.length, unusedCm };
}

function rollPackFor(result: SimResult, rollLen: number) {
  return packPullLengths(result.placements.filter((placement) => placement?.source === "fresh").map((placement) => placement.piece.l), rollLen);
}

/** Whole-job objective: first minimize seam count, then fresh stock, roll count and offcut quality. */
function better(a: SimResult, b: SimResult, scrapMin: number, rollLen: number): boolean {
  // The SmartTec installation rule gives seam minimization priority over scrap savings.
  if (a.seams !== b.seams) return a.seams < b.seams;
  // Reusing scraps must never increase fresh material relative to another plan with the same seam count.
  const ar = Math.round(a.rawCm2 * 1000);
  const br = Math.round(b.rawCm2 * 1000);
  if (ar !== br) return ar < br;
  const aRolls = rollPackFor(a, rollLen);
  const bRolls = rollPackFor(b, rollLen);
  if (aRolls.rolls !== bRolls.rolls) return aRolls.rolls < bRolls.rolls;
  const scrapQuality = (result: SimResult) => {
    const reusable = result.scraps.filter((x) => usable(x.w, x.h, scrapMin));
    const waste = result.scraps.filter((x) => !usable(x.w, x.h, scrapMin));
    return {
      unusableArea: waste.reduce((sum, x) => sum + x.w * x.h, 0),
      reusableArea: reusable.reduce((sum, x) => sum + x.w * x.h, 0),
      reusableCount: reusable.length,
      physicalCount: result.scraps.length,
    };
  };
  const aq = scrapQuality(a);
  const bq = scrapQuality(b);
  if (Math.abs(aq.unusableArea - bq.unusableArea) > 1e-6) return aq.unusableArea < bq.unusableArea;
  if (a.pulls !== b.pulls) return a.pulls < b.pulls;
  if (Math.abs(aq.reusableArea - bq.reusableArea) > 1e-6) return aq.reusableArea > bq.reusableArea;
  if (aq.physicalCount !== bq.physicalCount) return aq.physicalCount < bq.physicalCount;
  return aq.reusableCount < bq.reusableCount;
}

function buildGlobalOrderSeeds(pieces: Piece[]): number[][] {
  const base = pieces.map((_, i) => i);
  const orders: Array<(a: Piece, b: Piece) => number> = [
    // Main strategies: large items first, then explicitly start with useful scrap donors.
    (a, b) => (b.w * b.l) - (a.w * a.l) || b.w - a.w || b.l - a.l,
    (a, b) => b.w - a.w || b.l - a.l || (b.w * b.l) - (a.w * a.l),
    (a, b) => Number(b.full) - Number(a.full) || (b.w * b.l) - (a.w * a.l) || b.w - a.w,
    (a, b) => Number(b.full) - Number(a.full) || a.w - b.w || (b.w * b.l) - (a.w * a.l),
    // Alternate starts let small pieces consume existing stock early and expose multi-step offcut chains.
    (a, b) => (a.w * a.l) - (b.w * b.l) || a.w - b.w || a.l - b.l,
    (a, b) => b.l - a.l || b.w - a.w || (b.w * b.l) - (a.w * a.l),
    (a, b) => Math.max(b.w, b.l) - Math.max(a.w, a.l) || Math.min(b.w, b.l) - Math.min(a.w, a.l),
    (a, b) => a.w - b.w || b.l - a.l || (a.w * a.l) - (b.w * b.l),
  ];
  const seen = new Set<string>();
  const seeds: number[][] = [];
  for (const compare of orders) {
    const order = base.slice().sort((i, j) => compare(pieces[i], pieces[j]) || i - j);
    const key = order.join(",");
    if (!seen.has(key)) {
      seen.add(key);
      seeds.push(order);
    }
  }
  return seeds;
}

function optimizeJob(
  units: UnitPlan[],
  paneOfUnit: number[],
  FM: number,
  rollLen: number,
  scrapMin: number,
  spliceAllowanceCm = 0,
  effort: "quick" | "full" = "full",
  initialScraps: ScrapBit[] = [],
): { best: SimResult; order: PieceOrder; tried: number } {
  const choices = units.map((u) => choicesFor(u, FM, rollLen));
  // Every strip from every pane (including seam strips) participates in one work-wide search.
  const paneIds = [...new Set(paneOfUnit)];
  const paneChoices = new Map<number, Orient[]>();
  for (const id of paneIds) {
    const first = paneOfUnit.indexOf(id);
    paneChoices.set(id, choices[first]);
  }
  const toOrients = (assign: Map<number, Orient>) => paneOfUnit.map((id) => assign.get(id) as Orient);

  let tried = 0;
  const orientationBudget = units.length > 250 ? 220 : units.length > 100 ? 480 : 760;
  const starts: Array<{ label: string; assign: Map<number, Orient> }> = [];
  const legacy = new Map<number, Orient>();
  const allV = new Map<number, Orient>();
  const allH = new Map<number, Orient>();
  const alternating = new Map<number, Orient>();
  for (const id of paneIds) {
    const first = paneOfUnit.indexOf(id);
    const opts = paneChoices.get(id) as Orient[];
    const legacyChoice = legacyOrient(units[first], FM, rollLen, spliceAllowanceCm);
    legacy.set(id, legacyChoice);
    allV.set(id, opts.includes("V") ? "V" : opts[0]);
    allH.set(id, opts.includes("H") ? "H" : opts[0]);
    // A deterministic mixed orientation seed helps discover cross-pane opportunities missed by all-V/all-H.
    alternating.set(id, opts.includes((first % 2 === 0 ? "V" : "H") as Orient)
      ? (first % 2 === 0 ? "V" : "H") as Orient
      : opts[0]);
  }
  starts.push(
    { label: "legacy", assign: legacy },
    { label: "all-v", assign: allV },
    { label: "all-h", assign: allH },
    { label: "alternating", assign: alternating },
  );

  // Multi-roll assignment scores many candidate placements. Use a deliberately small,
  // no-look-ahead screening pass there; every committed physical-roll group is recalculated
  // in full mode after assignment. This keeps whole-job search responsive at 500 pane units.
  if (effort === "quick") {
    let quickBest: SimResult | null = null;
    let quickOrder: PieceOrder = "area";
    let quickTried = 0;
    const quickStarts = [starts[0], starts[1], starts[2]];
    const quickOrders: PieceOrder[] = ["area", "donor"];
    for (const order of quickOrders) {
      for (const start of quickStarts) {
        const trial = simulate(units, toOrients(start.assign), FM, scrapMin, order, true, undefined, spliceAllowanceCm, 0, initialScraps);
        quickTried += 1;
        if (!quickBest || better(trial, quickBest, scrapMin, rollLen)) {
          quickBest = trial;
          quickOrder = order;
        }
      }
    }
    const noReuse = simulate(units, units.map((u) => legacyOrient(u, FM, rollLen, spliceAllowanceCm)), FM, scrapMin, "area", false, undefined, spliceAllowanceCm, 0, initialScraps);
    quickTried += 1;
    if (!quickBest || better(noReuse, quickBest, scrapMin, rollLen)) {
      quickBest = noReuse;
      quickOrder = "area";
    }
    return { best: quickBest as SimResult, order: quickOrder, tried: quickTried };
  }

  const seeds: Array<{ result: SimResult; order: PieceOrder; label: string }> = [];
  const pieceOrders: PieceOrder[] = ["area", "width", "donor", "thin"];
  let best: SimResult | null = null;
  let bestOrder: PieceOrder = "area";

  // Evaluate the complete set of coarse whole-job starts first. Never select a cut just because
  // it makes the current pane's remainder look small; only the resulting whole-job score matters.
  for (const order of pieceOrders) {
    let orderBest: SimResult | null = null;
    let startLabel = "";
    for (const start of starts) {
      const trial = simulate(units, toOrients(start.assign), FM, scrapMin, order, true, undefined, spliceAllowanceCm, 12, initialScraps);
      tried += 1;
      seeds.push({ result: trial, order, label: `${order}:${start.label}` });
      if (!orderBest || better(trial, orderBest, scrapMin, rollLen)) {
        orderBest = trial;
        startLabel = start.label;
      }
      if (!best || better(trial, best, scrapMin, rollLen)) {
        best = trial;
        bestOrder = order;
      }
    }

    // Improve orientation assignment using job-level outcomes; the current sequence strategy is
    // retained so a local orientation decision is assessed against the full set of panes and scraps.
    if (orderBest && tried < orientationBudget) {
      const assign = new Map<number, Orient>();
      paneIds.forEach((id) => assign.set(id, orderBest!.orients[paneOfUnit.indexOf(id)]));
      let cur = orderBest;
      for (let pass = 0; pass < 2 && tried < orientationBudget; pass++) {
        let improved = false;
        for (const id of paneIds) {
          if (tried >= orientationBudget) break;
          const opts = paneChoices.get(id) as Orient[];
          if (opts.length < 2) continue;
          const now = assign.get(id) as Orient;
          const alt: Orient = now === "V" ? "H" : "V";
          if (!opts.includes(alt)) continue;
          assign.set(id, alt);
          const trial = simulate(units, toOrients(assign), FM, scrapMin, order, true, undefined, spliceAllowanceCm, 12, initialScraps);
          tried += 1;
          if (better(trial, cur, scrapMin, rollLen)) {
            cur = trial;
            improved = true;
          } else {
            assign.set(id, now);
          }
        }
        if (!improved) break;
      }
      seeds.push({ result: cur, order, label: `${order}:orientation-refined:${startLabel}` });
      if (!best || better(cur, best, scrapMin, rollLen)) {
        best = cur;
        bestOrder = order;
      }
    }
  }

  // Seed a work-wide sequence search from several distinct whole-job plans. Search includes all
  // generated seam strips and remainders produced by consuming another scrap; a cut can therefore
  // create a useful piece for any later pane, not only the pane it came from.
  const ranked = seeds.slice().sort((a, b) => {
    if (better(a.result, b.result, scrapMin, rollLen)) return -1;
    if (better(b.result, a.result, scrapMin, rollLen)) return 1;
    return a.label.localeCompare(b.label);
  });
  const startsForSequence: typeof ranked = [];
  const seenPlans = new Set<string>();
  for (const candidate of ranked) {
    const orientKey = candidate.result.orients.join("");
    const shapeKey = candidate.result.pieces.map((piece) => `${piece.w.toFixed(3)}x${piece.l.toFixed(3)}:${piece.full ? 1 : 0}`).sort().join("|");
    const key = `${orientKey}#${shapeKey}#${candidate.label.split(":")[0]}`;
    if (seenPlans.has(key)) continue;
    seenPlans.add(key);
    startsForSequence.push(candidate);
    if (startsForSequence.length >= 4) break;
  }

  let rng = 2463534242;
  const rand = () => {
    rng ^= rng << 13; rng >>>= 0;
    rng ^= rng >>> 17;
    rng ^= rng << 5; rng >>>= 0;
    return rng / 4294967296;
  };
  for (const start of startsForSequence) {
    const seedOrders = buildGlobalOrderSeeds(start.result.pieces);
    // Try every distinct seed order for each of the strongest orientation candidates.
    for (const seedOrder of seedOrders) {
      if (tried >= orientationBudget + 80) break;
      const trial = simulate(units, start.result.orients, FM, scrapMin, start.order, true, seedOrder, spliceAllowanceCm, 12, initialScraps);
      tried += 1;
      if (!best || better(trial, best, scrapMin, rollLen)) {
        best = trial;
        bestOrder = start.order;
      }
      seeds.push({ result: trial, order: start.order, label: `global-seed:${start.label}` });
    }
  }

  const bestSequenceStarts = seeds.slice().sort((a, b) => {
    if (better(a.result, b.result, scrapMin, rollLen)) return -1;
    if (better(b.result, a.result, scrapMin, rollLen)) return 1;
    return a.label.localeCompare(b.label);
  }).filter((candidate, index, all) => {
    const key = `${candidate.result.orients.join("")}:${candidate.result.sequence.join(",")}`;
    return all.findIndex((x) => `${x.result.orients.join("")}:${x.result.sequence.join(",")}` === key) === index;
  }).slice(0, 3);

  // Bounded deterministic neighborhood search (swap, move, and reverse). Multi-start improves
  // coverage while preserving predictable response times for the supported 100-pane job size.
  const pieceCount = best?.pieces.length ?? units.length;
  const iterationsPerStart = pieceCount > 180 ? 12 : pieceCount > 100 ? 18 : pieceCount > 80 ? 24 : pieceCount > 50 ? 42 : pieceCount > 25 ? 90 : 160;
  for (const start of bestSequenceStarts) {
    let current = start.result;
    let currentSeq = current.sequence.slice();
    const n = currentSeq.length;
    if (n < 2) continue;
    for (let k = 0; k < iterationsPerStart; k += 1) {
      const seq = currentSeq.slice();
      const i = Math.floor(rand() * n);
      const j = Math.floor(rand() * n);
      if (i === j) continue;
      const moveType = rand();
      if (moveType < 0.42) {
        [seq[i], seq[j]] = [seq[j], seq[i]];
      } else if (moveType < 0.84) {
        const [piece] = seq.splice(i, 1);
        seq.splice(j, 0, piece);
      } else {
        const lo = Math.min(i, j);
        const hi = Math.max(i, j);
        const reversed = seq.slice(lo, hi + 1).reverse();
        seq.splice(lo, reversed.length, ...reversed);
      }
      const trial = simulate(units, current.orients, FM, scrapMin, start.order, true, seq, spliceAllowanceCm, 12, initialScraps);
      tried += 1;
      if (better(trial, current, scrapMin, rollLen)) {
        current = trial;
        currentSeq = trial.sequence.slice();
      }
      if (!best || better(trial, best, scrapMin, rollLen)) {
        best = trial;
        bestOrder = start.order;
      }
    }
  }

  // Final guard: reuse-aware planning must never use more fresh stock than cutting every strip anew.
  const baseline = simulate(units, units.map((u) => legacyOrient(u, FM, rollLen, spliceAllowanceCm)), FM, scrapMin, "area", false, undefined, spliceAllowanceCm, 12, initialScraps);
  tried += 1;
  if (!best || better(baseline, best, scrapMin, rollLen)) {
    best = baseline;
    bestOrder = "area";
  }
  return { best: best as SimResult, order: bestOrder, tried };
}

/** ปัดพื้นที่ระดับงานครั้งเดียว แล้วกระจายกลับลงแต่ละบานด้วยวิธีเศษมากสุดก่อน (ผลรวมแถวตรงกับยอดรวมเสมอ) */
function allocateRounded(raw: number[], total: number): number[] {
  const base = raw.map((v) => Math.floor(v + 1e-9));
  let remaining = total - base.reduce((s, v) => s + v, 0);
  const order = raw
    .map((v, i) => ({ i, frac: v - Math.floor(v + 1e-9) }))
    .sort((a, b) => b.frac - a.frac || a.i - b.i);
  for (let k = 0; remaining > 0 && order.length; k = (k + 1) % order.length) {
    base[order[k].i] += 1;
    remaining -= 1;
  }
  return base;
}

function emptyResult(cfg: EngineConfig, FM: number, m: number, div: number): JobCalcResult {
  return {
    version: cfg.version || SYSTEM_VERSION,
    config: {
      filmMax: FM,
      margin: m,
      edgeGapMm: cfg.edgeGapMm ?? 0,
      divisor: div,
      rollLen: cfg.rollLen,
      scrapMin: cfg.scrapMin,
      jobProfile: cfg.jobProfile || "general",
      version: cfg.version,
    },
    panes: [],
    summary: {
      install_sqft: 0,
      fresh_sqft: 0,
      naive_install_sqft: 0,
      saved_sqft: 0,
      face_sqft: 0,
      pulls: 0,
      seams: 0,
      paired: 0,
      scrap_used_pieces: 0,
      scrap_used_cm2: 0,
      final_scrap_pieces: 0,
      final_scrap_cm2: 0,
      final_scrap_sqft: 0,
      reusable_scrap_pieces: 0,
      reusable_scrap_cm2: 0,
      waste_scrap_pieces: 0,
      waste_scrap_cm2: 0,
      waste_scrap_sqft: 0,
      waste_cm2: 0,
      pieces: 0,
      fresh_raw_sqft: 0,
      glass_raw_sqft: 0,
      optimizer_trials: 0,
      optimization_is_exact: false,
      optimization_method: "deterministic-multi-start-global-search",
      plan: "per-pane",
      plan_order: "simple",
      note_th: "ไม่มีบานที่คำนวณได้",
      fresh_pull_cm: 0,
      required_rolls: 0,
      roll_end_waste_cm: 0,
      orientation_status: "pass",
      orientation_warnings: [],
    },
    events: [],
    finalScraps: [],
    glassAreaCm2: 0,
    glassAreaSqft: 0,
    installAreaSqft: 0,
  };
}

/**
 * calculateJob — จุดคำนวณกลางสำหรับหน้าจอ / แชท / เซิร์ฟเวอร์
 * มองทั้งงานพร้อมกัน: ทุกแผ่นฟิล์มจากทุกบานลงกองเดียว เศษใช้ข้ามบานได้ทั้งงาน
 * แนวตัดของแต่ละบานเลือกจากผลรวมทั้งงาน (ไม่ขึ้นกับลำดับที่ผู้ใช้กรอกบาน)
 * พื้นที่ติดตั้งปัดขึ้นครั้งเดียวที่ระดับงาน
 */

/** ยืนยันว่าแผนต่อของหนึ่งบานไม่ใช่จิ๊กซอว์ (เรียกจากแผนตัดและใบสั่งช่าง) */
export function assertNoJigsawSeamLayout(orient: "V" | "H" | null | undefined, stripCount: number): void {
  if (!SPLICE_LAYOUT_POLICY.forbidJigsawSplice) return;
  const axis = seamAxisFromOrient(orient ?? null, stripCount);
  const check = validatePaneSeamLayout({ seamAxis: axis, stripCount, hasPerpendicularSeams: false, isJigsawOrGrid: false });
  if (!check.ok) {
    throw new Error(check.reasons[0] || "ห้ามต่อฟิล์มแบบจิ๊กซอว์");
  }
}

export function calculateJob(
  panes: PaneInput[],
  configOverride?: Partial<EngineConfig>,
  initialScrapInputs: EngineScrapInput[] = [],
): JobCalcResult {
  // Per-call overrides go through the same clamp/validation as setConfig(): an unclamped
  // filmMax of 0/NaN/negative would make splitUnit() loop forever (ceil(across / 0) = Infinity).
  const cfg = normalizeEngineConfig(configOverride ?? {}, _cfg);
  const FM = cfg.filmMax;
  const m = cfg.margin;
  const div = cfg.divisor;
  const scrapMin = cfg.scrapMin ?? 0;
  MIN_STRIP_CTX.v = Math.max(0, Number(cfg.minStrip ?? 0) || 0);
  const initialScraps: ScrapBit[] = (Array.isArray(initialScrapInputs) ? initialScrapInputs : []).map((scrap, index) => {
    const width = Number(scrap.width_cm);
    const height = Number(scrap.height_cm);
      if (!scrap.id || !scrap.roll_id || !scrap.from_uid || !Number.isInteger(Number(scrap.from_pane)) || Number(scrap.from_pane) < 1 || !Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0) {
      const error = new Error(`เศษฟิล์มที่เชื่อมม้วนรายการ ${index + 1} มีข้อมูลไม่ถูกต้อง`) as Error & { code?: string };
      error.code = "VALIDATION_FAILED";
      throw error;
    }
    return {
      id: String(scrap.id), w: width, h: height,
      face: scrap.face === "A" || scrap.face === "B" ? scrap.face : "unknown",
      fromPane: Number(scrap.from_pane), fromUid: String(scrap.from_uid ?? ""),
      createdByPane: Number(scrap.created_by_pane ?? scrap.from_pane),
      createdByUid: String(scrap.created_by_uid ?? scrap.from_uid ?? ""),
      familyId: scrap.family_id, familyCount: Number(scrap.family_count ?? 1),
      sourcePullNo: Number(scrap.source_pull_no ?? 0) || undefined,
      parentScrapId: scrap.parent_scrap_id,
      material: scrap.material ? { ...scrap.material } : undefined,
      rollId: String(scrap.roll_id), rollLabel: scrap.roll_label,
      createdByRollId: scrap.created_by_roll_id,
      fromPaneGlobal: scrap.from_pane_global === true,
      createdByPaneGlobal: scrap.created_by_pane_global === true,
    };
  });
  const seedIds = new Set<string>();
  for (const scrap of initialScraps) {
    if (seedIds.has(scrap.id)) {
      const error = new Error(`รหัสเศษฟิล์ม ${scrap.id} ซ้ำกันในกลุ่มม้วนที่เชื่อม`) as Error & { code?: string };
      error.code = "VALIDATION_FAILED";
      throw error;
    }
    seedIds.add(scrap.id);
  }

  const paneMeta: Array<{
    index: number;
    W: number;
    H: number;
    qty: number;
    E: number;
    F: number;
    actualW: number;
    actualH: number;
    dir: Orient | null;
    face: FilmFace;
    material?: Partial<MaterialOrientationSpec>;
  }> = [];
  const units: UnitPlan[] = [];
  const paneOfUnit: number[] = [];

  // Group physical panes by the full, normalized geometry/material contract. Separate
  // input rows with identical specifications belong to the same family unless explicitly
  // separated by a caller-provided familyId. A row's qty expands to physical units.
  const familyKeys: string[] = [];
  const familyCounts = new Map<string, number>();
  for (let i = 0; i < (panes || []).length; i++) {
    const p = panes[i] || {};
    const rawW = Number(p.raw_width_cm ?? p.width_cm ?? p.w ?? p.width ?? 0);
    const rawH = Number(p.raw_height_cm ?? p.height_cm ?? p.h ?? p.height ?? 0);
    const qty = Number(p.qty ?? 1);
    if (!(rawW > 0 && rawH > 0) || !Number.isFinite(rawW) || !Number.isFinite(rawH) || !Number.isInteger(qty) || qty < 1) {
      familyKeys[i] = `invalid:${i}`;
      continue;
    }
    const material = { ...(cfg.materialOrientation ?? {}), ...(p.material ?? {}) };
    const identity = {
      explicit: String(p.familyId ?? '').trim() || undefined,
      width: ceilDimensionCm(rawW),
      height: ceilDimensionCm(rawH),
      sku: String(material.sku ?? '').trim(),
      lot: String(material.lotId ?? '').trim(),
      face: asFace(p.face),
      paneFace: material.face ?? 'unknown',
      policy: material.policy ?? 'unknown',
      direction: String(material.directionKey ?? '').trim(),
      rotations: Array.isArray(material.allowedRotations) ? [...material.allowedRotations].sort((a, b) => a - b) : [],
      dir: p.dir === 'V' || p.dir === 'H' ? p.dir : 'auto',
    };
    const key = JSON.stringify(identity);
    familyKeys[i] = key;
    familyCounts.set(key, (familyCounts.get(key) ?? 0) + qty);
  }

  for (let i = 0; i < (panes || []).length; i++) {
    const p = panes[i] || {};
    const rawW = Number(p.raw_width_cm ?? p.width_cm ?? p.w ?? p.width ?? 0);
    const rawH = Number(p.raw_height_cm ?? p.height_cm ?? p.h ?? p.height ?? 0);
    const W = ceilDimensionCm(rawW);
    const H = ceilDimensionCm(rawH);
    const qty = Number(p.qty ?? 1);
    // The canonical service validates all inputs. Keep the pure engine defensive for direct/test calls.
    if (!(rawW > 0 && rawH > 0) || !Number.isFinite(rawW) || !Number.isFinite(rawH) || !Number.isInteger(qty) || qty < 1 || qty > 500) continue;

    const E = colE(W, m);
    const F = colF(H, m);
    const paneDir = p.dir === "V" || p.dir === "H" ? p.dir : null;
    const face = asFace(p.face);
    // Job-level material policy (config.materialOrientation) applies unless the pane carries its own.
    const material = { ...(cfg.materialOrientation ?? {}), ...(p.material ?? {}) };
    paneMeta.push({ index: i + 1, W, H, qty, E, F, actualW: rawW, actualH: rawH, dir: paneDir, face, material });
    const paneIdx = paneMeta.length - 1;

    for (let q = 0; q < qty; q++) {
      units.push({
        uid: `${i}:${q}`,
        familyId: familyKeys[i],
        familyCount: Math.max(qty, Number(p.familyCount ?? familyCounts.get(familyKeys[i]) ?? qty)),
        paneIdx,
        paneIndex: i + 1,
        qtyIndex: q,
        E,
        F,
        W,
        H,
        forceDir: paneDir,
        face,
        material,
      });
      paneOfUnit.push(paneIdx);
    }
  }

  if (!units.length) return emptyResult(cfg, FM, m, div);
  // ห้ามต่อจิ๊กซอว์: ยืนยันว่าทุกบานใช้ได้เฉพาะแนวแถบเดียว (V หรือ H)
  for (const unit of units) {
    const opts = choicesFor(unit, FM, cfg.rollLen);
    for (const orient of opts) {
      const parts = splitUnit(unit, orient, FM, MIN_STRIP_CTX.v, cfg.spliceAllowanceCm);
      assertNoJigsawSeamLayout(orient, parts.length);
    }
  }
  for (const unit of units) {
    if (!choicesFor(unit, FM, cfg.rollLen).length) {
      const error = new Error(`บาน ${unit.paneIndex}: ไม่มีแนวตัดที่ใช้ได้กับหน้ากว้างและความยาวม้วนที่ตั้งไว้ หรือขัดกับข้อกำหนดทิศทางฟิล์ม`) as Error & { code?: string };
      error.code = "VALIDATION_FAILED";
      throw error;
    }
  }

  // ฐานเทียบ "ไม่ใช้เศษเลย" (แต่ละบานดึงฟิล์มของตัวเอง) เพื่อวัดว่าประหยัดได้เท่าไร
  const naiveOrients = units.map((u) => legacyOrient(u, FM, cfg.rollLen, cfg.spliceAllowanceCm));
  const naive = simulate(units, naiveOrients, FM, scrapMin, "area", false, undefined, cfg.spliceAllowanceCm);
  const naiveInstall = calcAreaRounded(naive.rawCm2 / div, 1);

  const { best: plan, order, tried } = optimizeJob(units, paneOfUnit, FM, cfg.rollLen, scrapMin, cfg.spliceAllowanceCm, cfg.optimizerEffort ?? "full", initialScraps);
  const freshRawSqft = plan.rawCm2 / div;
  const totalInstall = calcAreaRounded(freshRawSqft, 1);

  // ─ เศษที่ใช้ → บานที่เป็นเจ้าของ material (สำหรับตรวจการต่อ/ทิศทาง) ─
  const orientationWarnings = new Set<string>();
  let orientationStatus: SpliceCheckStatus = "pass";
  const noteCheck = (status: SpliceCheckStatus, reasons: string[], paneIndex: number) => {
    if (status === "block") orientationStatus = "block";
    else if (status === "review" && orientationStatus !== "block") orientationStatus = "review";
    for (const reason of reasons) orientationWarnings.add(`บาน ${paneIndex}: ${reason}`);
  };

  // Missing optional selectors must never prevent the geometry planner from producing
  // a useful draft. Make every missing choice visible as REVIEW while keeping the plan
  // usable for estimation and material optimization. REVIEW is not production approval.
  for (const unit of units) {
    const material = unit.material;
    if (!String(material?.sku ?? "").trim()) {
      noteCheck("review", ["ยังไม่ได้เลือกสินค้า/SKU — ระบบวางแผนจากขนาดบานและม้วนที่มีให้อัตโนมัติแล้ว"], unit.paneIndex);
    }
    if (!material?.policy || material.policy === "unknown") {
      noteCheck("review", ["ยังไม่ได้ยืนยันทิศทางฟิล์มจากข้อมูลผู้ผลิต — ระบบเลือกแนวตัดที่จัดวางได้ตามขนาดและแจ้งเตือนไว้แล้ว"], unit.paneIndex);
    }
    if (!material?.face || material.face === "unknown") {
      noteCheck("review", ["ยังไม่ได้ระบุด้านฟิล์ม — ระบบจัดแผนเบื้องต้นตามข้อมูลที่มีและแจ้งเตือนไว้แล้ว"], unit.paneIndex);
    }
    if (material?.specVerified !== true || !String(material?.specSource ?? "").trim()) {
      noteCheck("review", ["ยังไม่มีคู่มือผู้ผลิตที่บันทึกและตรวจยืนยัน — แผนนี้เป็นแผนเบื้องต้นก่อนตัดจริง"], unit.paneIndex);
    }
  }

  for (const [ui, orientation] of plan.orients.entries()) {
    const unit = units[ui];
    if (orientation === "H") {
      const material = unit.material;
      const restrictions = [
        material?.policy === "directional" ? "ข้อมูลสินค้าระบุว่าฟิล์มมีทิศทาง" : "",
        Array.isArray(material?.allowedRotations) && material.allowedRotations.length && !material.allowedRotations.includes(90) && !material.allowedRotations.includes(270)
          ? "ข้อมูล SKU ยังไม่ระบุว่าอนุญาตหมุน 90°/270°" : "",
        material?.specVerified !== true || !String(material?.specSource ?? "").trim()
          ? "ยังไม่มีเอกสารผู้ผลิตที่ตรวจยืนยันในระบบ" : "",
      ].filter(Boolean);
      noteCheck("review", [
        `ระบบเลือกหมุนฟิล์ม 90° จากผลวางแผนภาพรวมทั้งงาน${restrictions.length ? ` (${restrictions.join("; ")})` : ""} — โปรดตรวจแนวลาย/ทิศทางและเอกสาร SKU ก่อนตัดจริง`,
      ], unit.paneIndex);
    }
  }

  // ─ จัดกลุ่มการวางแผ่นตามหน่วย (unit) ─
  const byUnit: Placement[][] = units.map(() => []);
  for (const pl of plan.placements) byUnit[pl.piece.unit].push(pl);
  for (const list of byUnit) list.sort((a, b) => a.piece.seq - b.piece.seq);

  // สร้างรายละเอียดชิ้นฟิล์มจากแผนเดียวกับที่ใช้คำนวณจริง เพื่อให้ใบสั่งงานช่าง
  // แสดงขนาด/แหล่งที่มา/ทิศทางตรงกับผลลัพธ์ที่บันทึกไว้ โดยไม่คำนวณซ้ำใน UI
  const globalSequence = new Map<number, number>();
  plan.sequence.forEach((pieceIndex, position) => globalSequence.set(pieceIndex, position + 1));
  const cutDetailsByUnit: CutPieceDetail[][] = units.map((unit) => []);
  for (const [ui, list] of byUnit.entries()) {
    for (const pl of list) {
      const unit = units[ui];
      const pieceIndex = plan.pieces.findIndex((piece) => piece === pl.piece);
      const sequence = globalSequence.get(pieceIndex) ?? pieceIndex + 1;
      cutDetailsByUnit[ui].push({
        piece_id: `B${String(unit.paneIndex).padStart(2, "0")}-Q${String(unit.qtyIndex + 1).padStart(2, "0")}-P${String(pl.piece.seq + 1).padStart(2, "02")}`,
        sequence,
        source: pl.source,
        cut_width_cm: Number(pl.source === "scrap" ? pl.usedW ?? pl.piece.w : pl.piece.w),
        cut_length_cm: Number(pl.source === "scrap" ? pl.usedH ?? pl.piece.l : pl.piece.l),
        orientation: plan.orients[ui],
        rotated: Boolean(pl.rotated),
        pull_no: pl.pullNo,
        scrap_id: pl.scrapId,
        from_pane: pl.fromPane,
        from_pane_global: pl.fromPaneGlobal === true,
        from_roll_id: pl.fromRollId,
        from_roll_label: pl.fromRollLabel,
        scrap_created_by_pane: pl.scrapCreatedByPane,
        scrap_created_by_pane_global: pl.scrapCreatedByPaneGlobal === true,
        source_pull_no: pl.sourcePullNo,
        created_scraps: pl.createdScraps,
      });
    }
    cutDetailsByUnit[ui].sort((a, b) => a.sequence - b.sequence);
  }

  const events: CalcEvent[] = [];
  const pairedUnits = new Set<number>();
  let scrapUsedCm2 = 0;
  let pairedPieces = 0;
  const rowRaw: number[] = paneMeta.map(() => 0);

  const paneRows = paneMeta.map((pm, paneIdx) => {
    const rollDetails: RollDetail[] = [];
    const scrapSources: ScrapSource[] = [];
    let rowPulls = 0;
    let rowPieces = 0;
    let rowSeams = 0;
    let pairedCount = 0;
    const cutPieces: CutPieceDetail[] = [];

    units.forEach((unit, ui) => {
      if (unit.paneIdx !== paneIdx) return;
      const list = byUnit[ui];
      const orient = plan.orients[ui];
      cutPieces.push(...cutDetailsByUnit[ui]);
      rowPieces += list.length;
      rowSeams += Math.max(0, list.length - 1);
      const fresh = list.filter((x) => x.source === "fresh");
      const fromScrap = list.filter((x) => x.source === "scrap");

      for (const pl of fromScrap) {
        const reuseCheck = checkScrapReuseCompatibility(pl.scrapMaterial, unit.material);
        noteCheck(reuseCheck.status, reuseCheck.reasons, unit.paneIndex);
        if (pl.rotated) {
          noteCheck("review", [
            `ระบบหมุนเศษฟิล์ม${pl.scrapId ? ` ${pl.scrapId}` : ""} 90° เพื่อใช้กับบานนี้${pl.fromPane ? ` (เศษจากบาน ${pl.fromPane})` : ""} — โปรดตรวจแนวลาย/ทิศทาง ด้านฟิล์ม และ SKU ก่อนตัดจริง`,
          ], unit.paneIndex);
        }
        pairedCount += 1;
        pairedPieces += 1;
        pairedUnits.add(ui);
        scrapUsedCm2 += (pl.usedW ?? 0) * (pl.usedH ?? 0);
        scrapSources.push({
          scrap_id: pl.scrapId || "",
          from_pane: pl.fromPane || 0,
          from_pane_global: pl.fromPaneGlobal === true,
          from_roll_id: pl.fromRollId,
          from_roll_label: pl.fromRollLabel,
          w: pl.usedW ?? 0,
          h: pl.usedH ?? 0,
          face: pl.scrapMaterial?.face === "A" || pl.scrapMaterial?.face === "B" ? pl.scrapMaterial.face : unit.face,
        });
        events.push({
          type: "paired",
          pane: unit.paneIndex,
          from_pane: pl.fromPane,
          from_pane_global: pl.fromPaneGlobal === true,
          from_roll_id: pl.fromRollId,
          scrap_id: pl.scrapId,
          w: pl.usedW,
          h: pl.usedH,
        });
      }

      if (fresh.length) {
        const last = fresh[fresh.length - 1];
        const length = fresh.reduce((s, x) => s + x.piece.l, 0);
        rowRaw[paneIdx] += (FM * length) / div;
        rowPulls += fresh.length;
        const leftover = Math.max(...fresh.map((x) => x.leftoverW ?? 0));
        rollDetails.push({
          pulls: fresh.length,
          dir: list.length > 1 ? orient : orient,
          I: FM,
          J: last.piece.l,
          K: leftover,
        });
        events.push({
          type: "fresh",
          pane: unit.paneIndex,
          dir: list.length > 1 ? orient : "none",
          M: fresh.length,
          K: leftover,
          J: last.piece.l,
        });
      }

      // การต่อแผ่น: ตรวจความเข้ากันได้ของฟิล์ม (เศษจากบานอื่นต้องตรวจม้วน/ทิศทางด้วย)
      if (list.length > 1) {
        const mine = pm.material;
        const check = checkSpliceCompatibility(mine, mine);
        noteCheck(check.status, check.reasons, unit.paneIndex);
        for (const pl of fromScrap) {
          const donorCheck = checkSpliceCompatibility(pl.scrapMaterial, mine);
          noteCheck(donorCheck.status, donorCheck.reasons, unit.paneIndex);
          if (pl.fromPane && pl.fromPane !== unit.paneIndex) {
            noteCheck(
              donorCheck.status === "block" ? "block" : "review",
              donorCheck.status === "block"
                ? donorCheck.reasons
                : [`แผ่นต่อใช้เศษจากบาน ${pl.fromPane} — ตรวจม้วน Lot ด้านฟิล์ม และทิศทางให้ตรงกันก่อนติดตั้ง`],
              unit.paneIndex,
            );
          }
        }
      }
    });

    cutPieces.sort((a, b) => a.sequence - b.sequence);
    return { pm, rollDetails, scrapSources, rowPulls, rowPieces, rowSeams, pairedCount, cutPieces };
  });

  const allocated = allocateRounded(rowRaw, totalInstall);

  // Physical glass area uses the measured dimensions, not ceil-rounded cut dimensions.
  // Cut allowances remain separate and are applied only to E/F above.
  const rawGlassSqftByPane = paneMeta.map((pm) => (pm.actualW * pm.actualH * pm.qty) / div);
  const totalGlassCm2 = paneMeta.reduce((sum, pm) => sum + pm.actualW * pm.actualH * pm.qty, 0);
  const exactGlassTotalSqft = totalGlassCm2 / div;

  const paneResults: PaneCalcRow[] = paneRows.map((row, idx) => {
    const { pm, rollDetails, scrapSources, rowPulls, rowPieces, rowSeams, pairedCount, cutPieces } = row;
    const faceSq = rawGlassSqftByPane[idx] ?? 0;
    return {
      index: pm.index,
      width_cm: pm.W,
      height_cm: pm.H,
      actual_width_cm: pm.actualW,
      actual_height_cm: pm.actualH,
      qty: pm.qty,
      afterW: pm.E,
      afterH: pm.F,
      dir: pm.dir || rollDetails[0]?.dir || "V",
      install_sqft: allocated[idx],
      face_sqft: faceSq,
      paired: pairedCount > 0,
      donor: scrapSources[0]?.from_pane ?? null,
      rollPulls: rowPulls,
      rollCount: rollDetails.length + pairedCount,
      scrapCount: scrapSources.length,
      rollDetails,
      scrapSources,
      face: pm.face,
      pieces: rowPieces,
      seams: rowSeams,
      cutPieces,
    };
  });

  // Glass area is measured area, kept exact internally; only display formatting rounds it.
  const totalFace = exactGlassTotalSqft;
  const isReusableScrap = (scrap: ScrapBit) => usable(scrap.w, scrap.h, scrapMin);
  const finalScrapCm2 = plan.scraps.reduce((s, x) => s + x.w * x.h, 0);
  const reusableScraps = plan.scraps.filter(isReusableScrap);
  const wasteScraps = plan.scraps.filter((scrap) => !isReusableScrap(scrap));
  const reusableScrapCm2 = reusableScraps.reduce((s, x) => s + x.w * x.h, 0);
  const wasteScrapCm2 = wasteScraps.reduce((s, x) => s + x.w * x.h, 0);
  const rollPack = rollPackFor(plan, cfg.rollLen);
  const requiredRolls = rollPack.rolls;
  const saved = Math.max(0, naiveInstall - totalInstall);
  const usedGlobal = pairedPieces > 0;

  const finalScraps: FinalScrap[] = plan.scraps
    .map((s) => ({
      id: s.id,
      w: s.w,
      h: s.h,
      width_cm: s.w,
      height_cm: s.h,
      face: s.face,
      pane_id: String(s.fromPane),
      from: String(s.fromPane),
      uid: s.fromUid,
      family_id: s.familyId,
      family_count: s.familyCount,
      material: s.material,
      reusable: isReusableScrap(s),
      source_pull_no: s.sourcePullNo,
      origin_pane_index: s.fromPane,
      created_by_pane_index: s.createdByPane,
      created_by_uid: s.createdByUid,
      created_by_roll_id: s.createdByRollId,
      parent_scrap_id: s.parentScrapId,
      area_cm2: s.w * s.h,
      status_note_th: isReusableScrap(s)
        ? "ผ่านเกณฑ์ขนาดเก็บเศษได้ แต่ไม่มีบานที่พอดีในงานนี้"
        : `ต่ำกว่าเกณฑ์เก็บเศษ ${scrapMin} ซม. จัดเป็นเศษทิ้ง`,
      roll_id: (s.rollId ?? String(s.material?.rollId ?? "")) || undefined,
      roll_label: s.rollLabel,
      origin_pane_global: s.fromPaneGlobal,
      created_by_pane_global: s.createdByPaneGlobal,
    }))
    .sort((a, b) => a.origin_pane_index - b.origin_pane_index || a.id.localeCompare(b.id, "en", { numeric: true }));

  return {
    version: cfg.version || SYSTEM_VERSION,
    config: {
      filmMax: FM,
      margin: m,
      edgeGapMm: cfg.edgeGapMm ?? 0,
      divisor: div,
      rollLen: cfg.rollLen,
      scrapMin: cfg.scrapMin,
      jobProfile: cfg.jobProfile || "general",
      version: cfg.version,
    },
    panes: paneResults,
    summary: {
      install_sqft: totalInstall,
      fresh_sqft: totalInstall,
      naive_install_sqft: naiveInstall,
      saved_sqft: saved,
      face_sqft: totalFace,
      pulls: plan.pulls,
      seams: plan.seams,
      paired: pairedUnits.size,
      scrap_used_pieces: pairedPieces,
      scrap_used_cm2: scrapUsedCm2,
      final_scrap_pieces: plan.scraps.length,
      final_scrap_cm2: finalScrapCm2,
      final_scrap_sqft: Math.round((finalScrapCm2 / div) * 100) / 100,
      reusable_scrap_pieces: reusableScraps.length,
      reusable_scrap_cm2: reusableScrapCm2,
      waste_scrap_pieces: wasteScraps.length,
      waste_scrap_cm2: wasteScrapCm2,
      waste_scrap_sqft: Math.round((wasteScrapCm2 / div) * 100) / 100,
      waste_cm2: wasteScrapCm2,
      pieces: plan.pieces.length,
      fresh_raw_sqft: freshRawSqft,
      glass_raw_sqft: totalGlassCm2 / div,
      optimizer_trials: tried,
      optimization_is_exact: false,
      optimization_method: "deterministic-multi-start-global-search",
      plan: usedGlobal ? "global-scrap" : "per-pane",
      plan_order: `whole-job-global-search-${order}-${tried}`,
      note_th: usedGlobal
        ? `วางแผนทั้งงาน: ใช้เศษฟิล์มข้ามบาน ${pairedPieces} ชิ้น ประหยัด ${saved} ตร.ฟ.`
        : "วางแผนทั้งงานแล้ว — ยังไม่มีเศษที่นำกลับมาใช้กับบานอื่นได้",
      fresh_pull_cm: plan.freshLen,
      required_rolls: requiredRolls,
      roll_end_waste_cm: rollPack.unusedCm,
      orientation_status: orientationStatus,
      orientation_warnings: [...orientationWarnings],
    },
    events,
    finalScraps,
    glassAreaCm2: totalGlassCm2,
    glassAreaSqft: totalFace,
    installAreaSqft: totalInstall,
  };
}

export const FilmEngine = {
  setConfig,
  getConfig,
  resetConfig,
  colE,
  colF,
  mustJoinByRule,
  computeLayout,
  calcAreaRaw,
  calcAreaRounded,
  fmtDim,
  fmtAreaSqft,
  calculateJob,
};

export default FilmEngine;
