import type { Metrics } from "react-native-safe-area-context";

export function subscribeSafeAreaInsets(_callback: (metrics: Metrics) => void): () => void {
  // Safe-area context receives native measurements from react-native-safe-area-context.
  // The web shell intentionally keeps the zero-inset fallback; no remote runtime is needed.
  return () => undefined;
}
