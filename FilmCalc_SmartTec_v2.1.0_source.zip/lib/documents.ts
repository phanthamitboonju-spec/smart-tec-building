import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import type { AppSettings, Job, Product } from "./types";
import { JOB_STATUS_LABEL } from "./types";

const esc = (v: unknown) => String(v ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]!));
const baht = (n: number | null | undefined) => (n == null ? "รอทบทวนราคา" : `฿${n.toLocaleString("th-TH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);

const CSS = `body{font-family:sans-serif;color:#10243E;padding:24px;font-size:13px}h1{font-size:22px;margin:0}h2{font-size:15px;margin:18px 0 6px;border-bottom:2px solid #39B8F2;padding-bottom:3px}
table{width:100%;border-collapse:collapse}td,th{border:1px solid #C9D6E3;padding:5px 7px;text-align:left}th{background:#EAF4FB}.r{text-align:right}
.warn{background:#FFF8EA;border:1px solid #E5B84F;padding:8px;border-radius:6px;margin:10px 0}.block{background:#FFF0F0;border-color:#D9534F}.small{color:#6B7C93;font-size:11px}`;

function head(settings: AppSettings, title: string) {
  return `<h1>${esc(settings.companyName || "SmartTec")}</h1><div class="small">${esc(settings.companyPhone)} ${esc(settings.companyEmail)}</div><h2 style="font-size:18px">${title}</h2>`;
}

function statusBanner(job: Job) {
  const s = job.calculation?.orientationStatus;
  if (!s || s === "pass") return "";
  return `<div class="warn ${s === "block" ? "block" : ""}"><b>สถานะข้อกำหนดวัสดุ: ${s.toUpperCase()}</b> — ${s === "block" ? "ห้ามตัด/ติดตั้งตามแผนนี้" : "REVIEW ไม่เท่ากับ PASS ต้องตรวจเอกสารผู้ผลิตและข้อมูลหน้างานก่อนตัดจริง"}${job.calculation?.warnings.length ? "<br>" + job.calculation.warnings.map((w) => `• ${esc(w)}`).join("<br>") : ""}</div>`;
}

export function quotationHtml(job: Job, product: Product | undefined, settings: AppSettings): string {
  const q = job.quote, c = job.calculation;
  if (!q || !c) throw new Error("ยังไม่มีใบเสนอราคา — คำนวณและบันทึกงานก่อน");
  const rows: [string, string][] = [
    [`ฟิล์ม ${esc(product?.brand)} ${esc(product?.model)} (${esc(product?.sku)}) — ${q.quotedAreaSqft} ตร.ฟุต × ${q.unitRate ?? "-"}`, baht(q.unitRate == null ? null : q.quotedAreaSqft * q.unitRate)],
    ["ค่าเดินทาง", baht(q.extras.travelFee)], ["ค่านั่งร้าน", baht(q.extras.scaffoldFee)], ["ค่าลอกฟิล์มเก่า", baht(q.extras.oldFilmRemovalFee)], ["ค่าใช้จ่ายเพิ่มเติม", baht(q.extras.additionalFee)],
    ["ส่วนลด", `-${baht(q.discount)}`],
    [`ภาษี (${q.taxTreatment === "exclusive" ? "VAT 7% แยก" : q.taxTreatment === "inclusive" ? "VAT 7% รวมแล้ว" : "ไม่ระบุ"})`, baht(q.taxAmount)],
  ];
  return `<html><head><meta charset="utf-8"><style>${CSS}</style></head><body>${head(settings, "ใบเสนอราคา")}
<p>เลขที่ ${esc(q.quoteNumber)}<br>ลูกค้า: ${esc(q.customerName || job.customer)} · สถานที่: ${esc(job.site)}<br>วันที่ ${new Date(q.createdAt).toLocaleDateString("th-TH")} · ใช้ได้ถึง ${new Date(q.validUntil).toLocaleDateString("th-TH")}</p>
<p class="small">พื้นที่เสนอราคา = ฟิล์มใหม่ที่ดึงจากม้วนรวมทั้งงาน + บัฟเฟอร์ 2 ตร.ฟุต ปัดขึ้นครั้งเดียว (ไม่ใช่พื้นที่กระจกจริง ${c.glassAreaSqft.toFixed(2)} ตร.ฟุต)</p>
${statusBanner(job)}<table>${rows.map(([a, b]) => `<tr><td>${a}</td><td class="r">${b}</td></tr>`).join("")}<tr><th>ยอดรวม</th><th class="r">${baht(q.total)}</th></tr></table>
<h2>เงื่อนไข</h2><p>${esc(settings.paymentTerms)}<br>${esc(settings.deliveryTimeline)}</p></body></html>`;
}

export function workOrderHtml(job: Job, product: Product | undefined, settings: AppSettings): string {
  const c = job.calculation;
  if (!c) throw new Error("ยังไม่มีผลคำนวณ — คำนวณและบันทึกงานก่อน");
  const ck = job.checklist;
  return `<html><head><meta charset="utf-8"><style>${CSS}</style></head><body>${head(settings, "ใบสั่งงานช่างติดตั้ง")}
<p>งาน: ${esc(job.title)} · ลูกค้า: ${esc(job.customer)} · สถานที่: ${esc(job.site)}<br>สถานะ: ${JOB_STATUS_LABEL[job.status]} · ฟิล์ม: ${esc(product?.brand)} ${esc(product?.model)} (${esc(product?.sku)})</p>
${statusBanner(job)}
<h2>สรุปแผน</h2><p>พื้นที่กระจก ${c.glassAreaSqft.toFixed(2)} ตร.ฟุต · ฟิล์มใหม่ที่ดึง ${c.freshAreaSqft.toFixed(2)} ตร.ฟุต · ครั้งดึง ${c.rollPulls} · ม้วนจริง ${c.requiredRolls} · รอยต่อ ${c.totalSeams}</p>
<h2>รายการบาน</h2><table><tr><th>#</th><th>ชื่อ</th><th>กว้าง×สูง (ซม.)</th><th>จำนวน</th><th>แนวตัด</th></tr>${job.panes.map((p, i) => `<tr><td>${i + 1}</td><td>${esc(p.label)}</td><td>${p.widthCm}×${p.heightCm}</td><td>${p.qty}</td><td>${p.direction}</td></tr>`).join("")}</table>
<h2>การใช้ม้วน</h2><table><tr><th>ม้วน</th><th>รายละเอียด</th></tr>${c.rollUsage.map((r) => `<tr><td>${esc((r as { roll_label?: string }).roll_label ?? (r as { roll_id?: string }).roll_id)}</td><td class="small">${esc(JSON.stringify(r))}</td></tr>`).join("")}</table>
<h2>เศษคงเหลือในแผน</h2>${c.scraps.length ? `<table>${c.scraps.map((s) => `<tr><td>${s.widthCm}×${s.heightCm} ซม.</td><td>${esc(s.fromLabel)} · ${esc(s.rollLabel ?? s.rollId ?? "")}</td><td>${s.reusable ? "เก็บได้" : "ไม่เก็บ"}</td></tr>`).join("")}</table>` : "<p>ไม่มี</p>"}
<h2>เช็กลิสต์</h2><p>${ck.inspect ? "☑" : "☐"} ตรวจสภาพกระจก &nbsp; ${ck.surface ? "☑" : "☐"} เตรียมพื้นผิว &nbsp; ${ck.install ? "☑" : "☐"} ติดตั้งตามคู่มือรุ่น &nbsp; ${ck.handover ? "☑" : "☐"} ตรวจงานและส่งมอบ</p>
<h2>หมายเหตุส่งมอบ</h2><p>${esc(job.notes)}</p><p class="small">ช่างผู้ติดตั้ง ____________ ลูกค้าผู้รับมอบ ____________</p></body></html>`;
}

export async function shareHtmlAsPdf(html: string) {
  const { uri } = await Print.printToFileAsync({ html });
  if (!(await Sharing.isAvailableAsync())) throw new Error("อุปกรณ์นี้ไม่รองรับการแชร์ไฟล์");
  await Sharing.shareAsync(uri, { mimeType: "application/pdf", UTI: "com.adobe.pdf" });
}
