import type { CanonicalCalcResult } from "./source-engine/src/domain/calculation-service";
import type { RollProfile } from "./source-engine/src/domain/multi-roll-planner";

export type JobStatus = "draft" | "confirmed" | "installed" | "closed";
export type CutDirection = "auto" | "V" | "H";
export type PriceStatus = "active" | "contact";
export type TaxTreatment = "unspecified" | "exclusive" | "inclusive" | "not_applicable";
export type OrientationPolicy = "unknown" | "standard" | "directional";
export type FilmFace = "unknown" | "A" | "B";
export type FactoryEdge = "unknown" | "A" | "B";
export type SpliceMethod = "unknown" | "butt" | "overlay" | "overlap-cut-through" | "forbidden";

export interface PaneInput {
  id: string;
  label: string;
  widthCm: number;
  heightCm: number;
  qty: number;
  direction: CutDirection;
}

export interface ProductSpecs {
  thicknessMil?: number | null;
  vlt?: number | null;
  vlr?: number | null;
  uv?: number | null;
  irr?: number | null;
  tser?: number | null;
  sc?: number | null;
  warrantyYears?: number | null;
  notes?: string | null;
}

export interface Product {
  id: string;
  brand: string;
  brandKey?: string;
  model: string;
  sku: string;
  filmType: string;
  rollWidthCm: number;
  rollLengthCm: number;
  pricePerSqft: number;
  priceStatus: PriceStatus;
  note?: string;
  category?: string;
  group?: string;
  shade?: string;
  sourceVersion?: string;
  sourcePriceField?: string;
  specs?: ProductSpecs;
  isCustom?: boolean;
}

export interface RollRuleSettings {
  lotId: string;
  directionKey: string;
  policy: OrientationPolicy;
  face: FilmFace;
  factoryEdge: FactoryEdge;
  spliceMethod: SpliceMethod;
  spliceOverlapCm: string;
  specSource: string;
  specVerified: boolean;
}

export interface ScrapPiece {
  id: string;
  widthCm: number;
  heightCm: number;
  fromLabel: string;
  used: boolean;
  reusable: boolean;
  statusNote?: string;
  rollId?: string;
  rollLabel?: string;
}

export interface CalculationResult {
  engineVersion: string;
  /** Exact, immutable engine output. Documents/reports must read this snapshot, not recalculate. */
  planSnapshot: CanonicalCalcResult;
  glassAreaSqft: number;
  freshAreaSqft: number;
  installAreaSqft: number;
  quoteAreaSqft: number;
  rollPulls: number;
  requiredRolls: number;
  totalSeams: number;
  totalCutAreaCm2: number;
  wasteAreaSqft: number;
  scraps: ScrapPiece[];
  warnings: string[];
  orientationStatus: "pass" | "review" | "block";
  rollUsage: NonNullable<CanonicalCalcResult["engine"]["summary"]["roll_usage"]>;
  optimizationIsExact: boolean;
  optimizationMethod: string;
  physicalRolls: RollProfile[];
}

export interface QuoteExtra {
  travelFee: number;
  scaffoldFee: number;
  oldFilmRemovalFee: number;
  additionalFee: number;
}

export interface QuoteSnapshot {
  quoteNumber: string;
  customerName: string;
  quotedAreaSqft: number;
  unitRate: number | null;
  subtotal: number | null;
  extras: QuoteExtra;
  discount: number;
  taxTreatment: TaxTreatment;
  taxAmount: number;
  total: number | null;
  validUntil: string;
  createdAt: string;
}

export interface Job {
  id: string;
  title: string;
  customer: string;
  site: string;
  notes: string;
  status: JobStatus;
  productId: string;
  panes: PaneInput[];
  calculation: CalculationResult | null;
  quote: QuoteSnapshot | null;
  physicalRollRules?: RollRuleSettings;
  rollProfiles?: RollProfile[];
  legacyData?: { sourceVersion: string; calculation?: unknown; quote?: unknown };
  checklist: { inspect: boolean; surface: boolean; install: boolean; handover: boolean };
  createdAt: string;
  updatedAt: string;
}

export interface AppSettings {
  marginCm: number;
  defaultRollWidthCm: number;
  defaultRollLengthCm: number;
  companyName: string;
  companyPhone: string;
  companyEmail: string;
  quoteValidityDays: number;
  travelRatePerKm: number;
  scaffoldPricePerTier: number;
  paymentTerms: string;
  deliveryTimeline: string;
  areaUnit: "sqft" | "m2";
}

export interface AppData {
  schemaVersion: 2;
  jobs: Job[];
  products: Product[];
  settings: AppSettings;
  legacyProducts?: Product[];
  lastSavedAt: string | null;
}

export const JOB_STATUS_LABEL: Record<JobStatus, string> = {
  draft: "ร่าง",
  confirmed: "ยืนยันงาน",
  installed: "ติดตั้งแล้ว",
  closed: "ปิดงาน",
};
export const JOB_STATUS_FLOW: JobStatus[] = ["draft", "confirmed", "installed", "closed"];
export const JOB_STATUS_COLOR: Record<JobStatus, string> = {
  draft: "#F59E0B",
  confirmed: "#3B82F6",
  installed: "#22C55E",
  closed: "#64748B",
};
