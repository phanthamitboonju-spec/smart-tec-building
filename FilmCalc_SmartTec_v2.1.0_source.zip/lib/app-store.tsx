import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { AppData, AppSettings, Job, Product } from "./types";
import { DEFAULT_PRODUCTS, DEFAULT_SETTINGS } from "./film-calculator";

const STORAGE_KEY = "filmcalc:v2";
const LEGACY_STORAGE_KEY = "filmcalc:v1";

function seedData(): AppData {
  return {
    schemaVersion: 2,
    jobs: [],
    products: DEFAULT_PRODUCTS,
    settings: DEFAULT_SETTINGS,
    legacyProducts: [],
    lastSavedAt: null,
  };
}

type StoreContextValue = AppData & {
  hydrated: boolean;
  addJob: (job: Omit<Job, "id" | "createdAt" | "updatedAt">) => Job;
  updateJob: (id: string, patch: Partial<Job>) => void;
  deleteJob: (id: string) => void;
  addProduct: (product: Omit<Product, "id">) => void;
  updateProduct: (id: string, patch: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  updateSettings: (patch: Partial<AppSettings>) => void;
  replaceAll: (next: AppData) => void;
};

const StoreContext = createContext<StoreContextValue | null>(null);

function migrateLegacy(parsed: Partial<AppData> & { jobs?: Job[]; products?: Product[]; settings?: Partial<AppSettings> }): AppData {
  const legacyJobs = Array.isArray(parsed.jobs) ? parsed.jobs : [];
  const migratedJobs: Job[] = legacyJobs.map((job) => ({
    ...job,
    productId: DEFAULT_PRODUCTS.find((p) => p.sku === (parsed.products ?? []).find((old) => old.id === job.productId)?.sku)?.id ?? "",
    // Old calculations came from the app's simplified planner. Keep them as history,
    // but never present them as approved v10.36.1 plans or reuse their quotation totals.
    calculation: null,
    quote: null,
    status: "draft",
    legacyData: {
      sourceVersion: "FilmCalc pre-v10.36.1 mobile planner",
      calculation: job.calculation,
      quote: job.quote,
    },
    notes: [job.notes, "ข้อมูลจากรุ่นก่อน: ต้องเลือกฟิล์มและคำนวณใหม่ด้วยเอนจิน 10.36.1 ก่อนใช้ตัดจริงหรือออกใบเสนอราคา"].filter(Boolean).join("\n"),
  }));
  return {
    ...seedData(),
    jobs: migratedJobs,
    settings: { ...DEFAULT_SETTINGS, ...(parsed.settings ?? {}) },
    // Preserve the prior catalog separately for reference. It is not silently mixed with
    // the authoritative building-film catalog from the original system.
    legacyProducts: Array.isArray(parsed.products) ? parsed.products : [],
    lastSavedAt: null,
  };
}

export function AppStoreProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(seedData);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    let mounted = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then(async (storedV2) => {
        if (!mounted) return;
        if (storedV2) {
          try {
            const parsed = JSON.parse(storedV2) as Partial<AppData>;
            setData({
              ...seedData(),
              ...parsed,
              schemaVersion: 2,
              products: Array.isArray(parsed.products) && parsed.products.length ? parsed.products : DEFAULT_PRODUCTS,
              settings: { ...DEFAULT_SETTINGS, ...(parsed.settings ?? {}) },
            });
            return;
          } catch {
            // Fall through to the legacy migration rather than discard the old store.
          }
        }
        const storedV1 = await AsyncStorage.getItem(LEGACY_STORAGE_KEY);
        if (!mounted) return;
        if (storedV1) {
          try {
            setData(migrateLegacy(JSON.parse(storedV1) as Partial<AppData> & { jobs?: Job[]; products?: Product[]; settings?: Partial<AppSettings> }));
          } catch {
            setData(seedData());
          }
        }
      })
      .catch(() => { if (mounted) setData(seedData()); })
      .finally(() => { if (mounted) setHydrated(true); });
    return () => { mounted = false; };
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({ ...data, schemaVersion: 2 })).catch(() => undefined);
  }, [data, hydrated]);

  const value = useMemo<StoreContextValue>(() => {
    const touch = (current: AppData): AppData => ({ ...current, lastSavedAt: new Date().toISOString() });
    return {
      ...data,
      hydrated,
      addJob: (job) => {
        const now = new Date().toISOString();
        const created: Job = { ...job, id: `job-${Date.now()}`, createdAt: now, updatedAt: now };
        setData((current) => touch({ ...current, jobs: [created, ...current.jobs] }));
        return created;
      },
      updateJob: (id, patch) => setData((current) => touch({ ...current, jobs: current.jobs.map((job) => job.id === id ? { ...job, ...patch, updatedAt: new Date().toISOString() } : job) })),
      deleteJob: (id) => setData((current) => touch({ ...current, jobs: current.jobs.filter((job) => job.id !== id) })),
      addProduct: (product) => setData((current) => touch({ ...current, products: [{ ...product, id: `custom-${Date.now()}`, isCustom: true }, ...current.products] })),
      updateProduct: (id, patch) => setData((current) => touch({ ...current, products: current.products.map((item) => item.id === id ? { ...item, ...patch } : item) })),
      deleteProduct: (id) => setData((current) => touch({ ...current, products: current.products.filter((item) => item.id !== id) })),
      replaceAll: (next) => {
        AsyncStorage.setItem(`${STORAGE_KEY}:pre-import`, JSON.stringify(data)).catch(() => undefined);
        setData(touch({ ...seedData(), ...next, schemaVersion: 2 }));
      },
      updateSettings: (patch) => setData((current) => touch({ ...current, settings: { ...current.settings, ...patch } })),
    };
  }, [data, hydrated]);

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useAppStore() {
  const value = useContext(StoreContext);
  if (!value) throw new Error("useAppStore ต้องถูกใช้ภายใน AppStoreProvider");
  return value;
}
