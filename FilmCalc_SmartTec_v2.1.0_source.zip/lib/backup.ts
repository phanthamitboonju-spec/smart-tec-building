import { File, Paths } from "expo-file-system";
import * as DocumentPicker from "expo-document-picker";
import * as Sharing from "expo-sharing";
import type { AppData } from "./types";
import { DEFAULT_SETTINGS } from "./film-calculator";

const FORMAT = "filmcalc-backup";

export function buildBackupPayload(data: AppData) {
  return { format: FORMAT, schemaVersion: 2, exportedAt: new Date().toISOString(), data };
}

/** Validates a parsed backup completely before anything is replaced (all-or-nothing import). */
export function validateBackup(raw: unknown): AppData {
  const root = raw as { format?: string; schemaVersion?: number; data?: Partial<AppData> };
  if (!root || root.format !== FORMAT) throw new Error("ไฟล์นี้ไม่ใช่ไฟล์สำรองของ FilmCalc");
  if (root.schemaVersion !== 2 || !root.data) throw new Error("ไฟล์สำรองเป็นเวอร์ชันที่ไม่รองรับ");
  const d = root.data;
  if (!Array.isArray(d.jobs) || !Array.isArray(d.products)) throw new Error("ไฟล์สำรองไม่สมบูรณ์ (ไม่มีรายการงานหรือสินค้า)");
  for (const job of d.jobs) {
    if (!job || typeof job.id !== "string" || !Array.isArray(job.panes)) throw new Error("พบงานที่ข้อมูลเสียหายในไฟล์สำรอง");
  }
  for (const p of d.products) {
    if (!p || typeof p.id !== "string" || typeof p.sku !== "string") throw new Error("พบสินค้าที่ข้อมูลเสียหายในไฟล์สำรอง");
  }
  return {
    schemaVersion: 2,
    jobs: d.jobs,
    products: d.products,
    settings: { ...DEFAULT_SETTINGS, ...(d.settings ?? {}) },
    legacyProducts: d.legacyProducts ?? [],
    lastSavedAt: d.lastSavedAt ?? null,
  };
}

export async function exportBackup(data: AppData): Promise<string> {
  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
  const file = new File(Paths.cache, `filmcalc-backup-${stamp}.json`);
  file.create({ overwrite: true });
  file.write(JSON.stringify(buildBackupPayload(data)));
  if (!(await Sharing.isAvailableAsync())) throw new Error("อุปกรณ์นี้ไม่รองรับการแชร์ไฟล์");
  await Sharing.shareAsync(file.uri, { mimeType: "application/json", dialogTitle: "บันทึกไฟล์สำรอง FilmCalc" });
  return file.uri;
}

export async function pickBackup(): Promise<AppData | null> {
  const res = await DocumentPicker.getDocumentAsync({ type: ["application/json", "text/plain", "*/*"], copyToCacheDirectory: true });
  if (res.canceled || !res.assets?.[0]) return null;
  const text = await new File(res.assets[0].uri).text();
  let parsed: unknown;
  try { parsed = JSON.parse(text); } catch { throw new Error("อ่านไฟล์ไม่ได้ (ไม่ใช่ JSON)"); }
  return validateBackup(parsed);
}

