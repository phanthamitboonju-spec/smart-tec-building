import { CATALOG } from "./source-engine/src/data/catalog-data.ts";
import {
  runMultiRollCalculation,
  type RollProfile as SourceRollProfile,
} from "./source-engine/src/domain/multi-roll-planner.ts";
import type { CanonicalCalcResult } from "./source-engine/src/domain/calculation-service.ts";
import { materialSpecForSku } from "./source-engine/src/domain/calculation-service.ts";
import { CM2_PER_SQFT } from "./source-engine/src/domain/units.ts";
import { SYSTEM_VERSION } from "./source-engine/src/version.ts";
import type { AppSettings, PaneInput, Product, CalculationResult, RollRuleSettings } from "./types";

export const ENGINE_VERSION = SYSTEM_VERSION;

export const CM2_PER_SQFT_APP = CM2_PER_SQFT;

interface CatalogProduct {
  skuId: string;
  code: string;
  codeNorm: string;
  brand: string;
  brandKey: string;
  name: string;
  filmType: string;
  group: string;
  price: number;
  selectable: boolean;
  identifierKind: string;
  priceStatus: "active" | "contact";
  rollWidthCm: number | null;
  rollLengthM: number | null;
  specs?: Product["specs"];
  shade?: string | null;
  productDescription?: string | null;
  category?: string;
}

const catalogRows = (CATALOG as unknown as { products: CatalogProduct[] }).products;

/** Only current, selectable building-film SKUs are offered. Vehicle/PPF references stay out. */
export const DEFAULT_PRODUCTS: Product[] = catalogRows
  .filter((item) => item.selectable && item.identifierKind === "sku")
  .map((item) => ({
    id: item.skuId,
    brand: item.brand,
    brandKey: item.brandKey,
    model: item.name,
    sku: item.code,
    filmType: item.filmType || item.group || item.category || "ฟิล์มอาคาร",
    rollWidthCm: Number(item.rollWidthCm ?? 0),
    rollLengthCm: Number(item.rollLengthM ?? 0) * 100,
    pricePerSqft: Number(item.price ?? 0),
    priceStatus: item.priceStatus,
    sourceVersion: "SmartTec Film Database SSOT v2.1",
    sourcePriceField: "C6",
    category: item.category,
    group: item.group,
    shade: item.shade ?? "",
    note: item.productDescription ?? "",
    specs: item.specs ?? undefined,
    isCustom: false,
  }));

export const DEFAULT_SETTINGS: AppSettings = {
  marginCm: 2,
  defaultRollWidthCm: 152,
  defaultRollLengthCm: 3000,
  companyName: "SmartTec",
  companyPhone: "",
  companyEmail: "",
  quoteValidityDays: 15,
  travelRatePerKm: 0,
  scaffoldPricePerTier: 0,
  paymentTerms: "ชำระตามเงื่อนไขที่ตกลงร่วมกัน",
  deliveryTimeline: "กำหนดวันติดตั้งตามการนัดหมายและความพร้อมของพื้นที่",
  areaUnit: "sqft",
};

export function formatArea(valueSqft: number, unit: "sqft" | "m2" = "sqft") {
  const safe = Number.isFinite(valueSqft) ? Math.max(0, valueSqft) : 0;
  return unit === "m2" ? `${(safe * 0.09290304).toFixed(2)} ม²` : `${safe.toFixed(2)} ตร.ฟุต`;
}

export function normalizeNumber(value: string, fallback = 0) {
  const parsed = Number(String(value ?? "").replace(/,/g, ".").trim());
  return Number.isFinite(parsed) ? parsed : fallback;
}

export function newPane(index = 0): PaneInput {
  return { id: `pane-${Date.now()}-${index}`, label: `บาน ${index + 1}`, widthCm: 120, heightCm: 180, qty: 1, direction: "auto" };
}

export const DEFAULT_ROLL_RULES: RollRuleSettings = {
  lotId: "",
  directionKey: "",
  policy: "unknown",
  face: "unknown",
  factoryEdge: "unknown",
  spliceMethod: "unknown",
  spliceOverlapCm: "",
  specSource: "",
  specVerified: false,
};

export function buildPhysicalRollProfiles(
  product: Product,
  count: number,
  settings: AppSettings,
  rules: RollRuleSettings = DEFAULT_ROLL_RULES,
  jobKey = "job",
): SourceRollProfile[] {
  const n = Math.max(1, Math.min(20, Math.floor(Number(count) || 1)));
  const width = Number(product.rollWidthCm || settings.defaultRollWidthCm);
  const length = Number(product.rollLengthCm || settings.defaultRollLengthCm);
  const catalogOrCustomDimensionsVerified = product.isCustom === true || (
    Number(product.rollWidthCm) >= 50 && Number(product.rollWidthCm) <= 300 &&
    Number(product.rollLengthCm) >= 100 && Number(product.rollLengthCm) <= 20000
  );
  // Default dimensions are only an estimate. They must never be promoted to verified physical stock.
  const verified = rules.specVerified === true && Boolean(rules.specSource.trim()) && catalogOrCustomDimensionsVerified;
  const policy = rules.policy;
  const rotations = policy === "standard" ? [0, 90] as const : policy === "directional" ? [0] as const : undefined;
  const group = rules.lotId.trim() ? `${jobKey}-lot-${rules.lotId.trim()}` : undefined;

  return Array.from({ length: n }, (_, index) => ({
    id: `R${index + 1}`,
    label: `ม้วน ${index + 1}`,
    width_cm: width,
    length_cm: length,
    lotId: rules.lotId.trim(),
    directionKey: rules.directionKey.trim() || undefined,
    policy,
    face: rules.face,
    factoryEdge: rules.factoryEdge,
    allowedRotations: rotations ? [...rotations] : undefined,
    sameLotForSplice: true,
    specSource: rules.specSource.trim(),
    specVerified: verified,
    spliceMethod: rules.spliceMethod,
    spliceOverlapCm: rules.spliceOverlapCm.trim() ? Number(rules.spliceOverlapCm) : undefined,
    planningGroupId: group,
  }));
}

export function calculateJob(
  panes: PaneInput[],
  product: Product,
  marginCm = 2,
  physicalRolls?: SourceRollProfile[],
): CalculationResult {
  if (!product) throw new Error("กรุณาเลือกฟิล์มก่อนคำนวณ");
  if (!Array.isArray(panes) || panes.length === 0) throw new Error("กรุณาเพิ่มรายการบานอย่างน้อย 1 รายการ");
  const profiles = physicalRolls?.length
    ? physicalRolls
    : buildPhysicalRollProfiles(product, 1, DEFAULT_SETTINGS, DEFAULT_ROLL_RULES);
  // The profile may contain estimate-only default dimensions when the catalog has no size.
  // Source engine will mark these as REVIEW because the roll rule verification is false.
  const width = Number(profiles[0]?.width_cm ?? product.rollWidthCm);
  const length = Number(profiles[0]?.length_cm ?? product.rollLengthCm);
  if (!(width >= 50 && width <= 300) || !(length >= 100 && length <= 20000)) {
    throw new Error("ไม่พบขนาดม้วนที่ยืนยันได้ กรุณาตรวจฉลากสินค้าและตั้งค่าหน้ากว้าง/ความยาวม้วนก่อนคำนวณ");
  }

  const material = materialSpecForSku(product.sku, product.brandKey) ?? {
    sku: `${product.brandKey ?? product.brand}:${product.sku}`,
    policy: "unknown" as const,
    face: "unknown" as const,
    factoryEdge: "unknown" as const,
  };
  const engineInput = panes.map((pane) => ({
    id: pane.id,
    label: pane.label,
    width_cm: Number(pane.widthCm),
    height_cm: Number(pane.heightCm),
    qty: Number(pane.qty),
    dir: pane.direction,
    face: "unknown" as const,
    material,
  }));
  const sourcePlan: CanonicalCalcResult = runMultiRollCalculation(
    engineInput,
    {
      filmMax: width,
      rollLen: length,
      margin: marginCm,
      divisor: CM2_PER_SQFT,
      scrapMin: 0,
      minStrip: 15,
      spliceAllowanceCm: 0,
      quoteBufferPct: 2,
      dimensionUnit: "cm",
      areaUnit: "sqft",
      jobProfile: "building-film",
      version: ENGINE_VERSION,
      materialOrientation: material,
      optimizerEffort: "full",
    },
    material,
    profiles,
  );

  const engine = sourcePlan.engine;
  const finalScraps = engine.finalScraps ?? [];
  const cutAreaCm2 = sourcePlan.cut_area_raw_sqft * CM2_PER_SQFT;
  return {
    engineVersion: sourcePlan.version,
    planSnapshot: sourcePlan,
    glassAreaSqft: sourcePlan.glass_area_raw_sqft,
    freshAreaSqft: sourcePlan.fresh_raw_sqft,
    installAreaSqft: sourcePlan.install_sqft,
    quoteAreaSqft: Number(sourcePlan.quote_area_sqft ?? 0),
    rollPulls: Number(engine.summary.pulls ?? 0),
    requiredRolls: Number(engine.summary.required_rolls ?? 0),
    totalSeams: Number(engine.summary.seams ?? 0),
    totalCutAreaCm2: Number(cutAreaCm2.toFixed(4)),
    wasteAreaSqft: Number((Number(engine.summary.waste_scrap_cm2 ?? 0) / CM2_PER_SQFT).toFixed(4)),
    scraps: finalScraps.map((scrap) => ({
      id: scrap.id,
      widthCm: Number(scrap.width_cm),
      heightCm: Number(scrap.height_cm),
      fromLabel: `บาน ${scrap.origin_pane_index ?? scrap.pane_id ?? "ไม่ระบุ"}`,
      used: false,
      reusable: scrap.reusable,
      statusNote: scrap.status_note_th,
      rollId: scrap.roll_id,
      rollLabel: scrap.roll_label,
    })),
    warnings: [...new Set([...(engine.summary.orientation_warnings ?? [])])],
    orientationStatus: engine.summary.orientation_status,
    rollUsage: engine.summary.roll_usage ?? [],
    optimizationIsExact: (engine.summary.optimization_is_exact as boolean | undefined) === true,
    optimizationMethod: engine.summary.optimization_method ?? "deterministic-heuristic",
    physicalRolls: profiles,
  };
}
