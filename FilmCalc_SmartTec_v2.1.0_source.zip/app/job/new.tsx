import { JobEditor } from "@/components/job-editor";
export default function NewJobRoute() { return <JobEditor />; }
