import { useLocalSearchParams } from "expo-router";
import { JobEditor } from "@/components/job-editor";
export default function JobDetailRoute() { const { id } = useLocalSearchParams<{ id: string }>(); return <JobEditor jobId={id} />; }
