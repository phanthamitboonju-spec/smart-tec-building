import { useState } from "react";
import { Alert, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { Button, Card, COLORS, Field, Header, Page, SectionTitle } from "@/components/film-ui";
import { useAppStore } from "@/lib/app-store";
import { normalizeNumber } from "@/lib/film-calculator";
import { exportBackup, pickBackup } from "@/lib/backup";

export default function SettingsScreen() {
  const router = useRouter();
  const store = useAppStore();
  const { settings, updateSettings, lastSavedAt, products, jobs, legacyProducts } = store;
  const [form, setForm] = useState({
    companyName: settings.companyName,
    companyPhone: settings.companyPhone,
    companyEmail: settings.companyEmail,
    margin: String(settings.marginCm),
    width: String(settings.defaultRollWidthCm),
    length: String(settings.defaultRollLengthCm),
    validity: String(settings.quoteValidityDays),
    payment: settings.paymentTerms,
  });
  const [saved, setSaved] = useState(false);
  const [backupMsg, setBackupMsg] = useState("");
  const doExport = async () => {
    try { await exportBackup({ schemaVersion: 2, jobs, products, settings, legacyProducts, lastSavedAt }); setBackupMsg("ส่งออกไฟล์สำรองแล้ว"); }
    catch (e) { setBackupMsg(`สำรองไม่สำเร็จ: ${(e as Error).message}`); }
  };
  const doImport = async () => {
    try {
      const next = await pickBackup();
      if (!next) return;
      Alert.alert("กู้คืนข้อมูล", `จะแทนที่ข้อมูลปัจจุบันด้วยไฟล์สำรอง (${next.jobs.length} งาน, ${next.products.length} สินค้า) ข้อมูลเดิมจะถูกเก็บสำเนาไว้ในเครื่องก่อนแทนที่`, [
        { text: "ยกเลิก", style: "cancel" },
        { text: "กู้คืน", style: "destructive", onPress: () => { store.replaceAll(next); setBackupMsg("กู้คืนข้อมูลแล้ว"); } },
      ]);
    } catch (e) { setBackupMsg(`กู้คืนไม่สำเร็จ (ข้อมูลเดิมไม่ถูกแก้ไข): ${(e as Error).message}`); }
  };
  const update = (key: keyof typeof form, value: string) => {
    setForm((current) => ({ ...current, [key]: value }));
    setSaved(false);
  };
  const save = () => {
    updateSettings({
      companyName: form.companyName,
      companyPhone: form.companyPhone,
      companyEmail: form.companyEmail,
      marginCm: Math.max(0, Math.min(20, normalizeNumber(form.margin, 2))),
      defaultRollWidthCm: Math.max(50, Math.min(300, normalizeNumber(form.width, 152))),
      defaultRollLengthCm: Math.max(100, Math.min(20000, normalizeNumber(form.length, 3000))),
      quoteValidityDays: Math.max(1, Math.min(365, Math.round(normalizeNumber(form.validity, 15)))),
      paymentTerms: form.payment,
    });
    setSaved(true);
  };

  return <Page>
    <Header eyebrow="APP SETTINGS" title="ตั้งค่า" subtitle="ข้อมูลบริษัท ค่าคำนวณ และการจัดเก็บในอุปกรณ์" />
    <Card>
      <SectionTitle>ข้อมูลบริษัท</SectionTitle>
      <Field label="ชื่อบริษัท/ทีมช่าง" value={form.companyName} onChangeText={(v) => update("companyName", v)} placeholder="SmartTec" />
      <Field label="โทรศัพท์" value={form.companyPhone} onChangeText={(v) => update("companyPhone", v)} keyboardType="phone-pad" placeholder="เบอร์ติดต่อ" />
      <Field label="อีเมล" value={form.companyEmail} onChangeText={(v) => update("companyEmail", v)} keyboardType="email-address" placeholder="อีเมลบริษัท" />
      <Field label="เงื่อนไขชำระเงิน" value={form.payment} onChangeText={(v) => update("payment", v)} multiline numberOfLines={2} />
    </Card>

    <SectionTitle>ค่าคำนวณเริ่มต้น</SectionTitle>
    <Card>
      <Text style={{ color: COLORS.muted, fontSize: 12, lineHeight: 19, marginBottom: 12 }}>ค่าหน้ากว้างและความยาวนี้เป็นค่า fallback สำหรับประมาณการเท่านั้น เมื่อ SKU ไม่มีขนาดม้วนในแคตตาล็อก ระบบจะยังคงสถานะ REVIEW และไม่ถือว่าเป็นข้อมูลม้วนจริงที่ยืนยันแล้ว ต้องตรวจฉลากม้วนก่อนตัดจริง</Text>
      <View style={{ flexDirection: "row", gap: 10 }}>
        <View style={{ flex: 1 }}><Field label="เผื่อขอบ/ด้าน (ซม.)" keyboardType="decimal-pad" value={form.margin} onChangeText={(v) => update("margin", v)} /></View>
        <View style={{ flex: 1 }}><Field label="หน้ากว้างเริ่มต้น (ซม.)" keyboardType="decimal-pad" value={form.width} onChangeText={(v) => update("width", v)} /></View>
      </View>
      <Field label="ความยาวม้วนเริ่มต้น (ซม.)" keyboardType="decimal-pad" value={form.length} onChangeText={(v) => update("length", v)} />
      <Field label="อายุใบเสนอราคา (วัน)" keyboardType="number-pad" value={form.validity} onChangeText={(v) => update("validity", v)} />
      <Button icon="save" onPress={save}>บันทึกการตั้งค่า</Button>
      {saved ? <Text style={{ color: "#218544", fontSize: 12, fontWeight: "800", marginTop: 9 }}>บันทึกการตั้งค่าแล้ว</Text> : null}
    </Card>

    <SectionTitle>สถานะข้อมูลในอุปกรณ์</SectionTitle>
    <Card>
      <View style={{ flexDirection: "row", justifyContent: "space-between", paddingVertical: 5 }}><Text style={{ color: COLORS.muted, fontSize: 12 }}>แคตตาล็อกฟิล์มอาคาร</Text><Text style={{ color: COLORS.ink, fontWeight: "900" }}>{products.length} SKU</Text></View>
      <View style={{ flexDirection: "row", justifyContent: "space-between", paddingVertical: 5 }}><Text style={{ color: COLORS.muted, fontSize: 12 }}>งานที่บันทึกในเครื่อง</Text><Text style={{ color: COLORS.ink, fontWeight: "900" }}>{jobs.length} งาน</Text></View>
      <View style={{ flexDirection: "row", justifyContent: "space-between", paddingVertical: 5 }}><Text style={{ color: COLORS.muted, fontSize: 12 }}>ข้อมูลแคตตาล็อกเก่าที่เก็บอ้างอิง</Text><Text style={{ color: COLORS.ink, fontWeight: "900" }}>{legacyProducts?.length ?? 0} รายการ</Text></View>
      <View style={{ flexDirection: "row", justifyContent: "space-between", paddingVertical: 5 }}><Text style={{ color: COLORS.muted, fontSize: 12 }}>บันทึกล่าสุด</Text><Text style={{ color: COLORS.ink, fontWeight: "800" }}>{lastSavedAt ? new Date(lastSavedAt).toLocaleString("th-TH") : "ยังไม่มีข้อมูล"}</Text></View>
      <View style={{ flexDirection: "row", alignItems: "center", backgroundColor: "#EAF9EE", borderRadius: 11, padding: 11, marginTop: 10 }}>
        <Text style={{ color: "#218544", fontSize: 12, fontWeight: "900" }}>ใช้งานออฟไลน์ · ไม่ต้องล็อกอิน</Text>
      </View>
      <Text style={{ color: COLORS.muted, fontSize: 11, lineHeight: 18, marginTop: 9 }}>ข้อมูลถูกจัดเก็บภายในอุปกรณ์ ไม่มีการซิงก์ขึ้นคลาวด์ หากถอนหรือล้างข้อมูลแอปข้อมูลจะหาย กรุณาส่งออกไฟล์สำรองเป็นระยะ</Text>
    </Card>

    <SectionTitle>สำรอง / กู้คืนข้อมูล</SectionTitle>
    <Card>
      <View style={{ flexDirection: "row", gap: 10 }}><Button icon="upload" onPress={doExport} style={{ flex: 1 }}>ส่งออกสำรอง</Button><Button icon="download" variant="secondary" onPress={doImport} style={{ flex: 1 }}>กู้คืนจากไฟล์</Button></View>
      {backupMsg ? <Text style={{ color: COLORS.muted, fontSize: 12, marginTop: 9 }}>{backupMsg}</Text> : null}
    </Card>
    <Button variant="secondary" icon="book-open" onPress={() => router.push("/tools")} style={{ marginTop: 16 }}>เปิดคู่มือและแปลงหน่วย</Button>
    <Card style={{ marginTop: 16, backgroundColor: COLORS.navy, borderColor: COLORS.navy }}>
      <Text style={{ color: COLORS.cyan, fontWeight: "900", letterSpacing: 1 }}>FILMCALC · ANDROID READY SOURCE</Text>
      <Text style={{ color: COLORS.white, fontSize: 13, lineHeight: 20, marginTop: 7 }}>แอปวางแผนงานติดตั้งฟิล์มอาคารแบบออฟไลน์ ใช้เอนจินคำนวณต้นฉบับ 10.36.1 และแคตตาล็อกข้อมูลบริษัท</Text>
      <Text style={{ color: "#9EBBD3", fontSize: 11, marginTop: 10 }}>วัดให้ครบ · วางแผนทั้งงาน · ตรวจ REVIEW/BLOCK ก่อนตัด</Text>
    </Card>
  </Page>;
}
