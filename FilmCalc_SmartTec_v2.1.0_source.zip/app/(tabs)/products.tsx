import { Feather } from "@expo/vector-icons";
import { useState } from "react";
import { Alert, Text, View } from "react-native";
import { Button, Card, COLORS, Field, Header, IconButton, Page, SectionTitle } from "@/components/film-ui";
import { useAppStore } from "@/lib/app-store";
import { normalizeNumber } from "@/lib/film-calculator";

export default function ProductsScreen() {
  const { products, addProduct, deleteProduct } = useAppStore();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ brand: "", model: "", sku: "", filmType: "กันความร้อน", price: "", width: "", length: "" });
  const update = (key: keyof typeof form, value: string) => setForm((current) => ({ ...current, [key]: value }));
  const submit = () => {
    const width = normalizeNumber(form.width, Number.NaN);
    const length = normalizeNumber(form.length, Number.NaN);
    const price = normalizeNumber(form.price);
    if (!form.brand.trim() || !form.model.trim() || !form.sku.trim()) {
      Alert.alert("ข้อมูลสินค้าไม่ครบ", "กรุณากรอกแบรนด์ รุ่น และ SKU");
      return;
    }
    if (!(width >= 50 && width <= 300) || !(length >= 100 && length <= 20000)) {
      Alert.alert("ขนาดม้วนไม่ถูกต้อง", "กรุณากรอกหน้ากว้างจริง 50–300 ซม. และความยาวจริง 100–20,000 ซม. จากฉลากม้วน");
      return;
    }
    addProduct({ brand: form.brand.trim(), model: form.model.trim(), sku: form.sku.trim(), filmType: form.filmType.trim() || "ทั่วไป", pricePerSqft: price, priceStatus: price > 0 ? "active" : "contact", rollWidthCm: width, rollLengthCm: length });
    setForm({ brand: "", model: "", sku: "", filmType: "กันความร้อน", price: "", width: "", length: "" });
    setShowForm(false);
  };
  return <Page><Header eyebrow="FILM CATALOG" title="รายการฟิล์ม" subtitle="สินค้าและสเปกม้วนที่ใช้ในแผนงาน" right={<Button icon={showForm ? "x" : "plus"} onPress={() => setShowForm(!showForm)}>{showForm ? "ปิดฟอร์ม" : "เพิ่มสินค้า"}</Button>} />
    {showForm ? <Card style={{ marginBottom: 16 }}><SectionTitle>เพิ่มรายการฟิล์มอาคาร</SectionTitle><Field label="แบรนด์" value={form.brand} onChangeText={(v) => update("brand", v)} placeholder="เช่น SmartTec" /><Field label="รุ่น" value={form.model} onChangeText={(v) => update("model", v)} placeholder="เช่น Solar Shield 50" /><View style={{ flexDirection: "row", gap: 10 }}><View style={{ flex: 1 }}><Field label="SKU" value={form.sku} onChangeText={(v) => update("sku", v)} placeholder="ST-SS50" /></View><View style={{ flex: 1 }}><Field label="ประเภท" value={form.filmType} onChangeText={(v) => update("filmType", v)} placeholder="กันความร้อน" /></View></View><View style={{ flexDirection: "row", gap: 10 }}><View style={{ flex: 1 }}><Field label="ราคา/ตร.ฟุต" keyboardType="decimal-pad" value={form.price} onChangeText={(v) => update("price", v)} placeholder="เว้นว่าง = ติดต่อราคา" /></View><View style={{ flex: 1 }}><Field label="หน้ากว้างม้วนจริง (ซม.)" keyboardType="decimal-pad" value={form.width} onChangeText={(v) => update("width", v)} placeholder="อ่านจากฉลากม้วน" /></View></View><Field label="ความยาวม้วนจริง (ซม.)" keyboardType="decimal-pad" value={form.length} onChangeText={(v) => update("length", v)} placeholder="อ่านจากฉลากม้วน" /><Button icon="save" onPress={submit}>บันทึกสินค้า</Button></Card> : null}
    <Text style={{ color: COLORS.muted, fontSize: 12, marginBottom: 8 }}>{products.length} รายการ · เพิ่มรายการบริษัทและนำรายการออกจากอุปกรณ์ได้</Text>
    {products.map((product) => <Card key={product.id} style={{ marginBottom: 10 }}><View style={{ flexDirection: "row", alignItems: "flex-start" }}><View style={{ width: 42, height: 42, borderRadius: 14, backgroundColor: COLORS.cyanSoft, alignItems: "center", justifyContent: "center", marginRight: 11 }}><Feather name="layers" size={20} color="#0A6B93" /></View><View style={{ flex: 1 }}><Text style={{ color: COLORS.ink, fontWeight: "900", fontSize: 16 }}>{product.brand} · {product.model}</Text><Text style={{ color: COLORS.muted, fontSize: 12, marginTop: 4 }}>{product.sku} · {product.filmType}</Text></View><IconButton icon="trash-2" label="ลบสินค้า" onPress={() => Alert.alert("นำสินค้าออกจากอุปกรณ์?", `ต้องการลบ ${product.brand} · ${product.model} ใช่หรือไม่`, [{ text: "ยกเลิก", style: "cancel" }, { text: "ลบสินค้า", style: "destructive", onPress: () => deleteProduct(product.id) }])} /></View><View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 14 }}><View style={{ backgroundColor: COLORS.paper, borderRadius: 8, paddingHorizontal: 9, paddingVertical: 6 }}><Text style={{ color: COLORS.ink, fontSize: 11, fontWeight: "800" }}>{product.rollWidthCm} × {product.rollLengthCm} ซม.</Text></View><View style={{ backgroundColor: product.priceStatus === "active" ? "#EAF9EE" : "#FFF4DF", borderRadius: 8, paddingHorizontal: 9, paddingVertical: 6 }}><Text style={{ color: product.priceStatus === "active" ? "#218544" : "#A56B10", fontSize: 11, fontWeight: "800" }}>{product.priceStatus === "active" ? `฿${product.pricePerSqft}/ตร.ฟุต` : "ติดต่อราคา"}</Text></View></View></Card>)}
  </Page>;
}
