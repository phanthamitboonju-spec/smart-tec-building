import { Tabs } from "expo-router";
import { Feather } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Platform } from "react-native";
import { COLORS } from "@/components/film-ui";

const icons: Record<string, React.ComponentProps<typeof Feather>["name"]> = { index: "grid", jobs: "clipboard", products: "layers", reports: "bar-chart-2", settings: "settings" };

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const bottom = Platform.OS === "web" ? 10 : Math.max(insets.bottom, 8);
  return <Tabs screenOptions={({ route }) => ({ headerShown: false, tabBarActiveTintColor: COLORS.cyan, tabBarInactiveTintColor: "#8EA0B4", tabBarLabelStyle: { fontSize: 10, fontWeight: "700", marginBottom: 2 }, tabBarStyle: { height: 58 + bottom, paddingTop: 8, paddingBottom: bottom, backgroundColor: COLORS.navy, borderTopWidth: 0 }, tabBarIcon: ({ color, size }) => <Feather name={icons[route.name] ?? "circle"} size={size - 1} color={color} /> })}>
    <Tabs.Screen name="index" options={{ title: "ภาพรวม" }} />
    <Tabs.Screen name="jobs" options={{ title: "งาน" }} />
    <Tabs.Screen name="products" options={{ title: "สินค้า" }} />
    <Tabs.Screen name="reports" options={{ title: "รายงาน" }} />
    <Tabs.Screen name="settings" options={{ title: "ตั้งค่า" }} />
  </Tabs>;
}
