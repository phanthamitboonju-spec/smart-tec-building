import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { Pressable, Text, View } from "react-native";
import { Button, Card, COLORS, Header, Metric, Page, SectionTitle, StatusPill, styles } from "@/components/film-ui";
import { useAppStore } from "@/lib/app-store";
import { formatArea } from "@/lib/film-calculator";

export default function HomeScreen() {
  const router = useRouter();
  const { jobs, settings } = useAppStore();
  const activeJobs = jobs.filter((job) => job.status !== "closed").length;
  const area = jobs.reduce((sum, job) => sum + (job.calculation?.glassAreaSqft ?? 0), 0);
  const fresh = jobs.reduce((sum, job) => sum + (job.calculation?.freshAreaSqft ?? 0), 0);
  return <Page>
    <View style={{ backgroundColor: COLORS.navy, borderRadius: 24, padding: 20, marginBottom: 18, overflow: "hidden" }}>
      <View style={{ position: "absolute", width: 170, height: 170, borderRadius: 100, borderWidth: 24, borderColor: "#39B8F218", right: -40, top: -70 }} />
      <Text style={{ color: COLORS.cyan, fontSize: 12, fontWeight: "900", letterSpacing: 1.5 }}>FILMCALC / FIELD TOOL</Text>
      <Text style={{ color: COLORS.white, fontSize: 28, fontWeight: "900", marginTop: 12, maxWidth: 290 }}>คุมงานฟิล์มให้แม่น ตั้งแต่บานแรก</Text>
      <Text style={{ color: "#BFD2E6", fontSize: 14, lineHeight: 21, marginTop: 8, maxWidth: 290 }}>วัด คำนวณ วางแผนตัด และส่งมอบในที่เดียว</Text>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 7, marginTop: 17 }}><View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: COLORS.lime }} /><Text style={{ color: "#D8E7F4", fontSize: 12 }}>บันทึกข้อมูลในอุปกรณ์ · ใช้งานออฟไลน์</Text></View>
    </View>
    <Header eyebrow="ภาพรวมหน้างาน" title="สวัสดีครับ" subtitle="เริ่มงานใหม่หรือกลับไปดูแผนที่บันทึกไว้" right={<View style={{ width: 42, height: 42, borderRadius: 14, backgroundColor: COLORS.cyanSoft, alignItems: "center", justifyContent: "center" }}><Text style={{ color: "#0A6B93", fontWeight: "900", fontSize: 18 }}>FC</Text></View>} />
    <View style={{ flexDirection: "row", gap: 10 }}><Metric label="งานที่กำลังทำ" value={String(activeJobs)} detail="ยังไม่ปิดงาน" icon="clipboard" /><Metric label="พื้นที่กระจก" value={area.toFixed(0)} detail="ตร.ฟุตสะสม" icon="maximize" tone="lime" /><Metric label="ฟิล์มใหม่" value={fresh.toFixed(0)} detail="ตร.ฟุตจากม้วน" icon="layers" tone="amber" /></View>
    <SectionTitle>ทางลัด</SectionTitle>
    <View style={{ flexDirection: "row", gap: 10 }}><Button icon="plus" onPress={() => router.push("/job/new")} style={{ flex: 1 }}>สร้างงานใหม่</Button><Button icon="bar-chart-2" variant="secondary" onPress={() => router.push("/(tabs)/reports")} style={{ flex: 1 }}>ดูรายงาน</Button></View>
    <SectionTitle action={<Pressable onPress={() => router.push("/(tabs)/jobs")}><Text style={{ color: COLORS.cyan, fontWeight: "800", fontSize: 13 }}>ดูทั้งหมด</Text></Pressable>}>งานล่าสุด</SectionTitle>
    {jobs.length === 0 ? <Card style={{ alignItems: "center", paddingVertical: 22 }}><Feather name="inbox" size={26} color={COLORS.cyan} /><Text style={{ color: COLORS.ink, fontWeight: "800", marginTop: 10 }}>ยังไม่มีงานบันทึก</Text><Text style={{ color: COLORS.muted, marginTop: 4, textAlign: "center" }}>สร้างงานแรกเพื่อเริ่มคำนวณแผนตัด</Text></Card> : jobs.slice(0, 3).map((job) => <Pressable key={job.id} onPress={() => router.push(`/job/${job.id}`)} style={({ pressed }) => [{ opacity: pressed ? 0.72 : 1 }]}><Card style={{ marginBottom: 10 }}><View style={{ flexDirection: "row", alignItems: "center" }}><View style={{ flex: 1 }}><Text style={{ color: COLORS.ink, fontSize: 16, fontWeight: "900" }}>{job.title}</Text><Text style={{ color: COLORS.muted, fontSize: 12, marginTop: 4 }}>{job.customer || "ไม่ระบุลูกค้า"} · {job.site || "ไม่ระบุสถานที่"}</Text></View><StatusPill status={job.status} /><Feather name="chevron-right" size={18} color={COLORS.muted} /></View><View style={{ flexDirection: "row", gap: 18, marginTop: 13 }}><Text style={styles.hint}>บาน {job.panes.length} รายการ</Text><Text style={styles.hint}>{job.calculation ? formatArea(job.calculation.glassAreaSqft, settings.areaUnit) : "ยังไม่คำนวณ"}</Text></View></Card></Pressable>)}
  </Page>;
}
