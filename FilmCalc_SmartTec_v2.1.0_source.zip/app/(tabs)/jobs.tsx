import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Pressable, Text, View } from "react-native";
import { Button, Card, COLORS, EmptyState, Field, Header, Page, StatusPill } from "@/components/film-ui";
import { useAppStore } from "@/lib/app-store";

export default function JobsScreen() {
  const router = useRouter();
  const { jobs } = useAppStore();
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<"all" | "draft" | "confirmed" | "installed" | "closed">("all");
  const filtered = useMemo(() => jobs.filter((job) => (status === "all" || job.status === status) && `${job.title} ${job.customer} ${job.site}`.toLowerCase().includes(query.toLowerCase())), [jobs, query, status]);
  return <Page><Header eyebrow="FIELD JOBS" title="รายการงาน" subtitle="ติดตามทุกงานตั้งแต่วัดหน้างานถึงส่งมอบ" right={<Button icon="plus" onPress={() => router.push("/job/new")}>สร้างงาน</Button>} />
    <Field label="ค้นหางาน" value={query} onChangeText={setQuery} placeholder="ชื่อลูกค้า สถานที่ หรือชื่องาน" />
    <View style={{ flexDirection: "row", gap: 7, marginBottom: 8 }}>{(["all", "draft", "confirmed", "installed", "closed"] as const).map((item) => <Pressable key={item} onPress={() => setStatus(item)} style={{ borderRadius: 999, paddingHorizontal: 11, paddingVertical: 8, backgroundColor: status === item ? COLORS.navy : COLORS.white, borderWidth: 1, borderColor: status === item ? COLORS.navy : COLORS.line }}><Text style={{ color: status === item ? COLORS.white : COLORS.muted, fontSize: 11, fontWeight: "800" }}>{item === "all" ? "ทั้งหมด" : item === "draft" ? "ร่าง" : item === "confirmed" ? "ยืนยัน" : item === "installed" ? "ติดตั้ง" : "ปิดงาน"}</Text></Pressable>)}</View>
    {filtered.length === 0 ? <EmptyState icon="clipboard" title="ยังไม่พบงาน" detail={jobs.length ? "ลองเปลี่ยนคำค้นหาหรือตัวกรอง" : "สร้างงานแรกเพื่อเริ่มวางแผนติดตั้ง"} action={<Button icon="plus" onPress={() => router.push("/job/new")}>สร้างงานใหม่</Button>} /> : filtered.map((job) => <Pressable key={job.id} onPress={() => router.push(`/job/${job.id}`)} style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}><Card style={{ marginBottom: 10 }}><View style={{ flexDirection: "row", alignItems: "center" }}><View style={{ flex: 1 }}><Text style={{ color: COLORS.ink, fontSize: 16, fontWeight: "900" }}>{job.title}</Text><Text style={{ color: COLORS.muted, fontSize: 13, marginTop: 4 }}>{job.customer || "ไม่ระบุลูกค้า"}</Text></View><StatusPill status={job.status} /><Feather name="chevron-right" size={18} color={COLORS.muted} /></View><View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 13, paddingTop: 11, borderTopWidth: 1, borderTopColor: COLORS.line }}><Text style={{ color: COLORS.muted, fontSize: 12 }}>{job.site || "ไม่ระบุสถานที่"}</Text><Text style={{ color: COLORS.ink, fontSize: 12, fontWeight: "800" }}>{job.calculation ? `${job.calculation.requiredRolls} ม้วน · ดึง ${job.calculation.rollPulls} ครั้ง · ${job.calculation.quoteAreaSqft} ตร.ฟุตเสนอราคา` : "ยังไม่คำนวณ"}</Text></View></Card></Pressable>)}
  </Page>;
}
