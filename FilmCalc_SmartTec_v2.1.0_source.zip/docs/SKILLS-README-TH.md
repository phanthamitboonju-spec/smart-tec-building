# สกิลที่มากับแพ็กที่สอง

ตรวจพบโฟลเดอร์สกิล 27 ชุด รวมไฟล์ `SKILL.md` และไฟล์ประกอบทั้งหมด 200 ไฟล์ เก็บไว้เดิมภายใต้ `docs/skills/filmcalc-skills/` โดยไม่ลบหรือเขียนทับเนื้อหา

สกิลเหล่านี้เป็นไฟล์คำสั่ง/คู่มือสำหรับ agent และเครื่องมือพัฒนา ไม่ใช่ library ที่ APK ต้องโหลดขณะทำงาน และไม่สามารถติดตั้งเข้า runtime ของ ChatGPT จาก ZIP นี้ได้โดยตรง ในโปรเจกต์นี้จึงเก็บไว้เป็นเอกสารอ้างอิงและไม่ให้สคริปต์รันเนื้อหาเหล่านั้นเอง

รายการ 27 ชุด:

1. accessibility
2. accessibility-review
3. account-research
4. beautiful-article
5. call-prep
6. capybara-skill
7. chrome-devtools
8. cypress-skill
9. draft-outreach
10. excel-generator
11. favicon-gen
12. gsap-core
13. gsap-plugins
14. microsoft-docs
15. muapi-ui-design
16. netlify-caching
17. penpot-uiux-design
18. programmatic-seo
19. puppeteer-skill
20. scrapling
21. seo-aeo-best-practices
22. spark-app-template
23. typst-pdf-maker
24. web-design-engineer
25. web-design-reviewer
26. web-perf
27. website-traffic-checker

สกิลเกี่ยวกับการออกแบบ/ตรวจสอบเว็บไซต์และ accessibility ช่วยเป็นแนวทางรีวิว UX ได้ แต่สกิลอย่าง SEO, outreach, account research, browser automation และ PDF creation ไม่ได้เปลี่ยนเป็นฟังก์ชันในแอปโดยอัตโนมัติ ต้องพัฒนา integration หรือ workflow แยกต่างหาก
