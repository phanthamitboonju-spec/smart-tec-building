# วิธีสร้างไฟล์ APK บนเครื่องพัฒนา Android

เอกสารนี้ใช้กับ source package ที่ปรับแล้วเท่านั้น; APK ยังไม่ได้ถูก build ในแชตนี้

## เครื่องมือที่ต้องติดตั้ง

- Node.js 22.12 ขึ้นไป
- pnpm 9.12 หรือ Corepack
- Java JDK 21
- Android Studio พร้อม Android SDK Platform / Build Tools / Platform Tools
- ตั้งค่า `ANDROID_HOME` หรือ `ANDROID_SDK_ROOT` ให้ชี้ไป Android SDK และติดตั้ง platform/tools ที่ Expo SDK 57 ต้องใช้

## Windows PowerShell

จากโฟลเดอร์ `filmcalc-source-project`:

```powershell
corepack enable
pnpm install --frozen-lockfile
pnpm exec expo prebuild --platform android
cd android
.\gradlew.bat assembleRelease
```

ไฟล์ output ปกติอยู่ที่:

```text
android\app\build\outputs\apk\release\app-release.apk
```

## macOS / Linux

```bash
corepack enable
pnpm install --frozen-lockfile
pnpm exec expo prebuild --platform android
cd android
./gradlew assembleRelease
```

ไฟล์ output ปกติอยู่ที่:

```text
android/app/build/outputs/apk/release/app-release.apk
```

## ตรวจและติดตั้ง

เชื่อมโทรศัพท์ เปิด Developer options / USB debugging แล้วตรวจอุปกรณ์:

```bash
adb devices
adb install -r android/app/build/outputs/apk/release/app-release.apk
```

ใน Windows ใช้ path ที่มี `\` ตามตัวอย่างข้างบน

## ข้อควรทราบ

- ผู้ใช้ปลายทางเปิดแอปได้โดยไม่ต้องมีบัญชีหรือ login; การ build ไม่ได้เปลี่ยนเงื่อนไขนี้
- การ build ในเครื่องต้องมีเครื่องมือ Android และดาวน์โหลด dependencies ก่อน
- APK แบบ sideload ไม่ใช่ Play Store release; ตั้งค่าการเซ็นแอปด้วย keystore ของเจ้าของระบบก่อนแจกจ่ายจริงในระยะยาว
- อย่าลบ/ล้างข้อมูลแอปก่อนทำระบบสำรอง เพราะข้อมูลปัจจุบันอยู่ใน AsyncStorage ของอุปกรณ์
- หลัง build ให้ทำ QA บนอุปกรณ์จริงตาม `ALIGNMENT-AUDIT-TH.md` ก่อนส่งให้ช่างใช้ตัดฟิล์ม
