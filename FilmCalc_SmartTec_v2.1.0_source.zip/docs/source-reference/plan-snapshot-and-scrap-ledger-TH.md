# Plan Snapshot SSOT + Scrap Ledger (ออกแบบ)

## หลักการ
1. Core คำนวณหนึ่งเดียว → `domain/calculation-service` → `engine/film-engine`
2. Snapshot แผนเป็นความจริงเดียว → ตาราง `job_plan_snapshot`
3. DB/auth/migrate แยก environment → `.env` / `.env.staging` / `.env.production`
4. กฎติดตั้งอยู่ใน domain ไม่ใช่แค่ UI
5. คลังเศษ = ledger ภายหลัง ไม่ใช้ localStorage เป็นความจริง

## job_plan_snapshot
- หนึ่งแถวต่อ (job_id, snapshot_version)
- `plan_json` เก็บผลคำนวณทั้งก้อนที่เซิร์ฟเวอร์สร้าง
- ใบเสนอราคา / ใบสั่งงาน ต้องอ้าง `job_id + snapshot_version`
- `job.plan` / `job.panes` ยังอยู่เพื่อความเข้ากันได้ย้อนหลัง

## scrap_lot (ยังไม่สร้างตารางในรุ่นนี้ — ออกแบบไว้)
เมื่อพร้อมหลายผู้ใช้ ค่อยเพิ่ม migration แยก:

```sql
-- DRAFT ONLY — do not apply in this release
CREATE TABLE scrap_lot (
  id UUID PRIMARY KEY,
  sku TEXT NOT NULL,
  brand_key TEXT NOT NULL,
  lot_code TEXT,
  roll_id TEXT,
  face TEXT,
  direction_key TEXT,
  width_cm NUMERIC(12,3) NOT NULL,
  height_cm NUMERIC(12,3) NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('available','reserved','consumed','waste','quarantine')),
  source_job_id UUID REFERENCES job(id) ON DELETE SET NULL,
  source_snapshot_version INTEGER,
  source_pane_id TEXT,
  reserved_by_job_id UUID REFERENCES job(id) ON DELETE SET NULL,
  reserved_at TIMESTAMPTZ,
  consumed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

กฎ: reserve/consume ต้องอยู่ใน transaction เดียว ห้ามใช้ localStorage เป็น ledger
