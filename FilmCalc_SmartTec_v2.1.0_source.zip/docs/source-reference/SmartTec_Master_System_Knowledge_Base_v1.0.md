# SmartTec Master System Knowledge Base v1.0

**เจ้าของระบบ:** บริษัท สมาร์ทเทค เอ็นเตอร์ไพรส์ จำกัด  
**ชื่อระบบ:** SmartTec Film System  
**Implementation baseline ที่รวมมา:** Source v10.33.1 (Full Source Patch / Staging Candidate)  
**เอกสารสถาปัตยกรรมอ้างอิง:** Blueprint v1.2 และ Full System Architecture v2.0  
**ภาษาเอกสาร:** ไทยเป็นหลัก  
**สถานะเอกสาร:** ชุดถ่ายทอดองค์ความรู้สำหรับ AI/ทีมพัฒนาอื่น ไม่ใช่ใบรับรอง Production

---

## 0. วิธีอ่านและลำดับแหล่งอ้างอิง

เอกสารชุดนี้รวมแหล่งข้อมูลหลายชนิดที่มีสถานะต่างกัน ห้ามนำมาเหมารวมว่าเป็นข้อเท็จจริงระดับเดียวกัน

| ประเภท | ความหมาย | วิธีใช้ |
|---|---|---|
| ข้อกำหนดผู้ใช้ | ความต้องการที่เจ้าของระบบระบุ | ใช้เป็นเป้าหมายหลัก เว้นแต่มีการยืนยันใหม่ |
| Source v10.33.1 | โค้ดจริงที่รวมในแพ็ก | ใช้ตรวจพฤติกรรมที่ implement แล้ว ห้ามสรุปว่าถูกต้องเพียงเพราะมีโค้ด |
| Blueprint v1.2 | แบบออกแบบเป้าหมาย | ใช้อ้างอิง UX/Architecture/กฎเป้าหมาย ต้องเทียบกับโค้ด |
| Architecture v2.0 | ข้อกำหนดสถาปัตยกรรมและฐานข้อมูลเชิงเป้าหมาย | เป็น design specification ไม่ใช่ schema ที่ deploy แล้วทั้งหมด |
| QA Report v10.33.1 | รายงานการตรวจใน sandbox | เป็นหลักฐานตามที่รายงานระบุ ไม่ใช่การทดสอบในระบบบริษัท |
| TDS/คู่มือผู้ผลิต | หลักฐานทางเทคนิคเฉพาะ SKU/Revision | เป็นหลักฐานสำหรับกฎด้านความปลอดภัยและติดตั้ง ต้องเก็บที่มา/รุ่นเอกสาร |

**ลำดับตัดสินเมื่อข้อมูลขัดกัน:** (1) ข้อกำหนดล่าสุดที่เจ้าของระบบยืนยัน (2) หลักฐานจาก source ปัจจุบันและการทดสอบจริง (3) Blueprint/Architecture ฉบับล่าสุดในฐานะเป้าหมาย (4) เอกสารเก่าเพื่อประวัติ (5) ความรู้ทั่วไปของ AI ใช้ได้เพียงเสนอแนวทาง ไม่ใช้เขียนทับข้อมูลจริง

เอกสาร Blueprint v1.2 และ Architecture v2.0 มีฐานอ้างอิงรุ่น v10.32.8/Source Dump รุ่นเก่าตามข้อความในเอกสาร จึงต้องถือเป็น design references และตรวจเทียบกับ Source v10.33.1 เสมอ

## 1. วัตถุประสงค์และขอบเขตระบบ

SmartTec เป็นระบบเว็บภายในองค์กรเดียว สำหรับงานฟิล์มอาคาร ตั้งแต่รับข้อมูลวัดกระจก คำนวณพื้นที่ วางแผนชิ้นตัด/ดึงฟิล์ม จัดการม้วน/เศษ/รอยต่อ จัดทำใบเสนอราคา ใบสั่งงานช่าง บันทึกติดตั้ง QC และรายงาน

ระบบไม่ใช่ SaaS สำหรับขายให้หลายองค์กร ไม่จำเป็นต้องให้พนักงานสมัครบัญชีหรือ Login รายบุคคลตามข้อกำหนดที่ผู้ใช้ให้ไว้ แต่ต้องจำกัดระบบไว้ใน Private Network/VPN/Private Gateway ที่องค์กรควบคุม ห้ามเปิดพอร์ตแอปโดยตรงสู่ Internet สาธารณะ

### 1.1 ผู้ใช้งานและรูปแบบงาน

- พนักงานทุกคนเข้าพื้นที่ทำงานหลักได้ทันทีโดยไม่มีการแยก role ที่ขวางการคำนวณ
- งานคำนวณตอบลูกค้าแบบรวดเร็วและงานเอกสารเต็มรูปแบบเป็น workflow/เครื่องมือใน workspace เดียวกัน ไม่ใช่ระบบคนละชุด
- การสร้าง/ออกเอกสารพิจารณาความครบถ้วนและสถานะงาน ไม่ใช่การแบ่งสิทธิ์ที่ผู้ใช้ไม่ได้ร้องขอ
- หากไม่มี named login จะระบุผู้กระทำเป็น `shared-staff` หรือรหัส session/device/gateway ที่เชื่อถือได้เท่านั้น ห้ามอ้างว่าสามารถพิสูจน์ตัวบุคคลได้

### 1.2 ขอบเขตหลัก

- งานฟิล์มกรองแสง ฟิล์มนิรภัย ฟิล์มตกแต่งกระจก และ SKU/การใช้งานที่มีข้อมูลรองรับ
- งานวัดขนาด/พื้นที่และคำนวณ
- การวางแผนทั้งงานก่อนตัด/ดึงฟิล์ม
- Roll/Sheet material planning
- การใช้เศษ การสร้างเศษใหม่ และการจองเศษ
- การต่อฟิล์มและข้อจำกัดการติดตั้ง
- Product master, price, technical profile, TDS
- Quotation, work order, installation, QC, warranty, report

ฟิล์มรถยนต์/PPF และการใช้งานบนพื้นผิวที่ไม่ใช่กระจกต้องแยก application profile และอนุมัติ scope/กฎใหม่ก่อนนำเข้าระบบ ห้ามใช้กฎกระจกแทนโดยอัตโนมัติ

## 2. หลักการบังคับของระบบ

1. **คำนวณได้โดยไม่เลือกสินค้า:** มิติที่ถูกต้องเพียงพอสำหรับคำนวณพื้นที่กระจกจริงได้ แม้ SKU ไม่ถูกเลือก
2. **Warning-first:** ข้อมูลไม่ครบต้องแสดงคำเตือนและคงข้อมูลที่คำนวณได้ ไม่ปิดกั้นโดยไม่จำเป็น
3. **UNKNOWN ≠ PASS:** สิ่งที่ไม่ทราบต้องคงสถานะ UNKNOWN/REVIEW ตามชนิดการตรวจ ห้ามแปลงเป็นผ่าน
4. **BLOCK ที่ยืนยันแล้วต้องไม่ถูกลดระดับ:** การไม่มี SKU หรือข้อมูลอื่นที่ไม่เกี่ยวกันต้องไม่เปลี่ยนผล BLOCK ของข้อห้ามจริง
5. **แยกพื้นที่:** พื้นที่กระจกจริง พื้นที่ชิ้นตัด พื้นที่ดึงฟิล์มใหม่ พื้นที่เศษที่นำกลับมาใช้ พื้นที่ติดตั้ง พื้นที่เสนอขาย และพื้นที่สูญเสียเป็นคนละ metric
6. **Whole-job first:** วางแผนทุกบานในงานพร้อมกันก่อนตัดสินใจเปิดม้วน/ดึงฟิล์มใหม่ ไม่คิดแยกบานจนทำให้เศษจากบานก่อนหน้าไม่ถูกนำมาพิจารณา
7. **Scrap-first where compatible:** ตรวจเศษที่มีอยู่ก่อนดึงฟิล์มใหม่ แต่ต้องผ่าน compatibility และสภาพใช้งานจริง
8. **Planning hierarchy:** ความเป็นไปได้/ความเข้ากันได้ทางเทคนิคก่อน ตามด้วยคุณภาพ แนวฟิล์ม/ลาย/ทิศทาง/ตำแหน่งรอยต่อ แล้วจึงลด fresh pull/waste/roll change และทำให้งานช่างง่ายขึ้น
9. **ไม่อ้าง optimal เกินจริง:** ถ้า planner ใช้ heuristic/deterministic search ห้ามเรียกว่า global optimum หรือ mathematical optimum
10. **Reuse ≠ Splice:** การนำเศษกลับมาใช้เป็นอีกเรื่องจากการต่อชิ้นฟิล์มภายในบาน
11. **Logical roll slot ≠ physical stock:** ช่องม้วนตั้งต้นเป็นช่องวางแผน ไม่ยืนยันว่ามีม้วนจริงหรือมีความจุจริง
12. **Immutable document snapshot:** เอกสารที่ออกแล้วต้องเก็บ snapshot; Master Data รุ่นใหม่ไม่แก้เอกสารย้อนหลัง การเปลี่ยนต้องออก revision ใหม่
13. **Single calculation/planning authority:** ทุกหน้า API ใบเสนอราคา ใบสั่งงาน รายงานและ PDF ต้องใช้ service/plan snapshot ชุดเดียวกัน ห้ามมีสูตรคัดลอกหลายจุด
14. **Evidence-based technical rules:** กฎความปลอดภัยต้องผูกกับ SKU/Revision, TDS/คู่มือ, วันมีผล และเงื่อนไขการทดสอบ
15. **Audit limitation explicit:** ไม่ใช้ login รายบุคคล หมายถึง audit ไม่สามารถยืนยันชื่อคนทำได้

## 3. สถานะและ validation model

| สถานะ | ความหมาย | การใช้งาน |
|---|---|---|
| PASS | ข้อมูลครบและผ่านกฎที่ใช้ตรวจ | ผ่านเฉพาะ scope ของกฎนั้น |
| REVIEW | ข้อมูลไม่ครบ/ยังรอยืนยัน/ต้องตรวจหน้างาน | คำนวณ/บันทึก/ออกเอกสารแบบมีเงื่อนไขได้ตามความเหมาะสม แต่ไม่อนุมัติติดตั้ง |
| BLOCK | มีข้อห้ามหรือความขัดแย้งที่ยืนยันแล้ว | ห้ามดำเนิน action ที่ขัดข้อห้าม |
| UNKNOWN | ไม่มีข้อมูลหรือหลักฐานเพียงพอ | ห้ามตีความเป็น PASS; โดยทั่วไปต้อง REVIEW |

แยก 3 มิติออกจากกัน:

- `data_completeness`: ข้อมูลครบ/ขาด/ไม่ทราบ
- `technical_validation`: PASS/REVIEW/BLOCK/UNKNOWN ตามกฎเฉพาะ
- `workflow_status`: Draft/Issued/On Hold/Cancelled/Completed
- `installation_readiness`: Not checked/Needs review/Ready/Not approved

การออกใบสั่งงานช่างไม่ได้หมายความว่าได้รับอนุมัติให้ตัดหรือติดตั้ง

### ข้อความ UI ตัวอย่าง

- `ยังไม่ได้เลือกรุ่นฟิล์ม — คำนวณพื้นที่ได้ แต่แผนวัสดุยังรอยืนยัน`
- `รอยืนยันหน้ากว้างม้วนจริงก่อนดึงฟิล์ม`
- `ยังไม่ทราบชนิดกระจก — ต้องตรวจหน้างานก่อนอนุมัติติดตั้ง`
- `พบข้อห้ามจากข้อมูลผู้ผลิต — ไม่อนุญาตให้ใช้วิธีนี้`
- `บันทึกแล้ว — เอกสารนี้ยังอยู่ในสถานะตรวจทาน`
- `ราคายังไม่ยืนยัน — กรุณาตรวจสอบก่อนส่งใบเสนอราคา`

## 4. หน่วยและการคำนวณพื้นที่

### 4.1 หน่วย canonical

ใช้มิลลิเมตร (mm) เป็นหน่วยภายในสำหรับมิติ geometry; เก็บทศนิยม/ความละเอียดด้วย numeric/decimal ตามความเหมาะสม หลีกเลี่ยง floating point ที่ทำให้ผลราคาหรือพื้นที่คลาดเคลื่อนโดยไม่ควบคุม แสดงผลตามหน่วยที่ผู้ใช้เลือกได้ เช่น mm/cm/m และตารางเสนอขายตามหน่วยบริษัท

แปลงพื้นที่:

- ถ้ามิติวัดเป็น mm: `area_m2 = width_mm * height_mm / 1_000_000`
- ถ้ามิติวัดเป็น cm: `area_m2 = width_cm * height_cm / 10_000`
- คูณจำนวนบาน/จำนวนซ้ำเฉพาะ metric ที่นิยามให้รวมจำนวน

### 4.2 นิยาม metric ที่ต้องแยก

| Metric | นิยาม |
|---|---|
| Actual glass area | พื้นที่กระจกตามขนาดวัดจริง ไม่รวม allowance เว้นแต่มีการระบุชัด |
| Cut-piece area | พื้นที่ชิ้นฟิล์มที่ตัดจริงจากมิติชิ้นตัด ซึ่งอาจรวม allowance |
| Fresh pull area | พื้นที่วัสดุใหม่ที่ดึงจากม้วนจริง ตามหน้ากว้างที่ใช้และความยาวดึงจริง |
| Reused scrap area | พื้นที่เศษเดิมที่นำกลับมาจ่ายให้ชิ้นงาน ต้องอ้างอิง scrap ID |
| Installed area | พื้นที่ฟิล์มที่ติดตั้งจริงตามบันทึกหน้างาน/วิธีวัดที่นิยาม |
| Quotation area | พื้นที่ฐานคิดราคาที่บริษัทกำหนด อาจไม่เท่ากับพื้นที่กระจกหรือชิ้นตัด |
| Waste/loss area | วัสดุที่ไม่ถูกนำไปเป็นชิ้นติดตั้งหรือเศษที่นำกลับมาใช้ได้ ตามนิยามบัญชีวัสดุ |

ห้ามใช้ `actual_glass_area`, `cut_piece_area`, `fresh_pull_area` หรือ `quotation_area` แทนกันโดยอัตโนมัติ

### 4.3 ตัวอย่างที่เป็นเพียงตัวอย่างคณิตศาสตร์

กระจก 80 × 100 cm มีพื้นที่จริง 0.80 m² หากสมมติ allowance 2 cm รอบด้าน จะได้ชิ้นตัด 84 × 104 cm = 0.8736 m² หากสมมติหน้ากว้างม้วน 152 cm และดึง 104 cm จะได้ fresh pull envelope 1.5808 m² ในตัวอย่างนี้เท่านั้น ตัวเลข allowance/หน้ากว้างไม่ใช่กฎสากลและต้องอ้าง profile/ม้วนจริงก่อนนำไปใช้กับงานจริง

## 5. Workflow: ก่อนดึงฟิล์ม

```text
Create Job
  -> Capture all panes / dimensions / quantities
  -> Validate measurement + units
  -> Calculate actual glass areas
  -> Optional product selection
  -> Resolve material compatibility groups
  -> Load available compatible scraps (not reserved/consumed)
  -> Generate whole-job candidate plan
  -> Allocate compatible scraps first
  -> Plan fresh roll pulls for remaining cut pieces
  -> Validate rotation / direction / factory edge / seam constraints
  -> Score candidate plans by technical feasibility, quality, waste, roll changes
  -> Save immutable plan snapshot + warnings + source data revisions
  -> Show plan and unresolved items for operator review
```

### 5.1 Planner priority

1. Technical feasibility and SKU/lot/profile compatibility.
2. Film/pattern/web direction, face, rotation, factory-edge requirements.
3. Splice count, method, position, visibility, seam direction and quality.
4. Reuse compatible available scraps before fresh pull.
5. Minimize fresh material pull and unusable waste.
6. Preserve useful child remnants for later jobs.
7. Reduce roll changes and simplify cutting/installation steps.

Planner output must contain plan version, input hash, engine version, constraints, candidate result score, reason codes, warning/block list and source snapshot. If it is heuristic, disclose the algorithm class and do not claim proof of optimum.

## 6. Workflow: ระหว่าง/หลังดึงและตัดฟิล์ม

**ห้ามถือว่าแผนที่ระบบสร้างเท่ากับวัสดุที่ใช้จริง** ต้องบันทึก actual operation แยกจาก planned operation

1. Operator confirms the actual physical roll or scrap source used (SKU, lot, roll ID, usable width, remaining length, face, direction).
2. Record actual pull width/length and actual cut-piece IDs.
3. Compare actual cutting result with plan snapshot; any change creates execution deviation, not silent overwrite.
4. For each offcut, create a unique child scrap record linked to source roll/scrap, job, pane, cut piece, operation, SKU, lot, dimensions, face, direction, factory-edge state, condition and measured timestamp.
5. Classify each offcut: available candidate, reserved, quarantine, discarded, or consumed; require reason for quarantine/discard.
6. Recalculate post-pull material balance using actual dimensions and source IDs.
7. Prevent duplicate scrap IDs and double consumption.
8. If the platform implements multi-device stock, use DB transaction/row locking/unique constraints for reserve→consume→create-child-scraps atomically; rollback entire transaction on failure.
9. If current source uses browser-local/advisory scrap data, do not represent it as global real-time warehouse. Do not use it as a guaranteed stock ledger across devices.
10. Corrections use compensating transactions/reversal events; never erase historic material movement.

### 6.1 Scrap lifecycle target

`Available -> Reserved -> Consumed` with branches to `Quarantine` and `Discarded`; reservation may be released when job/plan is cancelled. Consumed scrap cannot be reused. Child remnants reference parent source and create a genealogy graph; the same physical remnant must never appear as two available records.

## 7. Splice / seam rules

Splicing is distinct from reusing a whole remnant. Each seam must reference piece IDs and compatibility evaluation.

Potential methods represented in domain: `forbidden`, `butt`, `overlay`, `overlap_cut_through/double_cut`, `manufacturer_defined`, `unknown`. Never assume all methods are permitted for every SKU.

Check at minimum:

- SKU/material compatibility and manufacturer limitations
- lot/batch/roll restriction, whether same lot is mandatory
- film face and adhesive orientation
- web/pattern direction and allowed rotation/flip
- factory edge availability and which side must be retained
- seam axis, location, visibility and distance from edge/structure
- overlap amount and cutting method only when sourced
- glass/substrate compatibility, application side and warranty
- piece count and anti-jigsaw internal QC policy

Existing materials mention a two-piece/one-seam-per-pane and no zig-zag/jigsaw as an internal quality constraint; verify the current code and obtain owner confirmation before treating the exact limit as a final company rule. Source documentation includes anti-jigsaw/splice research and tests; check `docs/installation/splice-anti-jigsaw.md` and `src/tests/anti-jigsaw-splice.test.ts`.

## 8. Default roll and material planning behavior

- Default one `Logical Roll Slot` exists for planning usability only; it does not assert physical inventory or verified material capacity.
- With one slot, no per-pane roll selector is needed; assign internally to that logical slot.
- `Add Roll` is always available.
- When multiple slots exist, expose roll assignment controls and allow appropriate manual overrides.
- Current v10.33.1 README/QA says UI adds roll assignment by pane for multiple slots, while complete cut-piece-level mixed-roll assignment is not fully supported in all cases; do not overstate this feature.
- A pane may use multiple pieces/multiple rolls only if the plan and compatibility rules allow it.
- Do not use continuous-roll algorithms for sheet stock; stock format changes the planner model.

## 9. Product master and technical data management

Separate Product Management from general Settings.

Suggested hierarchy:

`Brand -> Product Family/Model -> Sellable SKU/Variant -> Roll/Sheet Profile -> Physical Roll/Lot`

Fields to consider (actual source may differ):

- identity: brand, family, model, SKU/code, display name, category, application type, status
- business: description, price, currency, unit, price effective dates, price status, tax policy reference
- packaging: roll/sheet, nominal/actual/usable width, nominal/usable length, tolerance, core, pack size
- technical: VLT, UVR, IRR, TSER, thickness, test condition, standard, substrate compatibility, application side, rotation, splice restrictions, edge gap, cure and aftercare where documented
- evidence: TDS, installation guide, warranty, source revision, URL/file, date verified, applicability SKU/lot/region

Unknown technical fields must remain null/UNKNOWN. Do not invent or extrapolate specs from neighboring products.

### 9.1 CRUD/history behavior

- Add/edit/archive products; hard-delete only when no historical use and safe under FKs. Prefer archive/soft-delete.
- Price and technical revisions should be effective-dated and auditable.
- Save updates current master data for new work; old issued documents retain snapshots.
- For SKU code change, preserve old code aliases if needed for historical lookup.
- Import/export catalog with validation, duplicate detection and rollback.
- Company admin process for master-data edits may be operationally configured, but do not introduce individual login friction contrary to owner's access model without approval.

## 10. Database and data integrity

### 10.1 Implementation fact

The current source contains PostgreSQL migration files from baseline `0002_core_schema.sql` through migration `0046_v103300_job_plan_snapshot.sql` plus auth-related migrations. `0002_core_schema.sql` defines `schema_migrations`, `system_release`, `system_setting`, `audit_log`, `product_brand`, `product_family`, `product`, and `job` with JSONB panes/plan fields among other schema components. Read actual migrations before changing schema; do not assume the conceptual schema in Architecture v2.0 has all been implemented relationally.

### 10.2 Target conceptual entities

The target model described in Architecture v2.0 includes:

- company_settings, system_settings, schema_migrations, audit_events
- brands, product_families, products_skus, product_prices, product_revisions
- product_roll_profiles, installation_profiles, technical_rule_sets, technical_rule_sources
- suppliers, lots, physical_rolls
- jobs, job_sites, job_openings, panes, pane_measurements
- calculation_runs, calculation_pane_results, plan_snapshots, cutting_plans, cutting_pieces, roll_allocations
- scrap_pieces, scrap_reservations, material_transactions, splice_segments
- quotations, quotation_lines, quotation_revisions
- work_orders, work_order_panes, installation_records, qc_checks, warranty_records, attachments, audit_events

These are target concepts; compare each with real migrations before implementing.

### 10.3 Constraints and integrity expectations

- UUID/ULID primary keys; FKs with RESTRICT/SET NULL/soft-delete choices documented
- canonical units and numeric types
- check constraints for positive dimensions, nonnegative amounts, enums/status transitions
- unique SKU normalized codes and unique scrap/source operation identifiers
- immutable issued document snapshot payload + snapshot version/hash
- indexes for job/status/date, product lookup, scrap compatibility/status, audit entity/time, plan/run id
- transaction boundaries for material movement; idempotency key for client retries
- optimistic version check for job/plan edits
- concurrency: row locks/serializable or suitable atomic conditional updates for scarce resources
- backup retention, encrypted backup, restore drill and migration rollback strategy

## 11. Canonical engines and code map

| Engine / module | Current source map | Responsibility / caveat |
|---|---|---|
| Calculation service | `src/domain/calculation-service.ts` | Common calculation orchestration; check every caller |
| Base planner | `src/engine/planner.ts` | Roll/cut plan logic; inspect algorithm/constraints |
| Multi-roll planner | `src/domain/multi-roll-planner.ts` | Multiple logical roll allocation; exact capabilities have limits |
| Mixed-film planner | `src/domain/mixed-film-planner.ts` | Mixed product/material planning, verify cases |
| Global scrap pool | `src/domain/global-scrap-pool.ts` | Scrap pool/availability logic; not a full transactional WMS per QA report |
| Product catalog | `src/domain/product-catalog.ts`, `src/data/catalog/*` | Catalog model and catalog dataset |
| Quotation domain | `src/domain/quotation.ts`, `src/components/film-quotation.tsx` | Quote calculations/presentation; verify pricing rules and VAT policy |
| Work order domain | `src/domain/work-order.ts`, `src/components/technician-work-order.tsx` | Work order preparation and status |
| 2D diagram | `src/components/installation-plan-diagram.tsx` | Installation plan visualization; inspect whether it fully separates glass elevation and roll layout |
| PDF work order | `src/domain/work-order-pdf.ts`, `src/lib/work-order-pdf-client.ts` | PDF output and fonts |

Every screen/document should consume a canonical calculation result/plan snapshot; no independently reimplemented formula in UI.

## 12. 2D simulation — two linked views

### A. Installation elevation (installer view)

Show actual pane outline, measured size, pane ID, piece IDs, installation order, seam locations and direction, source material reference (roll/scrap ID), face/orientation, factory-edge marker, unresolved instructions and warning overlays. It must never invent a geometry/orientation not supplied by the plan.

### B. Roll cutting layout (production/material view)

Show the real roll width/usable width, pull length, material source, cut-piece rectangles and dimensions, rotation status, offcut regions, child scrap IDs, waste and plan-vs-actual differences.

Both views use the same versioned plan snapshot and linked piece IDs but remain visually distinct. For sheet stock, render sheet nesting instead of roll length layout.

## 13. User interface and design system

### 13.1 Visual language

- Primary: deep navy blue (Blueprint reference `#102A43`)
- White `#FFFFFF`
- Cloud/neutral surface reference `#F1F5F9`
- Dark theme: dark navy/slate, not pure black; maintain contrast
- Theme modes: Light / Dark / System
- Typography: Sarabun for Thai UI; font binaries are intentionally not distributed in this handover archive. Obtain the authorized Sarabun font package and place the required files under `public/fonts/` using the local README.
- Icons: preserve the icon family used in source (package dependency includes `lucide-react`); avoid mixing unrelated icon sets.
- Use restrained motion; honor `prefers-reduced-motion`.
- Status colors must not rely on color alone; pair text/icon with color.

### 13.2 Layout

- Desktop: readable max-width/workspace grid, balanced side nav and content; avoid overly stretched tables/forms.
- Tablet: responsive two-column or collapsible panels; preserve key action reachability.
- Mobile: one-column stack, compact cards, touch-friendly controls, horizontally scrollable data tables only where necessary; keep primary actions visible.
- Use progressive disclosure: show essential results by default; formulas, technical rules and source details in expandable sections.
- Thai copy uses clear, consistent terminology and Sarabun sizing/line-height; check wrap/clipping in Thai labels and PDF.

### 13.3 Navigation target

Dashboard, Workspace/คำนวณ, Jobs/งานทั้งหมด, Quotations/ใบเสนอราคา, Work Orders/ใบสั่งงานช่าง, Material & Scrap/ม้วนและเศษ, Products/ข้อมูลสินค้า, Reports/รายงาน, Settings/ตั้งค่า. The menu arrangement should be validated against current routes before changing implementation.

## 14. Quotation and work order

### 14.1 Quotation

Include company identity, quote number/date/validity, customer/site, scope, item lines, product snapshot, metric basis, quantity/unit/area, unit price, amount, discount, VAT only per confirmed policy, total, terms, acceptance. Missing price must show `รอตรวจสอบราคา`/`price-review`, not confirmed zero. Distinguish quotation area from installation area. Issued document immutable; corrections create revision.

### 14.2 Work order

Include job/site, pane IDs, dimensions, cut-piece IDs and dimensions, install order, diagram, source roll/scrap/lot if known, splice method/location if known, face/orientation, factory edge, substrate/glass, application side, prep/accessories, edge gap, finishing, cure/aftercare, warnings, QC checklist, sign-off. Unknown information says `รอตรวจหน้างาน` and prevents READY status where required. Issuing work order does not approve installation.

## 15. Data flow: end to end

```text
User measurements
  -> measurement normalization (mm)
  -> canonical calculation service
  -> pane/job calculation results
  -> optional Product SKU binding
  -> technical rule evaluation (PASS/REVIEW/BLOCK/UNKNOWN)
  -> whole-job planner
  -> compatible scrap candidates + roll candidates
  -> plan snapshot (before pull)
  -> operator actual pull/cut execution
  -> actual pieces + actual waste/offcut recording
  -> scrap ledger transactions (after pull)
  -> quote snapshot / issue / revision
  -> work-order snapshot / issue / revision
  -> installation record + QC + photos + warranty
  -> reports using clearly labeled metric basis
```

Every stage stores references to job, source product revision, calculation run, planner version, plan snapshot, material transactions and document revision. If a source changes, recalculate/re-plan explicitly and create a new version; do not silently mutate historical evidence.

## 16. Reporting and summaries

Reports must explicitly state date range, job status, area metric, unit, product/SKU, and inclusion/exclusion rules. Do not sum quotation area as installed area. Distinguish estimated planned quantities from actual consumed quantities. Show unavailable/unknown values as unknown, not zero.

## 17. Security and operations

- Private network/VPN/private gateway only; HTTPS/TLS at reverse proxy.
- Reverse proxy strips client-supplied gateway headers and injects secret itself; firewall must deny public upstream access.
- Protect secrets in environment/secret manager; never commit `.env` with live secrets.
- Validate every API server-side; CSRF/session/rate limit per deployment model; CORS allowlist.
- Shared actor audit limitation documented.
- PostgreSQL persistent production database; PGlite local development only per README.
- Backup daily at minimum as an initial policy, but define RPO/RTO/retention with owner; encrypt backups and periodically restore-test.
- Production migration must be tested against restored staging DB first; do not modify historical migrations already applied.

## 18. Current v10.33.1 known status and limitations

Based on the included `README-TH.md` and `docs/QA-REPORT-v10.33.1.md`:

- Release label: `FULL SOURCE PATCH — STAGING CANDIDATE`; not Production Certified.
- Reported film-core tests: 301 passed / 0 failed / 3 skipped (PDF tests skipped due dependencies unavailable in sandbox).
- Reported script tests: 210 passed / 0 failed.
- Reported catalog check: 46 products / 147 variants / 5 brands.
- Reported production source/config checks passed.
- `npm install` timed out in that sandbox; typecheck, lint, production build, E2E were not completed there.
- No real-company PostgreSQL migration, backup/restore, private network penetration test, multi-device transaction test, PDF visual QA, device/browser QA or manufacturer/company data approval had been completed as of the report.
- Some roll/scrap stock is browser-local/advisory, not a transactional multi-user warehouse.
- Scrap double-reservation prevention across devices is not fully guaranteed by current source.
- Planner is deterministic/heuristic; no mathematical global optimality guarantee.
- Multi-roll cut-piece-level assignment is not complete in all cases; current UI assignment is by pane.
- Manufacturer specs, SKU/lot rules, price book, VAT and company document terms need owner/manufacturer verification.
- Font binaries are omitted from this handover archive; source uses Sarabun references and must be supplied from an authorized distribution.

Treat these as known gaps, not merely optional enhancements.

## 19. Recommended next-phase implementation priority

**P0 — Before real use:** verify PostgreSQL schema/migrations; prove private gateway/firewall; run dependency installation/typecheck/lint/build/E2E; complete PDF Thai visual QA; verify product prices/TDS/VAT/document templates with company; backup/restore drill; validate all calculation metrics and 80×100 example against expected policy.

**P1 — Core operational integrity:** implement transactional multi-device roll/scrap stock ledger; atomic reservation/consumption/child scrap; actual pull/cut execution and post-pull reconciliation; plan-vs-actual variance reports; cut-piece-level roll assignment where needed.

**P2 — Advanced UX/optimization:** full separate 2D installation elevation and roll/sheet cutting layout; better responsive/device tests; accessibility/contrast/reduced-motion; planner improvement with clear heuristic metrics and benchmark datasets.

## 20. Required acceptance tests for any receiving system

1. Calculate 80×100 cm glass area = 0.80 m² with no SKU.
2. Missing SKU produces warning but does not erase measurement or area calculation.
3. Unknown price is pending/null and never represented as confirmed zero.
4. A confirmed technical BLOCK remains BLOCK even when SKU/other optional fields are absent.
5. UNKNOWN is never promoted to PASS.
6. Full job planning considers all panes and compatible existing scraps before fresh pull.
7. After actual pull/cut, child remnants have unique IDs and full source lineage.
8. Concurrent attempts to reserve one scrap cannot both succeed in a transactional warehouse implementation.
9. Plan snapshot remains immutable after actual execution; actual deviation is recorded separately.
10. Same calculation output is used by UI, quote, work order, API and report.
11. Changing product price affects new quotes only; old issued quote snapshot remains unchanged.
12. Work order in REVIEW can be issued for preparation without marking installation ready.
13. Confirmed incompatible material/splice method causes BLOCK.
14. Installation elevation and roll cutting layout remain linked by piece IDs and plan revision.
15. Thai text renders with readable Sarabun in app and PDF; no clipped columns/overlaps across mobile/tablet/desktop.
16. Private gateway denies untrusted requests; app upstream is not public.
17. Backup restores into a clean staging environment and migration order is reproducible.

## 21. คำสั่งส่งต่อสำหรับ AI/ทีมพัฒนาอื่น

> คุณได้รับ SmartTec System Handover Package เพื่อสืบทอดและพัฒนาระบบต่อ ห้ามเริ่มเขียนระบบใหม่จากการคาดเดา ให้เริ่มจากอ่าน `00_START_HERE/README_TH.md`, `01_MASTER_KNOWLEDGE/SmartTec_Master_Knowledge_Base_v1.0.md`, `02_ARCHITECTURE_AND_BLUEPRINT/*`, `03_AI_COMMANDS/*`, `04_RELEASE_EVIDENCE/*` และ Source v10.33.1 ทั้งชุด ทำ inventory/hash ของไฟล์ ตรวจว่าแต่ละข้อใน Knowledge Base มีหลักฐานจาก source/test/TDS หรือเป็นเพียง target design แล้วรายงาน discrepancy ก่อนแก้ไข รักษา behavior และข้อมูลเดิมที่ยืนยันแล้ว ห้ามเดาสเปกผู้ผลิต ห้ามเปลี่ยนกฎโดยไม่มี decision record ทำการแก้แบบ incremental พร้อม regression tests และสร้าง release ใหม่พร้อม checksum, QA evidence, migration plan, rollback, install guide และรายการ unresolved issues ห้ามอ้าง production-ready จนกว่าจะผ่าน staging/production checks จริง

---

**เอกสารนี้เป็นเอกสารถ่ายทอดระบบฉบับรวม:** ใช้คู่กับ source code, migration, tests และเอกสารหลักฐานในโฟลเดอร์อื่น ไม่ใช่สิ่งทดแทน source code หรือคู่มือผู้ผลิต
