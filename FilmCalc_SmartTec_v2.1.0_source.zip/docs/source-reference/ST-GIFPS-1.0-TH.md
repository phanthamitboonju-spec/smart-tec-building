# SmartTec Global Intelligent Film Planning Standard — ST-GIFPS 1.0

**สถานะ:** มาตรฐานข้อกำหนดระบบ (System Rulebook)  
**รุ่นอ้างอิง:** SmartTec Film System 10.32.8  
**วันที่จัดทำ:** 2 พฤศจิกายน 2026  
**ขอบเขต:** ฟิล์มกรองแสงอาคาร ฟิล์มนิรภัย ฟิล์มกราฟิกกระจก และฟิล์มตกแต่งภายใน  
**ข้อจำกัด:** เอกสารนี้ไม่ใช้แทน TDS, Installation Guide หรือ Instruction Bulletin ของ SKU จริง

## 1. ปรัชญาหลัก

SmartTec ต้องวางแผนฟิล์มทั้งโครงการก่อนสั่งตัด โดยคำนึงถึงความถูกต้องของการติดตั้ง ความเข้ากันได้ของฟิล์ม การลดรอยต่อ การใช้เศษ และความสามารถในการตรวจสอบย้อนกลับ เป้าหมายคือใช้ฟิล์มใหม่เท่าที่จำเป็นโดยไม่ลดคุณภาพหรือฝ่าฝืนคู่มือผู้ผลิต

**ลำดับสูงสุด:** Installation correctness → seam integrity → material traceability → material efficiency → operator convenience.

## 2. ประเภทกฎ

### P0 — Hard constraints (ห้ามละเมิด)
- ห้ามต่อแบบจิ๊กซอว์, grid, patchwork หรือมีรอยต่อสองแกนในบานเดียว
- หนึ่งบานต้องเป็นแผ่นเดียว หรือแผ่นเต็ม 2 แผ่นที่เชื่อมด้วยแนวรอยต่อเดียวต่อเนื่อง (V หรือ H) เท่านั้น
- ห้ามนำเศษจาก physical pane unit ที่เพิ่งสร้างเศษชิ้นนั้นกลับมาเติมบานเดียวกัน
- ห้ามใช้เศษที่ขนาดสุทธิไม่พอ, ฟิล์มไม่ตรง, ด้านผิวผิด, หมุนผิดทิศ หรือไม่มี provenance ที่ตรวจสอบได้
- ห้ามใช้เศษหรือรอยต่อที่ละเมิดข้อกำหนด SKU / TDS / Lot / Roll / Direction / Factory Edge
- ห้ามใช้เศษเดียวกันซ้ำหรือจองซ้ำ และห้ามใช้เศษก่อนเกิดจริงในลำดับการผลิต
- หากข้อมูลฟิล์มหรือวิธีต่อไม่ครบ ต้องเป็น REVIEW/BLOCK ไม่ใช่เดาให้ผ่าน

### P1 — เป้าหมายการเพิ่มประสิทธิภาพ (เรียงตามลำดับ)
1. ลดจำนวน seam lines รวมทั้งงานให้ต่ำที่สุด
2. เมื่อจำนวนรอยต่อเท่ากัน ให้ลด fresh film pull
3. เพิ่มการใช้เศษที่เข้ากันได้โดยไม่เพิ่มรอยต่อ
4. ลดจำนวนม้วนที่เปิดและความยาวม้วนที่เหลือทิ้ง
5. ลดเศษที่ใช้ต่อไม่ได้

### P2 — Operational preferences
- ลดการเปลี่ยนม้วน/การตั้งเครื่อง
- จัดลำดับการตัดให้เหมาะกับช่าง
- เลือกตำแหน่งรอยต่อที่รบกวนสายตาน้อยกว่าเมื่อ SKU และงานอนุญาต

P1 ใช้ lexicographic ranking ไม่ใช้ weighted score ที่ยอมเพิ่มรอยต่อเพื่อประหยัดพื้นที่

## 3. Whole-job analysis ก่อนดึงฟิล์ม

ก่อนตัดต้องรวบรวมบานทั้งหมด ขนาดจริง จำนวน SKU, Lot, roll profiles, direction, face, allowed rotations, seam policy, existing scraps และข้อกำหนดหน้างาน จากนั้นสร้าง pane families และความต้องการแผ่นเต็ม

ระบบต้องประเมินทั้งลำดับตัดและผลพลอยได้จากแต่ละ pull ไม่เลือกบานแรกตามลำดับที่ผู้ใช้กรอกโดยอัตโนมัติ เศษในอนาคตสามารถใช้ได้เฉพาะเมื่อแผน execution กำหนดให้แหล่งกำเนิดถูกตัดก่อนผู้รับเศษ

## 4. Pane Family และการใช้เศษจากบานตัวเอง

### 4.1 นิยาม
Pane Family คือกลุ่ม physical panes ที่มีคุณสมบัติที่จำเป็นเหมือนกัน ได้แก่ ขนาดตัดที่ normalize แล้ว, SKU/material contract, Lot เมื่อเป็นเงื่อนไข, face, direction, allowed rotations และแนวตัดที่บังคับเหมือนกัน

`qty` ต้องขยายเป็นจำนวน physical panes จริง ห้ามนับจำนวนแถว input แทนจำนวนบาน

### 4.2 กฎการใช้เศษ
- อนุญาตให้เศษจาก physical pane หนึ่งใช้กับ sibling pane อีกใบใน Pane Family เดียวกันได้ เมื่อ family มี physical panes ตั้งแต่ 2 บานขึ้นไป และ material compatibility ผ่าน
- อนุญาตให้เศษจาก Pane Family อื่น/บานอื่นใช้ได้เมื่อ SKU, face, lot, roll, direction, rotation และ material reuse policy อนุญาต
- ห้ามเศษจาก physical pane UID เดียวกันกลับมาเติม pane UID เดิมที่เพิ่งสร้างเศษ
- ห้ามอนุมานว่าเศษใช้ได้เพียงเพราะขนาดพอดี ต้องตรวจ usable dimensions หลัง cut allowance และ edge conditions

“ใช้เศษกับบานตัวเอง” ในมาตรฐานนี้หมายถึงใช้กับบานอื่นในกลุ่มกระจกซ้ำเดียวกัน ไม่ใช่เอาเศษจากการตัด physical pane ใบเดียวกันกลับไปปะใบบานนั้น

## 5. Scrap lifecycle และการตรวจสอบ

สถานะมาตรฐาน: CANDIDATE → AVAILABLE → RESERVED → IN_USE → CONSUMED; สถานะทางเลือก QUARANTINE และ WASTE

ทุก scrap record ต้องมี unique ID, parent ID, source job/pane/roll, SKU, Lot, face, machine/pattern direction, rotation, factory/cut-edge metadata, actual/usable dimensions, condition, status, location และ reservation/consumption history

เมื่อแบ่งเศษแม่เป็นเศษลูก ต้องลด/ปิดพื้นที่ที่ถูกใช้จากเศษแม่อย่างถูกต้อง ห้ามใช้เศษแม่และเศษลูกซ้ำซ้อนกัน การจองต้อง atomic/transactional ในคลังกลางก่อนใช้งานจริง

## 6. Scrap-first allocation

ลำดับตรวจเชิงนโยบาย: (1) เศษที่มีอยู่จาก Pane Family เดียวกันแต่ต่าง physical pane, (2) เศษจาก pane อื่นใน job, (3) เศษจาก central warehouse, (4) เศษ/ปลายม้วนจาก roll ที่เปิดใช้อยู่, (5) fresh pull

ลำดับนี้เป็น candidate priority เท่านั้น การเลือกจริงต้อง optimize ทั้งงานและไม่เพิ่มจำนวน seam lines หรือขัด material contract เศษจากคลังกลางต้อง RESERVED ด้วย transaction ก่อนถูกใช้จริง

## 7. Seam / full-panel design

### 7.1 รูปแบบแผ่น
- NO_SEAM: แผ่นเดียวครอบคลุมบานหลังเผื่อขอบ
- V: แผ่นเต็ม 2 แผ่นประกอบตามแนวตั้งหนึ่งแนว
- H: แผ่นเต็ม 2 แผ่นประกอบตามแนวนอนหนึ่งแนว

แผ่นด้าน A และ B ของ seam ต้องเต็มช่วงที่กำหนด ไม่อนุญาตการปะเศษหลายชิ้นเพื่อสร้างแผ่นด้านใดด้านหนึ่ง และต้องไม่มี seam segment ที่ไม่ต่อเนื่อง

### 7.2 ขอบเขตทางเรขาคณิต
ให้คำนวณ usable roll width หลังหัก edge allowance และ splice allowance ตาม SKU จริง ไม่ใช้ nominal roll width โดยตรง ถ้าบานต้องใช้มากกว่า 2 panels หรือมีมากกว่า 1 seam line ให้ `INFEASIBLE_UNDER_ONE_SEAM_POLICY` และเสนอฟิล์มหน้ากว้างอื่น/แผนที่ได้รับอนุมัติ ห้ามผ่อนกฎเป็น grid

### 7.3 วิธีทำ seam
V/H คือแนววางแผ่น; Butt, Overlap, Double-cut/Overlap-cut-through, cover strip และ forbidden คือวิธี seam ที่แตกต่างกัน ต้องอ่านจาก SKU bulletin เท่านั้น ระยะ overlap, factory edge, edge gap, sealant และ accessory quantities ห้ามตั้งเป็นค่ากลาง

### 7.4 ความต่อเนื่องของ Roll/Lot/Direction
สำหรับ seam ในบานเดียวกัน SmartTec ใช้ policy เริ่มต้นที่เข้มงวด: physical roll เดียวกัน, Lot เดียวกัน, face และ machine/pattern direction เดียวกัน เว้นแต่ SKU bulletin ระบุข้อยกเว้นที่ชัดและได้รับการบันทึก/อนุมัติ การใช้เศษเต็มแผ่นกับบานอื่นแยกจาก seam compatibility และใช้กฎ reuse ของ SKU

## 8. Material consistency

ต้องมี source reference ที่ตรวจได้สำหรับ SKU-specific: allowed rotations, film face, pattern/gradient direction, machine direction, cross-web direction, lot compatibility, roll reuse, splice method, overlap width, factory edge, double-cut prohibition, cover strip, IPA/attachment, edge sealer, substrate/glass compatibility และ installation side

`UNKNOWN` ต้องเป็น REVIEW และไม่ให้ auto-approve งานตัด/ต่อที่ขึ้นกับข้อมูลนั้น `FORBIDDEN` ต้อง BLOCK

## 9. Global optimization — honesty contract

Exact global optimization ต้องพิจารณาการจัดสรร pane-to-roll, scrap-to-pane, cut layouts, orientation, roll lengths, production order, scrap generation/consumption และ hard constraints พร้อมพิสูจน์ optimality หรือ lower/upper bound

สถานะ solver: OPTIMAL (พิสูจน์แล้ว), FEASIBLE (พบแผนแต่ยังไม่พิสูจน์ดีที่สุด), INFEASIBLE, UNKNOWN, MODEL_INVALID

**สถานะ implementation ของ v10.32.8:** Engine ปัจจุบันเป็น deterministic multi-start heuristic; ไม่ใช่ Global Exact Solver. โหมดคำนวณม้วนเดียวมองเศษร่วมกันใน job scope; multi-roll planner แยก scrap pools ตาม physical roll. ยังไม่มี cross-roll global scrap assignment และไม่มี cross-job transactional warehouse. ห้ามแสดง OPTIMAL หรืออ้างว่าได้ global optimum

## 10. Execution dependency

แผนต้องเป็น acyclic dependency graph: source pull/cut เกิดก่อน scrap consume, scrap consume ก่อนสร้าง remainder child, และทุก piece/roll reservation มี one-time identity การเปลี่ยนแผนหลังเริ่มตัดต้องเก็บ plan version ใหม่และไม่แก้ประวัติ actual movements

## 11. Data and document SSOT

- Film Engine เป็นแหล่งคำนวณ geometry/cut/seam/material allocation
- Approved Plan Snapshot เป็นแหล่งเดียวของ Quote, Work Order, Cut Plan และ Installation Checklist
- Quote area, glass area, cut area, fresh-pull area และ installed area ต้องแยกกัน ไม่ใช้แทนกัน
- Actual material movement เกิดเมื่อยืนยันการตัด/ใช้จริง ไม่ใช่ตอน preview plan
- Browser Local Storage เป็นข้อมูลเฉพาะอุปกรณ์ ไม่ใช่ shared stock ledger

## 12. Required tests

- pane family จากหลาย input rows และ `qty` ขยาย physical units ถูกต้อง
- sibling reuse อนุญาตเฉพาะ family count ≥2; self physical pane reuse ถูกบล็อก
- cross-pane whole-sheet reuse ตรวจทุก material rules
- single pane 0/1 seam only, max two full panels; third panel must be infeasible
- no perpendicular seam axes; no patchwork panels
- lot/roll/direction/face/factory-edge/method constraints
- Auto planner tests geometrically feasible V/H rotations only after evaluating the complete job; a selected rotation is a non-blocking REVIEW warning for the installer. This planning behavior does not override manufacturer installation instructions; verify SKU direction/pattern/face before cutting.
- scraps cannot be consumed before producer; cannot be double-reserved/consumed
- randomized multi-pane reconciliation and order-invariance
- comparison with exhaustive enumeration on small optimization fixtures
- Quote/Work Order/PDF consume one approved plan snapshot
- cross-roll/cross-job tests only after those features are implemented

## 13. Current implementation status (v10.32.8)

| Capability | Status |
|---|---|
| Anti-jigsaw / one axis | Implemented and tested |
| Max 2 full panels / 1 seam | Implemented and tested |
| Pane Family sibling reuse >=2 physical panes | Implemented and tested |
| Same physical unit offcut reuse blocked | Implemented and tested |
| Single-roll job-level scrap look-ahead | Implemented as heuristic |
| Multi-roll offcuts shared across rolls | Not implemented; per-roll isolated pools |
| Cross-job transactional scrap warehouse | Not implemented |
| SKU / Lot / Face / Rotation / direction checks | SKU/face/Lot/roll incompatibilities remain enforced; auto quarter-turns are optimizer candidates and produce REVIEW warnings, not rotation-only BLOCKs |
| Product-specific accessory consumption (cover strip/IPA/sealer) | Not fully modeled |
| Global Exact Optimization | Not implemented; current algorithm is heuristic |
| Installed production build/browser/PDF DB staging proof | Not verified in this environment |

## 14. Manufacturer source references

1. 3M, Application: Building Windows, Instruction Bulletin Rev A (Dec 2024): https://multimedia.3m.com/mws/media/2419568O/application-building-windows-ra-pdf.pdf
2. 3M, Safety & Security Window Films Installation Guidelines, Rev C (Jan 2025): https://multimedia.3m.com/mws/media/1704892O/security-window-film.pdf
3. 3M, FASARA Glass Finishes Product Bulletin (Jan 2025): https://multimedia.3m.com/mws/media/224434O/product-bulletin-fasara.pdf
4. 3M, FASARA Application Guidelines, Rev A (Feb 2022): https://multimedia.3m.com/mws/media/2175776O/3m-fasara-glass-finishes-application-guidelines.pdf
5. 3M DI-NOC installation guide: follow current SKU-specific bulletin supplied with the product; the permitted seam method and direction vary by product family.
6. Google OR-Tools CP-SAT documentation: https://developers.google.com/optimization/cp/cp_solver

Always verify the latest document revision and the exact SKU/market region before work. Manufacturer instructions override generic planning preferences.
