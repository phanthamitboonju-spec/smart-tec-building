# สร้างไฟล์ APK (v2.1.0) — เลือกทางใดทางหนึ่ง

APK นี้ลงนามด้วย debug keystore (ติดตั้งแบบ sideload ได้ทันที ไม่ต้องล็อกอินในแอป) ถ้าจะขึ้น Play Store ต้องทำ release keystore ของคุณเอง

## ทาง A — GitHub Actions (ไม่ต้องลงอะไรในเครื่อง)
1. สร้าง repo ใน GitHub แล้วอัปโหลดโฟลเดอร์นี้ทั้งหมด (branch `main`)
2. แท็บ Actions → "Build FilmCalc APK" → Run workflow
3. รอ ~10–15 นาที → ดาวน์โหลด artifact `FilmCalc-SmartTec-apk` ได้ไฟล์ `.apk`

## ทาง B — EAS Build (บัญชี Expo ฟรี)
```
pnpm install
npx eas-cli login
npx eas-cli build -p android --profile apk
```
ได้ลิงก์ดาวน์โหลด APK จาก Expo

## ทาง C — เครื่องที่มี JDK 17 + Android SDK
```
pnpm install
pnpm build:android:apk
```
ไฟล์อยู่ที่ `android/app/build/outputs/apk/release/app-release.apk`

## สถานะการตรวจในรอบนี้
ผ่าน: `tsc --noEmit`, `pnpm test:engine`, `expo export --platform android` (Hermes bundle), `expo prebuild --platform android`
ยังไม่ได้ทำ: คอมไพล์ Gradle เป็น APK และทดสอบบนเครื่องจริง (สภาพแวดล้อมที่ทำงานเข้าถึง Android SDK/Maven ไม่ได้)
