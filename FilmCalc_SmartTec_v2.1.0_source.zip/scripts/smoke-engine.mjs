import assert from "node:assert/strict";
import {
  calculateJob,
  DEFAULT_PRODUCTS,
  DEFAULT_SETTINGS,
  buildPhysicalRollProfiles,
  DEFAULT_ROLL_RULES,
} from "../lib/film-calculator.ts";
import { runMultiRollCalculation } from "../lib/source-engine/src/domain/multi-roll-planner.ts";
import { SYSTEM_VERSION } from "../lib/source-engine/src/version.ts";

const product = DEFAULT_PRODUCTS.find((item) => item.sku === "A1" && item.brandKey === "smarttec");
assert.ok(product, "source catalog must contain SmartTec A1");
assert.equal(DEFAULT_PRODUCTS.length, 160, "only current selectable building-film SKUs are offered");

const verifiedRules = {
  ...DEFAULT_ROLL_RULES,
  lotId: "LOT-SMOKE-01",
  directionKey: "DIR-SMOKE-01",
  policy: "directional",
  face: "A",
  factoryEdge: "A",
  spliceMethod: "butt",
  specSource: "คู่มือทดสอบสำหรับ smoke test หน้า 1",
  specVerified: true,
};
const rolls = buildPhysicalRollProfiles(product, 1, DEFAULT_SETTINGS, verifiedRules, "smoke-job");

// A single ordinary panel: one full-width pull, no seam, and confirmed input constraints.
const ordinary = calculateJob(
  [{ id: "ordinary", label: "บาน 1", widthCm: 120, heightCm: 180, qty: 1, direction: "auto" }],
  product,
  2,
  rolls,
);
assert.equal(ordinary.engineVersion, SYSTEM_VERSION);
assert.equal(ordinary.requiredRolls, 1);
assert.equal(ordinary.rollPulls, 1);
assert.equal(ordinary.totalSeams, 0);
assert.equal(ordinary.orientationStatus, "pass");
assert.equal(ordinary.quoteAreaSqft, 33);

// The 28 x 184 cm side offcut from pane 1 supplies pane 2 after 2 cm edge allowance.
// The whole-job engine must plan the donor before using its offcut: one fresh pull total.
const reuse = calculateJob(
  [
    { id: "donor", label: "บาน 1", widthCm: 120, heightCm: 180, qty: 1, direction: "auto" },
    { id: "receiver", label: "บาน 2", widthCm: 24, heightCm: 180, qty: 1, direction: "auto" },
  ],
  product,
  2,
  rolls,
);
assert.equal(reuse.rollPulls, 1);
assert.equal(reuse.requiredRolls, 1);
assert.deepEqual(
  reuse.planSnapshot.engine.panes.map((pane) => pane.cutPieces?.map((piece) => piece.source)),
  [["fresh"], ["scrap"]],
);
assert.equal(reuse.scraps.length, 0);

// A pane wider than a 152 cm roll requires a seam. The planner returns REVIEW, not PASS.
const seam = calculateJob(
  [{ id: "wide", label: "บาน 1", widthCm: 300, heightCm: 200, qty: 1, direction: "auto" }],
  product,
  2,
  rolls,
);
assert.equal(seam.totalSeams, 1);
assert.equal(seam.orientationStatus, "review");

// Invalid dimensions must fail closed.
assert.throws(() => calculateJob(
  [{ id: "invalid", label: "บาน 1", widthCm: 0, heightCm: 180, qty: 1, direction: "auto" }],
  product,
  2,
  rolls,
));

// Missing catalog roll dimensions may use settings as an estimate, but cannot be promoted to verified stock.
const missingDimensionsProduct = { ...product, rollWidthCm: 0, rollLengthCm: 0, isCustom: false };
const fallbackRolls = buildPhysicalRollProfiles(
  missingDimensionsProduct,
  1,
  DEFAULT_SETTINGS,
  { ...verifiedRules, specSource: "manual smoke fixture", specVerified: true },
  "fallback-job",
);
assert.equal(fallbackRolls[0].width_cm, DEFAULT_SETTINGS.defaultRollWidthCm);
assert.equal(fallbackRolls[0].length_cm, DEFAULT_SETTINGS.defaultRollLengthCm);
assert.equal(fallbackRolls[0].specVerified, false);
const fallbackEstimate = calculateJob(
  [{ id: "fallback", label: "บาน 1", widthCm: 120, heightCm: 180, qty: 1, direction: "auto" }],
  missingDimensionsProduct,
  2,
  fallbackRolls,
);
assert.equal(fallbackEstimate.orientationStatus, "review");

// The source planner's maximum of 20 physical rolls is enforced.
const sourceConfig = {
  filmMax: 152,
  rollLen: 3000,
  margin: 2,
  divisor: 929.0304,
  scrapMin: 0,
  minStrip: 15,
  spliceAllowanceCm: 0,
  quoteBufferPct: 2,
  dimensionUnit: "cm",
  areaUnit: "sqft",
  jobProfile: "building-film",
  version: SYSTEM_VERSION,
  optimizerEffort: "full",
};
const overLimitRolls = Array.from({ length: 21 }, (_, index) => ({
  id: `roll-${index + 1}`,
  label: `ม้วน ${index + 1}`,
  width_cm: 152,
  length_cm: 3000,
  policy: "unknown",
  face: "unknown",
  factoryEdge: "unknown",
  sameLotForSplice: true,
  specSource: "",
  specVerified: false,
  spliceMethod: "unknown",
}));
assert.throws(() => runMultiRollCalculation(
  [{ id: "one", label: "บาน 1", width_cm: 50, height_cm: 50, qty: 1, dir: "auto" }],
  sourceConfig,
  undefined,
  overLimitRolls,
), /ไม่เกิน 20 ม้วน/);

console.log(JSON.stringify({
  status: "PASS",
  engineVersion: SYSTEM_VERSION,
  selectableBuildingSkus: DEFAULT_PRODUCTS.length,
  checks: [
    "ordinary single-pane calculation",
    "whole-job side-offcut reuse before another fresh pull",
    "seam case remains REVIEW, not PASS",
    "zero dimension rejected",
    "catalog-missing roll size uses estimate only and stays REVIEW",
    "physical-roll maximum enforced",
  ],
  result: {
    ordinary: { rolls: ordinary.requiredRolls, pulls: ordinary.rollPulls, seams: ordinary.totalSeams, quoteAreaSqft: ordinary.quoteAreaSqft, status: ordinary.orientationStatus },
    reuse: { rolls: reuse.requiredRolls, pulls: reuse.rollPulls, paneSources: reuse.planSnapshot.engine.panes.map((pane) => pane.cutPieces?.map((piece) => piece.source)), remainingScraps: reuse.scraps.length },
    seam: { pulls: seam.rollPulls, seams: seam.totalSeams, status: seam.orientationStatus },
  },
}, null, 2));
