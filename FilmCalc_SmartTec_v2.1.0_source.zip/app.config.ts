import type { ExpoConfig } from "expo/config";

const appId = "com.smarttec.filmcalc";
const config: ExpoConfig & { logoUrl: string } = {
  name: "FilmCalc | SmartTec",
  slug: "filmcalc-smarttec",
  logoUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519664096784593/EDfEXeksWOEULNkN.png",
  version: "2.1.0",
  orientation: "portrait",
  icon: "./assets/images/icon.png",
  scheme: "filmcalc",
  userInterfaceStyle: "automatic",
  ios: {
    supportsTablet: true,
    bundleIdentifier: appId,
    infoPlist: { ITSAppUsesNonExemptEncryption: false },
  },
  android: {
    package: appId,
    adaptiveIcon: {
      backgroundColor: "#071A33",
      foregroundImage: "./assets/images/android-icon-foreground.png",
      backgroundImage: "./assets/images/android-icon-background.png",
      monochromeImage: "./assets/images/android-icon-monochrome.png",
    },
    predictiveBackGestureEnabled: true,
    permissions: [],
    versionCode: 21,
  },
  web: {
    bundler: "metro",
    output: "static",
    favicon: "./assets/images/favicon.png",
  },
  plugins: [
    "expo-asset",
    "expo-router",
    ["expo-splash-screen", {
      image: "./assets/images/splash-icon.png",
      imageWidth: 200,
      resizeMode: "contain",
      backgroundColor: "#ffffff",
    }],
    ["expo-build-properties", {
      android: {
        buildArchs: ["arm64-v8a", "armeabi-v7a"],
        minSdkVersion: 24,
      },
    }],
  ],
  experiments: {
    typedRoutes: true,
    reactCompiler: true,
  },
};

export default config;
